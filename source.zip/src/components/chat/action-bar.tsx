import { Share2, Download, Copy, RefreshCw, ThumbsUp, ThumbsDown, MoreHorizontal, Globe } from "lucide-react";

export function ActionBar({
  sources,
  sourcesDialog,
}: {
  sources: number;
  sourcesDialog?: React.ReactNode;
}) {
  const Btn = ({ children, label }: { children: React.ReactNode; label: string }) => (
    <button
      aria-label={label}
      className="grid h-8 w-8 place-items-center rounded-full text-muted-foreground hover:bg-accent hover:text-foreground"
    >
      {children}
    </button>
  );
  return (
    <div className="mt-6 flex items-center justify-between border-t border-border pt-3">
      <div className="flex items-center gap-1">
        <Btn label="Share"><Share2 className="h-4 w-4" /></Btn>
        <Btn label="Download"><Download className="h-4 w-4" /></Btn>
        <Btn label="Copy"><Copy className="h-4 w-4" /></Btn>
        <Btn label="Regenerate"><RefreshCw className="h-4 w-4" /></Btn>
        {sourcesDialog ?? (
          <button className="ml-1 inline-flex items-center gap-1.5 rounded-full border border-border px-2.5 py-1 text-xs text-foreground/85 hover:bg-accent">
            <Globe className="h-3.5 w-3.5" />
            {sources} sources
          </button>
        )}
      </div>
      <div className="flex items-center gap-1">
        <Btn label="Like"><ThumbsUp className="h-4 w-4" /></Btn>
        <Btn label="Dislike"><ThumbsDown className="h-4 w-4" /></Btn>
        <Btn label="More"><MoreHorizontal className="h-4 w-4" /></Btn>
      </div>
    </div>
  );
}
