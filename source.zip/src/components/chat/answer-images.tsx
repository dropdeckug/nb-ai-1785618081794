/** Small image references shown beneath a chat answer. */
export function AnswerImages({ images }: { images: string[] }) {
  if (!images || images.length === 0) return null;
  return (
    <section className="mt-6 space-y-2">
      <h3 className="text-xs font-medium text-muted-foreground">References</h3>
      <div className="flex flex-wrap gap-2">
        {images.slice(0, 12).map((src, i) => (
          <a
            key={`${src}-${i}`}
            href={src}
            target="_blank"
            rel="noreferrer"
            className="block h-16 w-16 overflow-hidden rounded-md border border-border bg-muted"
            title="Open reference"
          >
            <img
              src={src}
              alt=""
              loading="lazy"
              className="h-full w-full object-cover transition-transform hover:scale-105"
            />
          </a>
        ))}
      </div>
    </section>
  );
}
