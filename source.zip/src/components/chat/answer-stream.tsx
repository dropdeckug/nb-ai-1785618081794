import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

/**
 * Word-by-word streaming reveal — fast, no flicker, no remount.
 * The container is rendered once and updates its `children` text in place,
 * so ReactMarkdown re-parses incrementally without unmount/mount cycles.
 *
 * `wordsPerTick` controls speed: bigger = faster, can skip several words
 * per frame so very long answers feel near-instant near the end.
 */
export function AnswerStream({
  markdown,
  onComplete,
  scrollContainer,
  wordsPerTick = 4,
  intervalMs = 30,
}: {
  markdown: string;
  onComplete?: () => void;
  scrollContainer?: React.RefObject<HTMLElement | null>;
  wordsPerTick?: number;
  intervalMs?: number;
}) {
  // Split preserving whitespace so layout/markdown structure is preserved.
  const tokens = markdown.match(/\S+\s*|\s+/g) ?? [markdown];
  const [shown, setShown] = useState(0);
  const stickRef = useRef(true);
  const completedRef = useRef(false);

  // Track user scroll to disable auto-scroll if they scrolled up.
  useEffect(() => {
    const el = scrollContainer?.current;
    if (!el) return;
    const onScroll = () => {
      const dist = el.scrollHeight - el.scrollTop - el.clientHeight;
      stickRef.current = dist < 80;
    };
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, [scrollContainer]);

  useEffect(() => {
    setShown(0);
    completedRef.current = false;
  }, [markdown]);

  useEffect(() => {
    if (shown >= tokens.length) {
      if (!completedRef.current) {
        completedRef.current = true;
        onComplete?.();
      }
      return;
    }
    const t = setTimeout(() => {
      setShown((s) => Math.min(s + wordsPerTick, tokens.length));
    }, intervalMs);
    return () => clearTimeout(t);
  }, [shown, tokens.length, onComplete, wordsPerTick, intervalMs]);

  useEffect(() => {
    const el = scrollContainer?.current;
    if (!el || !stickRef.current) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [shown, scrollContainer]);

  const visible = tokens.slice(0, shown).join("");

  return (
    <div className="answer-md text-[15px] leading-7 text-foreground/90">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          h1: ({ node, ...p }) => <h1 className="mt-6 mb-2 text-2xl font-medium tracking-tight" {...p} />,
          h2: ({ node, ...p }) => <h2 className="mt-6 mb-2 text-xl font-medium tracking-tight" {...p} />,
          h3: ({ node, ...p }) => <h3 className="mt-5 mb-2 text-base font-semibold" {...p} />,
          p: ({ node, ...p }) => <p className="my-3" {...p} />,
          ul: ({ node, ...p }) => <ul className="my-3 ml-5 list-disc space-y-1.5" {...p} />,
          ol: ({ node, ...p }) => <ol className="my-3 ml-5 list-decimal space-y-1.5" {...p} />,
          li: ({ node, ...p }) => <li className="pl-1" {...p} />,
          strong: ({ node, ...p }) => <strong className="font-semibold text-foreground" {...p} />,
          a: ({ node, ...p }) => <a className="text-primary hover:underline" {...p} />,
          code: ({ node, ...p }) => <code className="rounded bg-muted px-1 py-0.5 text-[0.85em]" {...p} />,
        }}
      >{visible}</ReactMarkdown>
    </div>
  );
}
