import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

/**
 * Renders a ```chart``` JSON code block emitted by the AI.
 * Shape: { type: "line"|"bar", title?, xKey, yKey, data: [{...}] }
 */
export function ChartBlock({ source }: { source: string }) {
  let cfg: any;
  try {
    cfg = JSON.parse(source);
  } catch {
    return (
      <pre className="rounded-md bg-muted p-3 text-xs text-muted-foreground">
        {source}
      </pre>
    );
  }
  const { type = "line", title, xKey = "x", yKey = "y", data = [] } = cfg;
  if (!Array.isArray(data) || data.length === 0) return null;

  return (
    <figure className="my-4 rounded-lg border border-border bg-card p-3">
      {title && (
        <figcaption className="mb-2 text-xs font-medium text-muted-foreground">
          {title}
        </figcaption>
      )}
      <div className="h-56 w-full">
        <ResponsiveContainer width="100%" height="100%">
          {type === "bar" ? (
            <BarChart data={data} margin={{ left: -12, right: 8, top: 4, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey={xKey} tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey={yKey} fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          ) : (
            <LineChart data={data} margin={{ left: -12, right: 8, top: 4, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey={xKey} tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Line
                type="monotone"
                dataKey={yKey}
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={{ r: 3 }}
              />
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>
    </figure>
  );
}
