import { CornerDownRight, Plus } from "lucide-react";

export function FollowUps({
  items,
  onPick,
}: {
  items: string[];
  onPick: (q: string) => void;
}) {
  return (
    <section className="mt-10">
      <h3 className="text-sm font-medium text-foreground/90">Follow-ups</h3>
      <ul className="mt-3 divide-y divide-border border-y border-border">
        {items.map((q) => (
          <li key={q}>
            <button
              onClick={() => onPick(q)}
              className="group flex w-full items-center justify-between gap-3 py-3 text-left text-sm text-foreground/85 hover:text-foreground"
            >
              <span className="flex items-center gap-3">
                <CornerDownRight className="h-4 w-4 text-muted-foreground" />
                {q}
              </span>
              <Plus className="h-4 w-4 opacity-0 transition-opacity group-hover:opacity-100 text-muted-foreground" />
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}