export function ShinyText({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <span className={`shiny-text font-medium ${className}`}>{children}</span>;
}