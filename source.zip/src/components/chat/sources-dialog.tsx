import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Globe, Package, Wrench, Briefcase, Tag, MessageSquare } from "lucide-react";
import type { PlanItem } from "@/lib/chat.functions";

const ICON: Record<string, typeof Globe> = {
  product: Package,
  service: Wrench,
  job: Briefcase,
  promotion: Tag,
  post: MessageSquare,
};

export function SourcesDialog({
  sources,
  trigger,
}: {
  sources: PlanItem[];
  trigger: React.ReactNode;
}) {
  return (
    <Dialog>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{sources.length} sources from earlymarketug.com</DialogTitle>
        </DialogHeader>
        {sources.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">
            No marketplace sources for this answer.
          </p>
        ) : (
          <ul className="mt-2 divide-y divide-border">
            {sources.map((s) => {
              const Icon = ICON[s.type] ?? Globe;
              return (
                <li key={s.id} className="flex items-start gap-3 py-3">
                  {s.image ? (
                    <img
                      src={s.image}
                      alt=""
                      className="h-12 w-12 shrink-0 rounded-md object-cover"
                      loading="lazy"
                    />
                  ) : (
                    <div className="grid h-12 w-12 shrink-0 place-items-center rounded-md bg-secondary">
                      <Icon className="h-5 w-5 text-muted-foreground" />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium text-foreground">{s.title}</div>
                    <div className="mt-0.5 flex items-center gap-2 text-[11px] text-muted-foreground">
                      <Icon className="h-3 w-3" />
                      <span className="capitalize">{s.type}</span>
                      {s.has_discount && (
                        <span className="rounded-full bg-rose-500/10 px-1.5 py-0.5 text-rose-500">
                          discount
                        </span>
                      )}
                      {s.price != null && (
                        <span>
                          {s.currency || "UGX"} {Number(s.price).toLocaleString()}
                        </span>
                      )}
                      <span className="ml-auto opacity-70">earlymarketug</span>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </DialogContent>
    </Dialog>
  );
}
