import { useEffect, useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  Search,
  Users,
  Package,
  Wrench,
  Briefcase,
  Tag,
  MessageSquare,
  Percent,
  Sparkles,
  CheckCircle2,
} from "lucide-react";
import type { PlanStep, PlanSeller } from "@/lib/chat.functions";
import { ShinyText } from "./shiny-text";
import { Logo } from "@/components/logo";

const KIND_ICON: Record<string, typeof Search> = {
  intent: Search,
  sellers: Users,
  products: Package,
  services: Wrench,
  jobs: Briefcase,
  promotions: Tag,
  posts: MessageSquare,
  discounts: Percent,
  drafting: Sparkles,
};

/** Animated count-up that runs once when `target` becomes known. */
function CountUp({ target, durationMs = 900 }: { target: number; durationMs?: number }) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!target || target <= 0) return setV(target);
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / durationMs);
      const eased = 1 - Math.pow(1 - p, 3);
      setV(Math.round(eased * target));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, durationMs]);
  return <span className="tabular-nums">{v.toLocaleString()}</span>;
}

/** Up to 5 static seller avatars with "+N more" bubble. */
function SellerAvatars({ sellers }: { sellers: PlanSeller[] }) {
  const MAX = 5;
  const visible = sellers.slice(0, MAX);
  const remaining = Math.max(0, sellers.length - visible.length);
  return (
    <div className="flex -space-x-2">
      {visible.map((s, i) => {
        const initials = (s.business_name ?? "?").slice(0, 2).toUpperCase();
        return (
          <div
            key={`${s.user_id}-${i}`}
            title={s.business_name ?? undefined}
            className="relative grid h-7 w-7 place-items-center overflow-hidden rounded-full border-2 border-background bg-secondary text-[10px] font-medium"
          >
            {s.business_logo_url ? (
              <img src={s.business_logo_url} alt="" className="h-full w-full object-cover" />
            ) : (
              <span>{initials}</span>
            )}
            {s.is_verified && (
              <CheckCircle2 className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-background text-sky-500" />
            )}
          </div>
        );
      })}
      {remaining > 0 && (
        <div className="grid h-7 min-w-7 px-1.5 place-items-center rounded-full border-2 border-background bg-secondary text-[10px] font-semibold text-foreground/80">
          +{remaining}
        </div>
      )}
    </div>
  );
}

export function ThinkingTimeline({
  steps,
  done,
  activeIndex,
}: {
  steps: PlanStep[];
  done: boolean;
  activeIndex: number;
}) {
  const [open, setOpen] = useState(true);
  useEffect(() => {
    if (done) setOpen(false);
  }, [done]);

  const activeLabel =
    !done && steps[activeIndex]?.label
      ? steps[activeIndex].label
      : "Thinking";

  return (
    <div className="mb-6">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
      >
        {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        {done ? (
          <span>Completed {steps.length} steps</span>
        ) : (
          <ShinyText>{activeLabel}…</ShinyText>
        )}
      </button>

      {open && (
        <div className="mt-3 ml-2 border-l border-border pl-4 space-y-4">
          {steps.slice(0, activeIndex + 1).map((s, i) => {
            const Icon = KIND_ICON[s.kind] ?? Search;
            const isActive = !done && i === activeIndex;
            return (
              <div key={i} className="fade-up-line">
                <div className="flex items-center gap-2 text-sm">
                  {s.kind === "drafting" ? (
                    <Logo className="h-4 w-4 rounded-sm" />
                  ) : (
                    <Icon
                      className={`h-3.5 w-3.5 ${isActive ? "text-primary" : "text-muted-foreground"}`}
                    />
                  )}
                  {isActive ? (
                    <ShinyText>{s.label}</ShinyText>
                  ) : (
                    <span className="text-foreground/90">{s.label}</span>
                  )}
                  {typeof s.count === "number" && s.count > 0 && (
                    <span className="ml-1 inline-flex items-center rounded-full bg-secondary px-1.5 py-0.5 text-[11px] font-medium text-foreground/80">
                      <CountUp target={s.count} />
                    </span>
                  )}
                </div>

                {s.query && s.kind !== "discounts" && s.kind !== "drafting" && (
                  <div className="mt-2 ml-5 inline-flex items-center gap-2 rounded-md border border-border bg-card px-2.5 py-1 text-xs text-muted-foreground">
                    <Search className="h-3 w-3" />
                    {s.query}
                  </div>
                )}

                {s.sellers && s.sellers.length > 0 && (
                  <div className="mt-2 ml-5">
                    <SellerAvatars sellers={s.sellers} />
                  </div>
                )}

                {s.items && s.items.length > 0 && s.kind !== "discounts" && (
                  <ul className="mt-2 ml-5 space-y-1 text-xs text-muted-foreground">
                    {s.items.slice(0, 3).map((it) => (
                      <li key={it.id} className="truncate">
                        • {it.title}
                      </li>
                    ))}
                    {s.items.length > 3 && (
                      <li className="text-[11px]">+{s.items.length - 3} more</li>
                    )}
                  </ul>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
