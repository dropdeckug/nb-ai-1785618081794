import logoImg from "@/assets/earlymarket-logo.png";
import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <img
      src={logoImg}
      alt="earlyMarket"
      className={cn("h-7 w-7 rounded-md object-contain", className)}
    />
  );
}
