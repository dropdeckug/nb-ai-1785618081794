import { useRef, useState, useEffect } from "react";
import {
  Plus,
  Search,
  Image as ImageIcon,
  ChevronDown,
  Mic,
  AudioLines,
  ArrowUp,
  X,
  FileText,
  Camera,
  Folder,
  Globe,
  GraduationCap,
  FlaskConical,
  Telescope,
  Check,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { VoiceDialog } from "@/components/voice-dialog";
import { useRecorder } from "@/lib/use-recorder";
import { useAuth } from "@/lib/auth";
import { useNavigate } from "@tanstack/react-router";

type ModelOpt = { id: string; label: string; provider: "Google" | "OpenAI"; desc: string };
const MODELS: ModelOpt[] = [
  { id: "gemini-3-flash", label: "Gemini 3 Flash", provider: "Google", desc: "Fast, balanced" },
  { id: "gemini-2.5-pro", label: "Gemini 2.5 Pro", provider: "Google", desc: "Top reasoning" },
  { id: "gemini-2.5-flash", label: "Gemini 2.5 Flash", provider: "Google", desc: "Quick everyday" },
  { id: "gpt-5", label: "GPT-5", provider: "OpenAI", desc: "All-rounder" },
  { id: "gpt-5-mini", label: "GPT-5 Mini", provider: "OpenAI", desc: "Lower cost" },
  { id: "gpt-5-nano", label: "GPT-5 Nano", provider: "OpenAI", desc: "Fastest" },
];

const TOOLS = [
  { id: "search", label: "Search", desc: "Fast answers from the web", icon: Globe },
  { id: "research", label: "Research", desc: "In-depth multi-source", icon: Telescope },
  { id: "academic", label: "Academic", desc: "Papers & journals", icon: GraduationCap },
  { id: "labs", label: "Labs", desc: "Experimental tools", icon: FlaskConical },
];

const ACCEPT = "image/*,application/pdf,.txt,.md,.csv,.json,.docx,.xlsx";

export function SearchComposer({
  onSubmit,
  placeholder = "Type / for search modes and shortcuts",
  autoFocus,
}: {
  onSubmit?: (text: string) => void;
  placeholder?: string;
  autoFocus?: boolean;
}) {
  const [value, setValue] = useState("");
  const { user: authUser } = useAuth();
  const navigate = useNavigate();
  const [files, setFiles] = useState<File[]>([]);
  const [model, setModel] = useState(MODELS[0]);
  const [tool, setTool] = useState(TOOLS[0]);
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);
  const recorder = useRecorder();

  const toggleMic = async () => {
    if (recorder.recording) {
      const text = await recorder.stopAndTranscribe();
      if (text) {
        setValue((v) => {
          const sep = v && !v.endsWith(" ") ? " " : "";
          return (v + sep + text).trim();
        });
        requestAnimationFrame(() => taRef.current?.focus());
      }
    } else {
      recorder.start();
    }
  };

  // auto-grow
  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 220) + "px";
  }, [value]);

  // window-level drag highlight
  useEffect(() => {
    let depth = 0;
    const hasFiles = (e: DragEvent) =>
      Array.from(e.dataTransfer?.types || []).includes("Files");
    const onEnter = (e: DragEvent) => {
      if (!hasFiles(e)) return;
      depth++;
      setDragOver(true);
    };
    const onLeave = () => {
      depth = Math.max(0, depth - 1);
      if (depth === 0) setDragOver(false);
    };
    const onDropWin = (e: DragEvent) => {
      depth = 0;
      setDragOver(false);
      if (!hasFiles(e)) return;
      e.preventDefault();
      if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files);
    };
    const onOver = (e: DragEvent) => {
      if (hasFiles(e)) e.preventDefault();
    };
    window.addEventListener("dragenter", onEnter);
    window.addEventListener("dragleave", onLeave);
    window.addEventListener("dragover", onOver);
    window.addEventListener("drop", onDropWin);
    return () => {
      window.removeEventListener("dragenter", onEnter);
      window.removeEventListener("dragleave", onLeave);
      window.removeEventListener("dragover", onOver);
      window.removeEventListener("drop", onDropWin);
    };
  }, []);

  const submit = () => {
    const v = value.trim();
    if (!v && files.length === 0) return;
    if (!authUser) {
      navigate({ to: "/auth" });
      return;
    }
    onSubmit?.(v);
    setValue("");
    setFiles([]);
  };

  const addFiles = (list: FileList | File[]) => {
    const arr = Array.from(list);
    setFiles((f) => [...f, ...arr].slice(0, 10));
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files);
  };

  return (
    <>
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={(e) => {
          if (e.currentTarget.contains(e.relatedTarget as Node)) return;
          setDragOver(false);
        }}
        onDrop={onDrop}
        className={`relative rounded-2xl border bg-card/70 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.25)] backdrop-blur transition-colors ${
          dragOver ? "border-primary ring-2 ring-primary/40 bg-primary/5" : "border-border"
        }`}
      >
        {dragOver && (
          <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center rounded-2xl bg-primary/5 text-sm font-medium text-primary">
            Drop files to attach
          </div>
        )}

        {files.length > 0 && (
          <div className="flex flex-wrap gap-2 px-4 pt-3">
            {files.map((f, i) => (
              <div
                key={i}
                className="flex items-center gap-2 rounded-lg border border-border bg-secondary/60 py-1.5 pl-2 pr-1 text-xs"
              >
                {f.type.startsWith("image/") ? (
                  <img
                    src={URL.createObjectURL(f)}
                    alt=""
                    className="h-6 w-6 rounded object-cover"
                  />
                ) : (
                  <FileText className="h-4 w-4 text-muted-foreground" />
                )}
                <span className="max-w-[140px] truncate">{f.name}</span>
                <button
                  onClick={() => setFiles((arr) => arr.filter((_, j) => j !== i))}
                  className="grid h-5 w-5 place-items-center rounded hover:bg-accent"
                  aria-label="Remove"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="px-4 pt-3">
          <textarea
            ref={taRef}
            value={value}
            autoFocus={autoFocus}
            rows={1}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                submit();
              }
            }}
            placeholder={placeholder}
            className="w-full resize-none bg-transparent text-[15px] leading-6 text-foreground placeholder:text-muted-foreground/80 outline-none max-h-[220px] overflow-y-auto"
          />
          {(recorder.recording || recorder.transcribing) && (
            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              <RecorderWaves level={recorder.level} active={recorder.recording} />
              <span className="italic text-foreground/70">
                {recorder.transcribing ? "Transcribing…" : "Listening — tap mic to stop"}
              </span>
            </div>
          )}
          {recorder.error && (
            <div className="mt-1 text-xs text-rose-500">{recorder.error}</div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 px-2 sm:px-3 pb-2.5 pt-2.5">
          {/* Plus / add */}
          <button
            onClick={() => setAddOpen(true)}
            className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Add"
          >
            <Plus className="h-4 w-4" />
          </button>

          {/* Tool dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex shrink-0 items-center gap-1.5 rounded-full border border-border bg-secondary/60 px-2.5 sm:px-3 py-1.5 text-xs font-medium hover:bg-secondary">
                <tool.icon className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{tool.label}</span>
                <ChevronDown className="h-3 w-3 opacity-70" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-60">
              <DropdownMenuLabel>Tools</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {TOOLS.map((t) => (
                <DropdownMenuItem
                  key={t.id}
                  onClick={() => setTool(t)}
                  className="flex items-start gap-2"
                >
                  <t.icon className="mt-0.5 h-4 w-4 text-muted-foreground" />
                  <div className="flex-1">
                    <div className="text-sm">{t.label}</div>
                    <div className="text-xs text-muted-foreground">{t.desc}</div>
                  </div>
                  {tool.id === t.id && <Check className="h-4 w-4 text-primary" />}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Image attach shortcut */}
          <button
            onClick={() => fileRef.current?.click()}
            className="hidden sm:grid h-8 w-8 shrink-0 place-items-center rounded-full border border-border text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Image"
          >
            <ImageIcon className="h-3.5 w-3.5" />
          </button>

          <div className="ml-auto flex items-center gap-1 sm:gap-1.5">
            {/* Model dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex shrink-0 items-center gap-1 rounded-full px-2 sm:px-3 py-1.5 text-xs font-medium text-muted-foreground hover:bg-accent hover:text-foreground">
                  <span className="max-w-[88px] sm:max-w-none truncate">{model.label}</span>
                  <ChevronDown className="h-3 w-3 opacity-70" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-72">
                <DropdownMenuLabel>Google</DropdownMenuLabel>
                {MODELS.filter((m) => m.provider === "Google").map((m) => (
                  <ModelItem key={m.id} m={m} active={model.id === m.id} onPick={() => setModel(m)} />
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>OpenAI</DropdownMenuLabel>
                {MODELS.filter((m) => m.provider === "OpenAI").map((m) => (
                  <ModelItem key={m.id} m={m} active={model.id === m.id} onPick={() => setModel(m)} />
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mic — record then transcribe via Lovable AI */}
            <button
              onClick={toggleMic}
              disabled={recorder.transcribing}
              aria-label={recorder.recording ? "Stop recording" : "Start voice transcription"}
              title={recorder.recording ? "Stop & transcribe" : "Record — your speech becomes text"}
              className={`grid h-8 w-8 shrink-0 place-items-center rounded-full transition-colors ${
                recorder.recording
                  ? "bg-rose-500/15 text-rose-500"
                  : "text-muted-foreground hover:bg-accent hover:text-foreground"
              } ${recorder.transcribing ? "opacity-60" : ""}`}
            >
              <Mic className="h-4 w-4" />
            </button>

            {value.trim() || files.length > 0 ? (
              <button
                onClick={submit}
                aria-label="Send"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-foreground text-background hover:opacity-90"
              >
                <ArrowUp className="h-4 w-4" />
              </button>
            ) : (
              <button
                onClick={() => setVoiceOpen(true)}
                aria-label="Voice mode"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-foreground text-background hover:opacity-90"
              >
                <AudioLines className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        <input
          ref={fileRef}
          type="file"
          multiple
          accept={ACCEPT}
          className="hidden"
          onChange={(e) => e.target.files && addFiles(e.target.files)}
        />
        <input
          ref={photoRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => e.target.files && addFiles(e.target.files)}
        />
      </div>

      {/* Add dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Add to message</DialogTitle>
          </DialogHeader>
          <div className="grid gap-2">
            <AddOption
              icon={ImageIcon}
              label="Photos"
              desc="Attach images from your device"
              onClick={() => {
                setAddOpen(false);
                fileRef.current?.click();
              }}
            />
            <AddOption
              icon={Folder}
              label="Files"
              desc="PDFs, docs, spreadsheets"
              onClick={() => {
                setAddOpen(false);
                fileRef.current?.click();
              }}
            />
            <AddOption
              icon={Camera}
              label="Take a photo"
              desc="Capture from camera"
              onClick={() => {
                setAddOpen(false);
                photoRef.current?.click();
              }}
            />
          </div>
        </DialogContent>
      </Dialog>

      <VoiceDialog open={voiceOpen} onClose={() => setVoiceOpen(false)} />
    </>
  );
}

function ModelItem({
  m,
  active,
  onPick,
}: {
  m: ModelOpt;
  active: boolean;
  onPick: () => void;
}) {
  return (
    <DropdownMenuItem onClick={onPick} className="flex items-start gap-2">
      <div className="flex-1">
        <div className="text-sm">{m.label}</div>
        <div className="text-xs text-muted-foreground">{m.desc}</div>
      </div>
      {active && <Check className="h-4 w-4 text-primary" />}
    </DropdownMenuItem>
  );
}

function AddOption({
  icon: Icon,
  label,
  desc,
  onClick,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  desc: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 rounded-lg border border-border p-3 text-left hover:bg-accent"
    >
      <div className="grid h-9 w-9 place-items-center rounded-md bg-secondary text-foreground">
        <Icon className="h-4 w-4" />
      </div>
      <div className="flex-1">
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
    </button>
  );
}

function RecorderWaves({ level, active }: { level: number; active: boolean }) {
  // 12 animated bars whose height responds to mic level
  const bars = Array.from({ length: 14 });
  const amp = Math.min(1, level * 6);
  return (
    <div className="flex h-5 items-end gap-[3px]">
      {bars.map((_, i) => {
        const phase = (i / bars.length) * Math.PI * 2;
        const wobble = (Math.sin(Date.now() / 140 + phase) + 1) / 2;
        const h = active ? 3 + amp * 16 * (0.4 + wobble * 0.6) : 3;
        return (
          <span
            key={i}
            className="w-[3px] rounded-full bg-rose-500 transition-[height] duration-75"
            style={{ height: `${h}px` }}
          />
        );
      })}
    </div>
  );
}
