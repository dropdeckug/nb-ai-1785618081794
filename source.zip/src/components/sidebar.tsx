import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  Plus,
  Monitor,
  LayoutGrid,
  Settings2,
  History,
  PanelLeft,
  Bell,
  ArrowUpCircle,
  MessageSquare,
  Trash2,
  LogIn,
  LogOut,
  CheckCircle2,
  Image as ImageIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Logo } from "./logo";
import { useAuth } from "@/lib/auth";
import { useConversations } from "@/lib/use-conversations";

const items = [
  { title: "New", url: "/", icon: Plus },
  { title: "Images", url: "/images", icon: ImageIcon },
  { title: "Computer", url: "/computer", icon: Monitor },
  { title: "Spaces", url: "/spaces", icon: LayoutGrid },
  { title: "Customise", url: "/customise", icon: Settings2 },
  { title: "History", url: "/history", icon: History },
];

export function Sidebar({
  collapsed,
  onToggle,
}: {
  collapsed: boolean;
  onToggle: () => void;
}) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const { user, business, signOut } = useAuth();
  const { items: convs, remove } = useConversations();

  return (
    <aside
      className={cn(
        "flex h-screen sticky top-0 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-[width] duration-200",
        collapsed ? "w-16" : "w-60",
      )}
    >
      {/* Brand row */}
      <div className="flex h-14 items-center justify-between px-3">
        <Link to="/" className="flex items-center gap-2 min-w-0">
          <Logo className="h-7 w-7 shrink-0" />
          {!collapsed && (
            <span className="truncate text-sm font-medium tracking-tight">
              earlymarket AI
            </span>
          )}
        </Link>
        <button
          onClick={onToggle}
          className="grid h-8 w-8 place-items-center rounded-md text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
          aria-label="Toggle sidebar"
        >
          <PanelLeft className="h-4 w-4" />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-2">
        <ul className="space-y-1">
          {items.map((it) => {
            const active = path === it.url;
            return (
              <li key={it.title}>
                <Link
                  to={it.url}
                  className={cn(
                    "group flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                    active
                      ? "bg-sidebar-accent text-sidebar-foreground"
                      : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                    collapsed && "justify-center px-0",
                  )}
                >
                  <it.icon className="h-[18px] w-[18px] shrink-0" />
                  {!collapsed && <span className="truncate">{it.title}</span>}
                </Link>
              </li>
            );
          })}
        </ul>

        {!collapsed && user && convs.length > 0 && (
          <div className="mt-6">
            <p className="px-3 pb-1 text-[10px] font-medium uppercase tracking-wider text-sidebar-foreground/50">
              Chats
            </p>
            <ul className="space-y-0.5">
              {convs.map((c) => {
                const url = `/ask/${c.id}`;
                const active = path === url;
                return (
                  <li key={c.id} className="group/conv relative">
                    <Link
                      to="/ask/$threadId"
                      params={{ threadId: c.id }}
                      className={cn(
                        "flex items-center gap-2 rounded-md px-3 py-1.5 pr-8 text-xs transition-colors",
                        active
                          ? "bg-sidebar-accent text-sidebar-foreground"
                          : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                      )}
                    >
                      <MessageSquare className="h-3 w-3 shrink-0 opacity-60" />
                      <span className="truncate">{c.title || "New chat"}</span>
                    </Link>
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        remove(c.id);
                        if (active) navigate({ to: "/" });
                      }}
                      className="absolute right-1.5 top-1/2 hidden -translate-y-1/2 rounded p-1 text-sidebar-foreground/60 hover:bg-destructive/15 hover:text-destructive group-hover/conv:block"
                      aria-label="Delete chat"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        )}

        {!collapsed && !user && (
          <div className="mt-6 px-2">
            <p className="px-2 text-xs text-sidebar-foreground/50">
              Sign in to save your chats and unlock business insights.
            </p>
          </div>
        )}
      </nav>

      {/* Footer */}
      <div className="border-t border-sidebar-border p-2">
        {!collapsed && !user && (
          <Link
            to="/auth"
            className="mb-2 flex w-full items-center justify-center gap-2 rounded-full border border-sidebar-border bg-sidebar-accent/50 px-3 py-1.5 text-xs font-medium hover:bg-sidebar-accent"
          >
            <LogIn className="h-3.5 w-3.5" />
            Sign in
          </Link>
        )}
        {!collapsed && user && !business && (
          <button className="mb-2 flex w-full items-center justify-center gap-2 rounded-full border border-sidebar-border bg-sidebar-accent/50 px-3 py-1.5 text-xs font-medium hover:bg-sidebar-accent">
            <ArrowUpCircle className="h-3.5 w-3.5 text-brand" />
            Become a seller
          </button>
        )}
        <div
          className={cn(
            "flex items-center gap-2 rounded-md px-2 py-1.5",
            collapsed && "justify-center",
          )}
        >
          {business?.business_logo_url ? (
            <img
              src={business.business_logo_url}
              alt={business.business_name ?? ""}
              className="h-7 w-7 shrink-0 rounded-full object-cover"
            />
          ) : (
            <div className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand to-primary text-[11px] font-semibold text-brand-foreground">
              {(user?.email ?? "g")[0].toUpperCase()}
            </div>
          )}
          {!collapsed && (
            <>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1 truncate text-sm">
                  {business?.business_name ?? user?.email?.split("@")[0] ?? "Guest"}
                  {business?.is_verified && (
                    <CheckCircle2 className="h-3 w-3 shrink-0 text-sky-500" />
                  )}
                </div>
                {business && (
                  <div className="truncate text-[10px] text-sidebar-foreground/60">
                    Business account
                  </div>
                )}
              </div>
              {user ? (
                <button
                  onClick={signOut}
                  className="text-sidebar-foreground/60 hover:text-sidebar-foreground"
                  aria-label="Sign out"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              ) : (
                <Bell className="h-4 w-4 text-sidebar-foreground/60" />
              )}
            </>
          )}
        </div>
      </div>
    </aside>
  );
}
