import { cn } from "@/lib/utils";

export function Shimmer({ className }: { className?: string }) {
  return <div className={cn("shimmer", className)} aria-hidden="true" />;
}

export function TextLines({
  lines = 3,
  className,
}: {
  lines?: number;
  className?: string;
}) {
  return (
    <div className={cn("space-y-2", className)}>
      {Array.from({ length: lines }).map((_, i) => (
        <Shimmer key={i} className={cn("h-3", i === lines - 1 && "w-2/3")} />
      ))}
    </div>
  );
}

export function FeedSkeleton() {
  return (
    <div className="space-y-6">
      <article className="grid gap-5 md:grid-cols-[1fr_320px]">
        <div className="space-y-3">
          <Shimmer className="h-7 w-5/6" />
          <Shimmer className="h-7 w-3/4" />
          <Shimmer className="h-3 w-32" />
          <div className="space-y-2 pt-2">
            <Shimmer className="h-3" />
            <Shimmer className="h-3 w-11/12" />
            <Shimmer className="h-3 w-2/3" />
          </div>
        </div>
        <Shimmer className="h-48 w-full rounded-xl" />
      </article>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="space-y-3">
            <Shimmer className="h-40 w-full rounded-xl" />
            <Shimmer className="h-4 w-11/12" />
            <Shimmer className="h-4 w-3/4" />
            <Shimmer className="h-3 w-20" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function CardGridSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="rounded-xl border border-border bg-card p-4 space-y-3"
        >
          <Shimmer className="h-32 w-full rounded-lg" />
          <Shimmer className="h-4 w-5/6" />
          <Shimmer className="h-3 w-2/3" />
          <div className="flex items-center gap-2 pt-1">
            <Shimmer className="h-6 w-6 rounded-full" />
            <Shimmer className="h-3 w-24" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function ChartSkeleton() {
  return (
    <div className="rounded-xl border border-border bg-card p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Shimmer className="h-5 w-40" />
          <Shimmer className="h-3 w-24" />
        </div>
        <Shimmer className="h-7 w-20 rounded-full" />
      </div>
      <Shimmer className="h-64 w-full rounded-lg" />
      <div className="grid grid-cols-3 gap-3">
        <Shimmer className="h-12" />
        <Shimmer className="h-12" />
        <Shimmer className="h-12" />
      </div>
    </div>
  );
}