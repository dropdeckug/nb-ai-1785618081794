import { Link, useRouterState } from "@tanstack/react-router";
import { Share2, Sun, Moon, Bell, Menu, LogIn } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTheme } from "@/lib/theme";
import { useAuth } from "@/lib/auth";

const tabs = [
  { label: "Discover", to: "/discover" },
  { label: "Products", to: "/products" },
  { label: "Services", to: "/services" },
  { label: "Jobs", to: "/jobs" },
  { label: "Events", to: "/events" },
  { label: "Insights", to: "/insights" },
];

export function TopNav({ onOpenMobile }: { onOpenMobile?: () => void }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { theme, setTheme } = useTheme();
  const { user, business } = useAuth();

  return (
    <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-border bg-background/80 px-3 sm:px-4 backdrop-blur">
      <button
        onClick={onOpenMobile}
        className="grid h-8 w-8 place-items-center rounded-full border border-border bg-secondary/60 hover:bg-secondary md:hidden"
        aria-label="Open menu"
      >
        <Menu className="h-4 w-4" />
      </button>
      <nav className="hidden md:flex ml-2 flex-1 items-center justify-center gap-7 overflow-x-auto">
        {tabs.map((t) => {
          const active = path === t.to;
          return (
            <Link
              key={t.to}
              to={t.to}
              className={cn(
                "relative text-sm transition-colors py-4",
                active
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {t.label}
              {active && (
                <span className="absolute -bottom-px left-1/2 h-0.5 w-6 -translate-x-1/2 rounded-full bg-foreground" />
              )}
            </Link>
          );
        })}
      </nav>

      <nav className="md:hidden flex-1 flex items-center gap-4 overflow-x-auto no-scrollbar">
        {tabs.map((t) => {
          const active = path === t.to;
          return (
            <Link
              key={t.to}
              to={t.to}
              className={cn(
                "shrink-0 text-xs py-3",
                active ? "text-foreground font-medium" : "text-muted-foreground",
              )}
            >
              {t.label}
            </Link>
          );
        })}
      </nav>
      <div className="ml-auto flex items-center gap-2">
        {!user ? (
          <Link
            to="/auth"
            className="flex items-center gap-1.5 rounded-full bg-foreground px-3 py-1.5 text-xs font-medium text-background hover:opacity-90"
          >
            <LogIn className="h-3.5 w-3.5" />
            Sign in
          </Link>
        ) : (
          <button className="hidden sm:flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-xs font-medium hover:bg-secondary">
            <Share2 className="h-3.5 w-3.5" />
            {business?.business_name ? "Share store" : "Share"}
          </button>
        )}
        <button
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="grid h-8 w-8 place-items-center rounded-full border border-border bg-secondary/60 hover:bg-secondary"
          aria-label="Toggle theme"
        >
          {theme === "dark" ? (
            <Sun className="h-4 w-4" />
          ) : (
            <Moon className="h-4 w-4" />
          )}
        </button>
        <button
          className="grid h-8 w-8 place-items-center rounded-full border border-border bg-secondary/60 hover:bg-secondary"
          aria-label="Notifications"
        >
          <Bell className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}