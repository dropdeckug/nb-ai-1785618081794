import { useEffect, useRef, useState } from "react";
import { X, Phone } from "lucide-react";
import { useSpeech } from "@/lib/use-speech";

type Phase = "idle" | "listening" | "thinking" | "speaking";

export function VoiceDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const levelRef = useRef(0);
  const [phase, setPhase] = useState<Phase>("idle");
  const [transcript, setTranscript] = useState("");
  const [reply, setReply] = useState("");
  const [error, setError] = useState<string | null>(null);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const ttsTimerRef = useRef<number | null>(null);
  const silenceTimerRef = useRef<number | null>(null);
  const pendingRef = useRef<string>("");
  const busyRef = useRef(false);

  // Send accumulated transcript to AI, then TTS the reply
  const sendToAI = async (text: string) => {
    if (!text.trim() || busyRef.current) return;
    busyRef.current = true;
    setPhase("thinking");
    setTranscript(text);
    try {
      const cRes = await fetch("/api/voice-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: text }),
      });
      if (!cRes.ok) {
        const j = await cRes.json().catch(() => ({}));
        throw new Error(j.error || `AI failed (${cRes.status})`);
      }
      const { text: answer } = (await cRes.json()) as { text: string };
      setReply(answer);

      setPhase("speaking");
      const sRes = await fetch("/api/speak", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: answer, voice: "alloy" }),
      });
      if (!sRes.ok) {
        const t = await sRes.text().catch(() => "");
        throw new Error(`Voice failed: ${t.slice(0, 120)}`);
      }
      const buf = await sRes.arrayBuffer();
      const url = URL.createObjectURL(new Blob([buf], { type: "audio/mpeg" }));
      const audio = new Audio(url);
      audioElRef.current = audio;
      ttsTimerRef.current = window.setInterval(() => {
        levelRef.current = 0.05 + Math.random() * 0.2;
      }, 100);
      await new Promise<void>((resolve) => {
        audio.onended = () => resolve();
        audio.onerror = () => resolve();
        audio.play().catch(() => resolve());
      });
      if (ttsTimerRef.current) {
        clearInterval(ttsTimerRef.current);
        ttsTimerRef.current = null;
      }
      levelRef.current = 0;
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Voice error");
    } finally {
      busyRef.current = false;
      setPhase("listening");
    }
  };

  const speech = useSpeech({
    onInterim: (t) => {
      pendingRef.current = t;
      setTranscript(t);
      // Reset silence timer on new speech
      if (silenceTimerRef.current) {
        clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = null;
      }
      silenceTimerRef.current = window.setTimeout(() => {
        const text = pendingRef.current.trim();
        if (text.length > 1 && !busyRef.current) {
          pendingRef.current = "";
          sendToAI(text);
        }
      }, 1400);
    },
    onFinal: (t) => {
      pendingRef.current = (pendingRef.current + " " + t).trim();
    },
  });

  // Mic stream + level meter
  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    let analyser: AnalyserNode | null = null;
    let dataArr: Uint8Array | null = null;

    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const Ctx: typeof AudioContext =
          window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new Ctx();
        audioCtxRef.current = ctx;
        const source = ctx.createMediaStreamSource(stream);
        analyser = ctx.createAnalyser();
        analyser.fftSize = 512;
        source.connect(analyser);
        dataArr = new Uint8Array(analyser.frequencyBinCount);

        const tick = () => {
          if (!analyser || !dataArr) return;
          analyser.getByteTimeDomainData(dataArr as any);
          let sum = 0;
          for (let i = 0; i < dataArr.length; i++) {
            const v = (dataArr[i] - 128) / 128;
            sum += v * v;
          }
          const rms = Math.sqrt(sum / dataArr.length);
          if (phase !== "speaking") {
            levelRef.current = levelRef.current * 0.78 + rms * 0.22;
          }
          rafRef.current = requestAnimationFrame(tick);
        };
        tick();

        // Start speech recognition
        if (speech.supported) {
          speech.start();
          setPhase("listening");
        } else {
          setError("Voice input not supported in this browser. Use Chrome or Edge.");
        }
      } catch {
        setError("Microphone blocked. Allow microphone access and reload.");
      }
    })();

    return () => {
      cancelled = true;
      speech.stop();
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
      audioCtxRef.current?.close().catch(() => {});
      streamRef.current = null;
      audioCtxRef.current = null;
      levelRef.current = 0;
      if (audioElRef.current) {
        audioElRef.current.pause();
        audioElRef.current = null;
      }
      if (ttsTimerRef.current) {
        clearInterval(ttsTimerRef.current);
        ttsTimerRef.current = null;
      }
      pendingRef.current = "";
      busyRef.current = false;
      setPhase("idle");
      setTranscript("");
      setReply("");
      setError(null);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // Particle ball
  useEffect(() => {
    if (!open) return;
    const canvas = canvasRef.current!;
    const ctx2 = canvas.getContext("2d")!;
    const dpr = window.devicePixelRatio || 1;

    const resize = () => {
      const size = Math.min(window.innerWidth, window.innerHeight) * 0.85;
      canvas.width = size * dpr;
      canvas.height = size * dpr;
      canvas.style.width = `${size}px`;
      canvas.style.height = `${size}px`;
    };
    resize();
    window.addEventListener("resize", resize);

    type P = { theta: number; phi: number; r: number; vTheta: number; vPhi: number; size: number; tint: number };
    const N = 1100;
    const particles: P[] = Array.from({ length: N }, () => ({
      theta: Math.random() * Math.PI * 2,
      phi: Math.acos(2 * Math.random() - 1),
      r: 0.55 + Math.random() * 0.45,
      vTheta: (Math.random() - 0.5) * 0.004,
      vPhi: (Math.random() - 0.5) * 0.003,
      size: Math.random() * 1.4 + 0.4,
      tint: Math.random(),
    }));

    let raf = 0;
    const draw = () => {
      const w = canvas.width, h = canvas.height;
      ctx2.clearRect(0, 0, w, h);
      const cx = w / 2, cy = h / 2;
      const lvl = Math.min(1, levelRef.current * 5);
      const baseR = Math.min(w, h) * 0.32;
      const radius = baseR * (1 + lvl * 0.18);

      const g1 = ctx2.createRadialGradient(cx, cy, radius * 0.1, cx, cy, radius * 1.6);
      g1.addColorStop(0, `rgba(180,200,255,${0.05 + lvl * 0.07})`);
      g1.addColorStop(0.5, `rgba(255,255,255,${0.02 + lvl * 0.03})`);
      g1.addColorStop(1, "rgba(255,255,255,0)");
      ctx2.fillStyle = g1;
      ctx2.beginPath();
      ctx2.arc(cx, cy, radius * 1.6, 0, Math.PI * 2);
      ctx2.fill();

      ctx2.globalCompositeOperation = "lighter";
      for (const p of particles) {
        p.theta += p.vTheta + 0.0008;
        p.phi += p.vPhi;
        if (p.phi < 0) p.phi += Math.PI;
        if (p.phi > Math.PI) p.phi -= Math.PI;
        const sinPhi = Math.sin(p.phi);
        const x3 = sinPhi * Math.cos(p.theta);
        const y3 = Math.cos(p.phi);
        const z3 = sinPhi * Math.sin(p.theta);
        const depth = (z3 + 1) / 2;
        const px = cx + x3 * p.r * radius;
        const py = cy + y3 * p.r * radius;
        const sz = p.size * dpr * (0.55 + depth * 0.9) * (0.95 + lvl * 0.4);
        const alpha = 0.18 + depth * 0.75;
        const r8 = 235 + Math.round(p.tint * 20);
        const g8 = 240 + Math.round((1 - p.tint) * 15);
        const b8 = 255;
        const halo = ctx2.createRadialGradient(px, py, 0, px, py, sz * 3);
        halo.addColorStop(0, `rgba(${r8},${g8},${b8},${alpha})`);
        halo.addColorStop(1, `rgba(${r8},${g8},${b8},0)`);
        ctx2.fillStyle = halo;
        ctx2.beginPath();
        ctx2.arc(px, py, sz * 3, 0, Math.PI * 2);
        ctx2.fill();
        ctx2.fillStyle = `rgba(255,255,255,${Math.min(1, alpha + 0.15)})`;
        ctx2.beginPath();
        ctx2.arc(px, py, sz, 0, Math.PI * 2);
        ctx2.fill();
      }
      ctx2.globalCompositeOperation = "source-over";
      raf = requestAnimationFrame(draw);
    };
    draw();
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const status = error
    ? error
    : phase === "listening" ? "Listening… speak naturally"
    : phase === "thinking" ? "Thinking…"
    : phase === "speaking" ? "Speaking…"
    : "Connecting…";

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background/95 backdrop-blur-xl animate-fade-in">
      <div className="flex-1 flex items-center justify-center w-full">
        <canvas ref={canvasRef} className="block" />
      </div>
      <div className="pb-12 sm:pb-16 flex flex-col items-center gap-4 max-w-xl px-6 text-center">
        {transcript && (
          <p className="text-sm text-foreground/70 italic line-clamp-2">"{transcript}"</p>
        )}
        {reply && phase === "speaking" && (
          <p className="text-sm text-foreground line-clamp-3">{reply}</p>
        )}
        <p className={`text-sm sm:text-base ${error ? "text-rose-500" : "text-primary/90"}`}>
          {status}
        </p>
        <button
          onClick={onClose}
          aria-label="End call"
          className="grid h-16 w-16 place-items-center rounded-full bg-rose-500 text-white hover:bg-rose-600 transition-colors"
        >
          <Phone className="h-6 w-6 rotate-[135deg]" />
        </button>
      </div>
      <button
        onClick={onClose}
        className="absolute top-4 right-4 grid h-10 w-10 place-items-center rounded-full bg-secondary/70 hover:bg-secondary"
        aria-label="Close"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
