export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.12 (cd3cf9e)"
  }
  public: {
    Tables: {
      activity_logs: {
        Row: {
          activity_type: string
          created_at: string
          description: string
          id: string
          ip_address: unknown
          metadata: Json | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          activity_type: string
          created_at?: string
          description: string
          id?: string
          ip_address?: unknown
          metadata?: Json | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          activity_type?: string
          created_at?: string
          description?: string
          id?: string
          ip_address?: unknown
          metadata?: Json | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      ad_images: {
        Row: {
          ad_id: string
          alt_text: string | null
          created_at: string
          id: string
          image_order: number
          image_url: string
        }
        Insert: {
          ad_id: string
          alt_text?: string | null
          created_at?: string
          id?: string
          image_order?: number
          image_url: string
        }
        Update: {
          ad_id?: string
          alt_text?: string | null
          created_at?: string
          id?: string
          image_order?: number
          image_url?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_ad_images_ad_id"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_invite_codes: {
        Row: {
          code: string
          created_at: string
          created_by: string | null
          expires_at: string | null
          id: string
          is_active: boolean
          max_uses: number
          updated_at: string
          uses: number
        }
        Insert: {
          code: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_uses?: number
          updated_at?: string
          uses?: number
        }
        Update: {
          code?: string
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_uses?: number
          updated_at?: string
          uses?: number
        }
        Relationships: []
      }
      admin_roles: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          permissions: Json
          role_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          permissions?: Json
          role_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          permissions?: Json
          role_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      admins: {
        Row: {
          added_by: string | null
          admin_role_id: string
          created_at: string
          id: string
          is_active: boolean
          last_login: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          added_by?: string | null
          admin_role_id: string
          created_at?: string
          id?: string
          is_active?: boolean
          last_login?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          added_by?: string | null
          admin_role_id?: string
          created_at?: string
          id?: string
          is_active?: boolean
          last_login?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_admins_admin_role_id"
            columns: ["admin_role_id"]
            isOneToOne: false
            referencedRelation: "admin_roles"
            referencedColumns: ["id"]
          },
        ]
      }
      ads: {
        Row: {
          accepts_quotes: boolean
          ai_category_suggestion: string | null
          ai_quality_score: number | null
          allow_comments: boolean | null
          b2_video_url: string | null
          boost_expires_at: string | null
          brand: string | null
          category: string
          color: string | null
          condition: string | null
          created_at: string
          currency: string | null
          description: string | null
          dimensions: string | null
          embedding: string | null
          engagement_score: number | null
          expires_at: string | null
          features: string | null
          followers_count: number
          fraud_risk_score: number | null
          fraud_score: number | null
          has_discount: boolean | null
          id: string
          image_embedding: string | null
          images: string[] | null
          inventory_count: number | null
          is_boosted: boolean | null
          is_price_negotiable: boolean | null
          is_sponsored: boolean | null
          last_update_at: string | null
          listing_type: string | null
          location: string
          media_dimensions: Json | null
          media_duration: number | null
          model: string | null
          original_price: number | null
          pickup_available: boolean | null
          price: number | null
          save_count: number | null
          search_vector: unknown
          seller_id: string
          shipping_options: Json | null
          size: string | null
          sponsored_until: string | null
          status: string
          subcategory: string | null
          tags: string[] | null
          testimonials_count: number
          tiktok_url: string | null
          title: string
          update_count: number
          updated_at: string
          video_height: number | null
          video_thumbnail_url: string | null
          video_width: number | null
          view_count: number | null
          visibility: string | null
          warranty: string | null
          weight: string | null
          year_manufactured: number | null
          youtube_url: string | null
        }
        Insert: {
          accepts_quotes?: boolean
          ai_category_suggestion?: string | null
          ai_quality_score?: number | null
          allow_comments?: boolean | null
          b2_video_url?: string | null
          boost_expires_at?: string | null
          brand?: string | null
          category: string
          color?: string | null
          condition?: string | null
          created_at?: string
          currency?: string | null
          description?: string | null
          dimensions?: string | null
          embedding?: string | null
          engagement_score?: number | null
          expires_at?: string | null
          features?: string | null
          followers_count?: number
          fraud_risk_score?: number | null
          fraud_score?: number | null
          has_discount?: boolean | null
          id?: string
          image_embedding?: string | null
          images?: string[] | null
          inventory_count?: number | null
          is_boosted?: boolean | null
          is_price_negotiable?: boolean | null
          is_sponsored?: boolean | null
          last_update_at?: string | null
          listing_type?: string | null
          location: string
          media_dimensions?: Json | null
          media_duration?: number | null
          model?: string | null
          original_price?: number | null
          pickup_available?: boolean | null
          price?: number | null
          save_count?: number | null
          search_vector?: unknown
          seller_id: string
          shipping_options?: Json | null
          size?: string | null
          sponsored_until?: string | null
          status?: string
          subcategory?: string | null
          tags?: string[] | null
          testimonials_count?: number
          tiktok_url?: string | null
          title: string
          update_count?: number
          updated_at?: string
          video_height?: number | null
          video_thumbnail_url?: string | null
          video_width?: number | null
          view_count?: number | null
          visibility?: string | null
          warranty?: string | null
          weight?: string | null
          year_manufactured?: number | null
          youtube_url?: string | null
        }
        Update: {
          accepts_quotes?: boolean
          ai_category_suggestion?: string | null
          ai_quality_score?: number | null
          allow_comments?: boolean | null
          b2_video_url?: string | null
          boost_expires_at?: string | null
          brand?: string | null
          category?: string
          color?: string | null
          condition?: string | null
          created_at?: string
          currency?: string | null
          description?: string | null
          dimensions?: string | null
          embedding?: string | null
          engagement_score?: number | null
          expires_at?: string | null
          features?: string | null
          followers_count?: number
          fraud_risk_score?: number | null
          fraud_score?: number | null
          has_discount?: boolean | null
          id?: string
          image_embedding?: string | null
          images?: string[] | null
          inventory_count?: number | null
          is_boosted?: boolean | null
          is_price_negotiable?: boolean | null
          is_sponsored?: boolean | null
          last_update_at?: string | null
          listing_type?: string | null
          location?: string
          media_dimensions?: Json | null
          media_duration?: number | null
          model?: string | null
          original_price?: number | null
          pickup_available?: boolean | null
          price?: number | null
          save_count?: number | null
          search_vector?: unknown
          seller_id?: string
          shipping_options?: Json | null
          size?: string | null
          sponsored_until?: string | null
          status?: string
          subcategory?: string | null
          tags?: string[] | null
          testimonials_count?: number
          tiktok_url?: string | null
          title?: string
          update_count?: number
          updated_at?: string
          video_height?: number | null
          video_thumbnail_url?: string | null
          video_width?: number | null
          view_count?: number | null
          visibility?: string | null
          warranty?: string | null
          weight?: string | null
          year_manufactured?: number | null
          youtube_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ads_listing_type_fkey"
            columns: ["listing_type"]
            isOneToOne: false
            referencedRelation: "listing_types"
            referencedColumns: ["name"]
          },
          {
            foreignKeyName: "ads_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ads_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_image_rate_limits: {
        Row: {
          count: number
          user_id: string
          window_start: string
        }
        Insert: {
          count?: number
          user_id: string
          window_start: string
        }
        Update: {
          count?: number
          user_id?: string
          window_start?: string
        }
        Relationships: []
      }
      algorithm_settings: {
        Row: {
          created_at: string
          description: string | null
          id: string
          setting_key: string
          setting_value: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          setting_key: string
          setting_value: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          setting_key?: string
          setting_value?: Json
          updated_at?: string
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          description: string | null
          key: string
          updated_at: string | null
          updated_by: string | null
          value: Json
        }
        Insert: {
          description?: string | null
          key: string
          updated_at?: string | null
          updated_by?: string | null
          value: Json
        }
        Update: {
          description?: string | null
          key?: string
          updated_at?: string | null
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      app_support_links: {
        Row: {
          created_at: string | null
          icon: string | null
          id: string
          is_active: boolean | null
          label: string
          link_type: string
          sort_order: number | null
          updated_at: string | null
          value: string
        }
        Insert: {
          created_at?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          label: string
          link_type: string
          sort_order?: number | null
          updated_at?: string | null
          value: string
        }
        Update: {
          created_at?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          label?: string
          link_type?: string
          sort_order?: number | null
          updated_at?: string | null
          value?: string
        }
        Relationships: []
      }
      app_update_control: {
        Row: {
          app_store_url: string | null
          id: string
          is_forced: boolean
          latest_version: string
          min_version: string
          play_store_url: string | null
          release_notes: string | null
          released_at: string | null
          updated_at: string | null
          updated_by: string | null
        }
        Insert: {
          app_store_url?: string | null
          id?: string
          is_forced?: boolean
          latest_version?: string
          min_version?: string
          play_store_url?: string | null
          release_notes?: string | null
          released_at?: string | null
          updated_at?: string | null
          updated_by?: string | null
        }
        Update: {
          app_store_url?: string | null
          id?: string
          is_forced?: boolean
          latest_version?: string
          min_version?: string
          play_store_url?: string | null
          release_notes?: string | null
          released_at?: string | null
          updated_at?: string | null
          updated_by?: string | null
        }
        Relationships: []
      }
      app_version_requirements: {
        Row: {
          created_at: string | null
          description: string | null
          display_name: string | null
          feature_name: string
          id: string
          is_enforced: boolean | null
          min_version: string
          tier: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          display_name?: string | null
          feature_name: string
          id?: string
          is_enforced?: boolean | null
          min_version: string
          tier?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          display_name?: string | null
          feature_name?: string
          id?: string
          is_enforced?: boolean | null
          min_version?: string
          tier?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      applications: {
        Row: {
          applicant_email: string
          applicant_name: string
          applicant_phone: string | null
          cover_letter: string | null
          created_at: string
          id: string
          job_ad_id: string
          notes: string | null
          resume_url: string
          reviewed_at: string | null
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          applicant_email: string
          applicant_name: string
          applicant_phone?: string | null
          cover_letter?: string | null
          created_at?: string
          id?: string
          job_ad_id: string
          notes?: string | null
          resume_url: string
          reviewed_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          applicant_email?: string
          applicant_name?: string
          applicant_phone?: string | null
          cover_letter?: string | null
          created_at?: string
          id?: string
          job_ad_id?: string
          notes?: string | null
          resume_url?: string
          reviewed_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "applications_job_ad_id_fkey"
            columns: ["job_ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string
          id: string
          ip_address: unknown
          new_values: Json | null
          old_values: Json | null
          record_id: string | null
          table_name: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          ip_address?: unknown
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          ip_address?: unknown
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      b2_deletion_queue: {
        Row: {
          attempts: number
          created_at: string
          file_url: string
          id: string
          last_error: string | null
          status: string
          updated_at: string
        }
        Insert: {
          attempts?: number
          created_at?: string
          file_url: string
          id?: string
          last_error?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          attempts?: number
          created_at?: string
          file_url?: string
          id?: string
          last_error?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      banned_users: {
        Row: {
          ban_type: string
          banned_by: string
          banned_until: string | null
          created_at: string
          id: string
          is_active: boolean
          reason: string
          updated_at: string
          user_id: string
        }
        Insert: {
          ban_type?: string
          banned_by: string
          banned_until?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          reason: string
          updated_at?: string
          user_id: string
        }
        Update: {
          ban_type?: string
          banned_by?: string
          banned_until?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          reason?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      blocked_users: {
        Row: {
          blocked_user_id: string
          blocker_user_id: string
          created_at: string
          id: string
        }
        Insert: {
          blocked_user_id: string
          blocker_user_id: string
          created_at?: string
          id?: string
        }
        Update: {
          blocked_user_id?: string
          blocker_user_id?: string
          created_at?: string
          id?: string
        }
        Relationships: []
      }
      bookmarks: {
        Row: {
          created_at: string
          id: string
          item_id: string
          item_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          item_id: string
          item_type?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          item_id?: string
          item_type?: string
          user_id?: string
        }
        Relationships: []
      }
      boost_plans: {
        Row: {
          base_price_per_day: number
          created_at: string
          description: string | null
          display_name: string
          features: Json | null
          gradient_from: string | null
          gradient_to: string | null
          icon: string | null
          id: string
          is_active: boolean | null
          is_popular: boolean | null
          multiplier: number
          name: string
          sort_order: number | null
          updated_at: string
          visibility_multiplier: number | null
        }
        Insert: {
          base_price_per_day: number
          created_at?: string
          description?: string | null
          display_name: string
          features?: Json | null
          gradient_from?: string | null
          gradient_to?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          is_popular?: boolean | null
          multiplier?: number
          name: string
          sort_order?: number | null
          updated_at?: string
          visibility_multiplier?: number | null
        }
        Update: {
          base_price_per_day?: number
          created_at?: string
          description?: string | null
          display_name?: string
          features?: Json | null
          gradient_from?: string | null
          gradient_to?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          is_popular?: boolean | null
          multiplier?: number
          name?: string
          sort_order?: number | null
          updated_at?: string
          visibility_multiplier?: number | null
        }
        Relationships: []
      }
      boost_pricing_config: {
        Row: {
          description: string | null
          id: string
          key: string
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          description?: string | null
          id?: string
          key: string
          updated_at?: string
          updated_by?: string | null
          value: Json
        }
        Update: {
          description?: string | null
          id?: string
          key?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      boost_requests: {
        Row: {
          ad_id: string
          amount_paid: number
          boost_type: string
          created_at: string
          currency: string
          duration_days: number
          id: string
          review_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          ad_id: string
          amount_paid: number
          boost_type?: string
          created_at?: string
          currency?: string
          duration_days: number
          id?: string
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          ad_id?: string
          amount_paid?: number
          boost_type?: string
          created_at?: string
          currency?: string
          duration_days?: number
          id?: string
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "boost_requests_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      boosts: {
        Row: {
          ad_id: string
          amount_paid: number
          boost_end: string
          boost_start: string
          boost_type: string
          created_at: string
          currency: string
          id: string
          is_active: boolean
          payment_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          ad_id: string
          amount_paid: number
          boost_end: string
          boost_start?: string
          boost_type: string
          created_at?: string
          currency?: string
          id?: string
          is_active?: boolean
          payment_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          ad_id?: string
          amount_paid?: number
          boost_end?: string
          boost_start?: string
          boost_type?: string
          created_at?: string
          currency?: string
          id?: string
          is_active?: boolean
          payment_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_boosts_ad_id"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_boosts_payment_id"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payments"
            referencedColumns: ["id"]
          },
        ]
      }
      brands: {
        Row: {
          category: string
          created_at: string | null
          id: string
          is_popular: boolean | null
          logo_url: string | null
          name: string
        }
        Insert: {
          category: string
          created_at?: string | null
          id?: string
          is_popular?: boolean | null
          logo_url?: string | null
          name: string
        }
        Update: {
          category?: string
          created_at?: string | null
          id?: string
          is_popular?: boolean | null
          logo_url?: string | null
          name?: string
        }
        Relationships: []
      }
      business_visits: {
        Row: {
          created_at: string
          district: string | null
          id: string
          region: string | null
          seller_id: string
          session_id: string
          source: string
          visitor_user_id: string | null
        }
        Insert: {
          created_at?: string
          district?: string | null
          id?: string
          region?: string | null
          seller_id: string
          session_id: string
          source?: string
          visitor_user_id?: string | null
        }
        Update: {
          created_at?: string
          district?: string | null
          id?: string
          region?: string | null
          seller_id?: string
          session_id?: string
          source?: string
          visitor_user_id?: string | null
        }
        Relationships: []
      }
      categories: {
        Row: {
          created_at: string
          description: string | null
          icon: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      category_field_mappings: {
        Row: {
          created_at: string
          display_order: number | null
          field_name: string
          field_options: Json | null
          field_type: string
          id: string
          is_required: boolean
          listing_type: string
          validation_rules: Json | null
        }
        Insert: {
          created_at?: string
          display_order?: number | null
          field_name: string
          field_options?: Json | null
          field_type: string
          id?: string
          is_required?: boolean
          listing_type: string
          validation_rules?: Json | null
        }
        Update: {
          created_at?: string
          display_order?: number | null
          field_name?: string
          field_options?: Json | null
          field_type?: string
          id?: string
          is_required?: boolean
          listing_type?: string
          validation_rules?: Json | null
        }
        Relationships: []
      }
      changelogs: {
        Row: {
          changes: Json
          created_at: string
          description: string | null
          id: string
          is_major: boolean | null
          release_date: string
          title: string
          version: string
        }
        Insert: {
          changes?: Json
          created_at?: string
          description?: string | null
          id?: string
          is_major?: boolean | null
          release_date?: string
          title: string
          version: string
        }
        Update: {
          changes?: Json
          created_at?: string
          description?: string | null
          id?: string
          is_major?: boolean | null
          release_date?: string
          title?: string
          version?: string
        }
        Relationships: []
      }
      comment_likes: {
        Row: {
          comment_id: string
          created_at: string | null
          id: string
          user_id: string
        }
        Insert: {
          comment_id: string
          created_at?: string | null
          id?: string
          user_id: string
        }
        Update: {
          comment_id?: string
          created_at?: string | null
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "comment_likes_comment_id_fkey"
            columns: ["comment_id"]
            isOneToOne: false
            referencedRelation: "comments"
            referencedColumns: ["id"]
          },
        ]
      }
      comments: {
        Row: {
          content: string
          content_id: string
          content_type: string
          created_at: string | null
          id: string
          like_count: number | null
          parent_comment_id: string | null
          reply_count: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          content: string
          content_id: string
          content_type: string
          created_at?: string | null
          id?: string
          like_count?: number | null
          parent_comment_id?: string | null
          reply_count?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          content?: string
          content_id?: string
          content_type?: string
          created_at?: string | null
          id?: string
          like_count?: number | null
          parent_comment_id?: string | null
          reply_count?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "comments_parent_comment_id_fkey"
            columns: ["parent_comment_id"]
            isOneToOne: false
            referencedRelation: "comments"
            referencedColumns: ["id"]
          },
        ]
      }
      content_clicks: {
        Row: {
          click_type: string
          content_id: string
          content_type: string
          created_at: string
          district: string | null
          id: string
          region: string | null
          source_page: string
          user_id: string | null
        }
        Insert: {
          click_type: string
          content_id: string
          content_type: string
          created_at?: string
          district?: string | null
          id?: string
          region?: string | null
          source_page?: string
          user_id?: string | null
        }
        Update: {
          click_type?: string
          content_id?: string
          content_type?: string
          created_at?: string
          district?: string | null
          id?: string
          region?: string | null
          source_page?: string
          user_id?: string | null
        }
        Relationships: []
      }
      content_engagements: {
        Row: {
          content_id: string
          content_type: string
          created_at: string
          district: string | null
          engagement_type: string
          id: string
          region: string | null
          session_id: string | null
          user_id: string
        }
        Insert: {
          content_id: string
          content_type: string
          created_at?: string
          district?: string | null
          engagement_type?: string
          id?: string
          region?: string | null
          session_id?: string | null
          user_id: string
        }
        Update: {
          content_id?: string
          content_type?: string
          created_at?: string
          district?: string | null
          engagement_type?: string
          id?: string
          region?: string | null
          session_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      content_views: {
        Row: {
          content_id: string
          content_type: string
          created_at: string
          district: string | null
          id: string
          region: string | null
          session_id: string | null
          source_page: string
          user_id: string | null
          view_duration_seconds: number | null
        }
        Insert: {
          content_id: string
          content_type: string
          created_at?: string
          district?: string | null
          id?: string
          region?: string | null
          session_id?: string | null
          source_page?: string
          user_id?: string | null
          view_duration_seconds?: number | null
        }
        Update: {
          content_id?: string
          content_type?: string
          created_at?: string
          district?: string | null
          id?: string
          region?: string | null
          session_id?: string | null
          source_page?: string
          user_id?: string | null
          view_duration_seconds?: number | null
        }
        Relationships: []
      }
      dashboard_stats: {
        Row: {
          created_at: string
          date_recorded: string
          id: string
          stat_name: string
          stat_value: Json
        }
        Insert: {
          created_at?: string
          date_recorded?: string
          id?: string
          stat_name: string
          stat_value: Json
        }
        Update: {
          created_at?: string
          date_recorded?: string
          id?: string
          stat_name?: string
          stat_value?: Json
        }
        Relationships: []
      }
      device_tokens: {
        Row: {
          app_version: string | null
          created_at: string
          id: string
          last_seen_at: string
          platform: string
          token: string
          user_id: string
        }
        Insert: {
          app_version?: string | null
          created_at?: string
          id?: string
          last_seen_at?: string
          platform?: string
          token: string
          user_id: string
        }
        Update: {
          app_version?: string | null
          created_at?: string
          id?: string
          last_seen_at?: string
          platform?: string
          token?: string
          user_id?: string
        }
        Relationships: []
      }
      digital_product_details: {
        Row: {
          ad_id: string
          created_at: string
          download_count: number | null
          file_size: string | null
          file_type: string | null
          id: string
          license_type: string | null
          preview_urls: string[] | null
          supported_platforms: string[] | null
          system_requirements: string | null
          updated_at: string
          version: string | null
        }
        Insert: {
          ad_id: string
          created_at?: string
          download_count?: number | null
          file_size?: string | null
          file_type?: string | null
          id?: string
          license_type?: string | null
          preview_urls?: string[] | null
          supported_platforms?: string[] | null
          system_requirements?: string | null
          updated_at?: string
          version?: string | null
        }
        Update: {
          ad_id?: string
          created_at?: string
          download_count?: number | null
          file_size?: string | null
          file_type?: string | null
          id?: string
          license_type?: string | null
          preview_urls?: string[] | null
          supported_platforms?: string[] | null
          system_requirements?: string | null
          updated_at?: string
          version?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "digital_product_details_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      districts: {
        Row: {
          country: string
          created_at: string
          id: string
          name: string
          region: string
          slug: string
          updated_at: string
        }
        Insert: {
          country?: string
          created_at?: string
          id?: string
          name: string
          region: string
          slug: string
          updated_at?: string
        }
        Update: {
          country?: string
          created_at?: string
          id?: string
          name?: string
          region?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      emi_conversations: {
        Row: {
          created_at: string
          id: string
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      emi_messages: {
        Row: {
          charts: Json | null
          content: string
          conversation_id: string
          created_at: string
          id: string
          role: string
        }
        Insert: {
          charts?: Json | null
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          role: string
        }
        Update: {
          charts?: Json | null
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "emi_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "emi_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          activities_schedule: Json | null
          age_restriction: string | null
          allow_comments: boolean | null
          b2_video_url: string | null
          category: string
          contact_email: string | null
          contact_phone: string | null
          cover_image: string | null
          created_at: string | null
          current_attendees: number | null
          daily_schedule: Json | null
          description: string
          dress_code: string | null
          emergency_contact: string | null
          end_date: string | null
          event_date: string
          event_status: string | null
          external_ticket_url: string | null
          facebook_url: string | null
          food_drinks_info: string | null
          gallery: Json | null
          google_map_link: string | null
          id: string
          images: string[] | null
          instagram_url: string | null
          is_active: boolean | null
          is_free: boolean | null
          is_hybrid: boolean | null
          is_multi_day: boolean | null
          is_online: boolean | null
          lineup: Json | null
          location: string
          max_attendees: number | null
          media_dimensions: Json | null
          media_duration: number | null
          not_allowed: string | null
          official_website: string | null
          organizer_name: string | null
          organizer_type: string | null
          price_range_max: number | null
          price_range_min: number | null
          refund_policy: string | null
          registration_url: string | null
          safety_notes: string | null
          seller_id: string | null
          spotify_url: string | null
          streaming_url: string | null
          tagline: string | null
          tags: string[] | null
          ticket_button_label: string | null
          ticket_currency: string | null
          ticket_price: number | null
          ticket_tiers: Json | null
          ticket_type: string | null
          tiktok_url: string | null
          timezone: string | null
          title: string
          updated_at: string | null
          user_id: string
          venue_address: string | null
          venue_name: string | null
          video_height: number | null
          video_thumbnail_url: string | null
          video_url: string | null
          video_width: number | null
          view_count: number | null
          visibility: string | null
          what_to_bring: string | null
          whatsapp_contact: string | null
          youtube_url: string | null
        }
        Insert: {
          activities_schedule?: Json | null
          age_restriction?: string | null
          allow_comments?: boolean | null
          b2_video_url?: string | null
          category: string
          contact_email?: string | null
          contact_phone?: string | null
          cover_image?: string | null
          created_at?: string | null
          current_attendees?: number | null
          daily_schedule?: Json | null
          description: string
          dress_code?: string | null
          emergency_contact?: string | null
          end_date?: string | null
          event_date: string
          event_status?: string | null
          external_ticket_url?: string | null
          facebook_url?: string | null
          food_drinks_info?: string | null
          gallery?: Json | null
          google_map_link?: string | null
          id?: string
          images?: string[] | null
          instagram_url?: string | null
          is_active?: boolean | null
          is_free?: boolean | null
          is_hybrid?: boolean | null
          is_multi_day?: boolean | null
          is_online?: boolean | null
          lineup?: Json | null
          location: string
          max_attendees?: number | null
          media_dimensions?: Json | null
          media_duration?: number | null
          not_allowed?: string | null
          official_website?: string | null
          organizer_name?: string | null
          organizer_type?: string | null
          price_range_max?: number | null
          price_range_min?: number | null
          refund_policy?: string | null
          registration_url?: string | null
          safety_notes?: string | null
          seller_id?: string | null
          spotify_url?: string | null
          streaming_url?: string | null
          tagline?: string | null
          tags?: string[] | null
          ticket_button_label?: string | null
          ticket_currency?: string | null
          ticket_price?: number | null
          ticket_tiers?: Json | null
          ticket_type?: string | null
          tiktok_url?: string | null
          timezone?: string | null
          title: string
          updated_at?: string | null
          user_id: string
          venue_address?: string | null
          venue_name?: string | null
          video_height?: number | null
          video_thumbnail_url?: string | null
          video_url?: string | null
          video_width?: number | null
          view_count?: number | null
          visibility?: string | null
          what_to_bring?: string | null
          whatsapp_contact?: string | null
          youtube_url?: string | null
        }
        Update: {
          activities_schedule?: Json | null
          age_restriction?: string | null
          allow_comments?: boolean | null
          b2_video_url?: string | null
          category?: string
          contact_email?: string | null
          contact_phone?: string | null
          cover_image?: string | null
          created_at?: string | null
          current_attendees?: number | null
          daily_schedule?: Json | null
          description?: string
          dress_code?: string | null
          emergency_contact?: string | null
          end_date?: string | null
          event_date?: string
          event_status?: string | null
          external_ticket_url?: string | null
          facebook_url?: string | null
          food_drinks_info?: string | null
          gallery?: Json | null
          google_map_link?: string | null
          id?: string
          images?: string[] | null
          instagram_url?: string | null
          is_active?: boolean | null
          is_free?: boolean | null
          is_hybrid?: boolean | null
          is_multi_day?: boolean | null
          is_online?: boolean | null
          lineup?: Json | null
          location?: string
          max_attendees?: number | null
          media_dimensions?: Json | null
          media_duration?: number | null
          not_allowed?: string | null
          official_website?: string | null
          organizer_name?: string | null
          organizer_type?: string | null
          price_range_max?: number | null
          price_range_min?: number | null
          refund_policy?: string | null
          registration_url?: string | null
          safety_notes?: string | null
          seller_id?: string | null
          spotify_url?: string | null
          streaming_url?: string | null
          tagline?: string | null
          tags?: string[] | null
          ticket_button_label?: string | null
          ticket_currency?: string | null
          ticket_price?: number | null
          ticket_tiers?: Json | null
          ticket_type?: string | null
          tiktok_url?: string | null
          timezone?: string | null
          title?: string
          updated_at?: string | null
          user_id?: string
          venue_address?: string | null
          venue_name?: string | null
          video_height?: number | null
          video_thumbnail_url?: string | null
          video_url?: string | null
          video_width?: number | null
          view_count?: number | null
          visibility?: string | null
          what_to_bring?: string | null
          whatsapp_contact?: string | null
          youtube_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "events_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "events_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      featured_ads: {
        Row: {
          ad_id: string
          created_at: string
          featured_type: string
          featured_until: string
          id: string
          priority: number
        }
        Insert: {
          ad_id: string
          created_at?: string
          featured_type?: string
          featured_until: string
          id?: string
          priority?: number
        }
        Update: {
          ad_id?: string
          created_at?: string
          featured_type?: string
          featured_until?: string
          id?: string
          priority?: number
        }
        Relationships: [
          {
            foreignKeyName: "fk_featured_ads_ad_id"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      featured_sellers: {
        Row: {
          created_at: string
          featured_by: string | null
          featured_until: string | null
          id: string
          is_active: boolean | null
          reason: string | null
          seller_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          featured_by?: string | null
          featured_until?: string | null
          id?: string
          is_active?: boolean | null
          reason?: string | null
          seller_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          featured_by?: string | null
          featured_until?: string | null
          id?: string
          is_active?: boolean | null
          reason?: string | null
          seller_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "featured_sellers_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "featured_sellers_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      feedback: {
        Row: {
          admin_notes: string | null
          category: string | null
          contact_phone: string | null
          created_at: string
          email: string | null
          feedback_type: string
          id: string
          message: string
          rating: number | null
          status: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          admin_notes?: string | null
          category?: string | null
          contact_phone?: string | null
          created_at?: string
          email?: string | null
          feedback_type: string
          id?: string
          message: string
          rating?: number | null
          status?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          admin_notes?: string | null
          category?: string | null
          contact_phone?: string | null
          created_at?: string
          email?: string | null
          feedback_type?: string
          id?: string
          message?: string
          rating?: number | null
          status?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      follows: {
        Row: {
          created_at: string | null
          follower_id: string
          following_id: string
          id: string
        }
        Insert: {
          created_at?: string | null
          follower_id: string
          following_id: string
          id?: string
        }
        Update: {
          created_at?: string | null
          follower_id?: string
          following_id?: string
          id?: string
        }
        Relationships: []
      }
      job_details: {
        Row: {
          about_company: string | null
          ad_id: string
          age_range_max: number | null
          age_range_min: number | null
          allow_direct_calls: boolean | null
          allow_sharing: boolean | null
          applicant_count: number | null
          application_deadline: string | null
          apply_method: string | null
          benefits: string | null
          campaign_overview: string | null
          campaign_title: string | null
          company_address: string | null
          company_industry: string | null
          company_logo_url: string | null
          company_name: string
          company_website: string | null
          contact_email: string | null
          contact_phone: string | null
          cover_letter_required: boolean | null
          created_at: string
          cv_required: boolean | null
          education_level: string | null
          employment_duration: string | null
          enable_applicant_counter: boolean | null
          enable_reporting: boolean | null
          enable_view_counter: boolean | null
          experience_required: string | null
          external_application_url: string | null
          gender_preference: string | null
          id: string
          job_level: string | null
          job_posting_type: string | null
          job_type: string
          location_type: string | null
          number_of_positions: number | null
          payment_frequency: string | null
          pdf_attachments: string[] | null
          positions: Json | null
          promo_video_thumbnail_url: string | null
          promo_video_url: string | null
          required_documents: string[] | null
          requirements: string | null
          responsibilities: string | null
          salary_currency: string | null
          salary_max: number | null
          salary_min: number | null
          salary_type: string | null
          show_salary: boolean | null
          skills_required: string[] | null
          tags: string[] | null
          updated_at: string
          use_earlymarket_system: boolean | null
          work_location: string | null
          workplace_images: string[] | null
        }
        Insert: {
          about_company?: string | null
          ad_id: string
          age_range_max?: number | null
          age_range_min?: number | null
          allow_direct_calls?: boolean | null
          allow_sharing?: boolean | null
          applicant_count?: number | null
          application_deadline?: string | null
          apply_method?: string | null
          benefits?: string | null
          campaign_overview?: string | null
          campaign_title?: string | null
          company_address?: string | null
          company_industry?: string | null
          company_logo_url?: string | null
          company_name: string
          company_website?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          cover_letter_required?: boolean | null
          created_at?: string
          cv_required?: boolean | null
          education_level?: string | null
          employment_duration?: string | null
          enable_applicant_counter?: boolean | null
          enable_reporting?: boolean | null
          enable_view_counter?: boolean | null
          experience_required?: string | null
          external_application_url?: string | null
          gender_preference?: string | null
          id?: string
          job_level?: string | null
          job_posting_type?: string | null
          job_type: string
          location_type?: string | null
          number_of_positions?: number | null
          payment_frequency?: string | null
          pdf_attachments?: string[] | null
          positions?: Json | null
          promo_video_thumbnail_url?: string | null
          promo_video_url?: string | null
          required_documents?: string[] | null
          requirements?: string | null
          responsibilities?: string | null
          salary_currency?: string | null
          salary_max?: number | null
          salary_min?: number | null
          salary_type?: string | null
          show_salary?: boolean | null
          skills_required?: string[] | null
          tags?: string[] | null
          updated_at?: string
          use_earlymarket_system?: boolean | null
          work_location?: string | null
          workplace_images?: string[] | null
        }
        Update: {
          about_company?: string | null
          ad_id?: string
          age_range_max?: number | null
          age_range_min?: number | null
          allow_direct_calls?: boolean | null
          allow_sharing?: boolean | null
          applicant_count?: number | null
          application_deadline?: string | null
          apply_method?: string | null
          benefits?: string | null
          campaign_overview?: string | null
          campaign_title?: string | null
          company_address?: string | null
          company_industry?: string | null
          company_logo_url?: string | null
          company_name?: string
          company_website?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          cover_letter_required?: boolean | null
          created_at?: string
          cv_required?: boolean | null
          education_level?: string | null
          employment_duration?: string | null
          enable_applicant_counter?: boolean | null
          enable_reporting?: boolean | null
          enable_view_counter?: boolean | null
          experience_required?: string | null
          external_application_url?: string | null
          gender_preference?: string | null
          id?: string
          job_level?: string | null
          job_posting_type?: string | null
          job_type?: string
          location_type?: string | null
          number_of_positions?: number | null
          payment_frequency?: string | null
          pdf_attachments?: string[] | null
          positions?: Json | null
          promo_video_thumbnail_url?: string | null
          promo_video_url?: string | null
          required_documents?: string[] | null
          requirements?: string | null
          responsibilities?: string | null
          salary_currency?: string | null
          salary_max?: number | null
          salary_min?: number | null
          salary_type?: string | null
          show_salary?: boolean | null
          skills_required?: string[] | null
          tags?: string[] | null
          updated_at?: string
          use_earlymarket_system?: boolean | null
          work_location?: string | null
          workplace_images?: string[] | null
        }
        Relationships: [
          {
            foreignKeyName: "job_details_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          parent_id: string | null
          slug: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          parent_id?: string | null
          slug: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          parent_id?: string | null
          slug?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "knowledge_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_chunks: {
        Row: {
          chunk_index: number
          content: string
          created_at: string
          document_id: string
          embedding: string | null
          id: string
          metadata: Json
          token_count: number | null
          version_id: string | null
        }
        Insert: {
          chunk_index: number
          content: string
          created_at?: string
          document_id: string
          embedding?: string | null
          id?: string
          metadata?: Json
          token_count?: number | null
          version_id?: string | null
        }
        Update: {
          chunk_index?: number
          content?: string
          created_at?: string
          document_id?: string
          embedding?: string | null
          id?: string
          metadata?: Json
          token_count?: number | null
          version_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_chunks_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "knowledge_chunks_version_id_fkey"
            columns: ["version_id"]
            isOneToOne: false
            referencedRelation: "knowledge_document_versions"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_document_tags: {
        Row: {
          document_id: string
          tag_id: string
        }
        Insert: {
          document_id: string
          tag_id: string
        }
        Update: {
          document_id?: string
          tag_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_document_tags_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "knowledge_document_tags_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "knowledge_tags"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_document_versions: {
        Row: {
          body_markdown: string
          change_note: string | null
          created_at: string
          created_by: string | null
          document_id: string
          id: string
          title: string
          version: number
        }
        Insert: {
          body_markdown: string
          change_note?: string | null
          created_at?: string
          created_by?: string | null
          document_id: string
          id?: string
          title: string
          version: number
        }
        Update: {
          body_markdown?: string
          change_note?: string | null
          created_at?: string
          created_by?: string | null
          document_id?: string
          id?: string
          title?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_document_versions_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_documents: {
        Row: {
          category_id: string | null
          created_at: string
          created_by: string | null
          id: string
          is_official: boolean
          language: string
          published_at: string | null
          slug: string
          source: string
          status: string
          summary: string | null
          title: string
          updated_at: string
          updated_by: string | null
          version: number
          visibility: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_official?: boolean
          language?: string
          published_at?: string | null
          slug: string
          source?: string
          status?: string
          summary?: string | null
          title: string
          updated_at?: string
          updated_by?: string | null
          version?: number
          visibility?: string
        }
        Update: {
          category_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_official?: boolean
          language?: string
          published_at?: string | null
          slug?: string
          source?: string
          status?: string
          summary?: string | null
          title?: string
          updated_at?: string
          updated_by?: string | null
          version?: number
          visibility?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_documents_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "knowledge_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_query_logs: {
        Row: {
          app_id: string | null
          block_reason: string | null
          blocked: boolean
          created_at: string
          id: string
          latency_ms: number | null
          matched_chunk_ids: string[] | null
          query: string
          user_id: string | null
        }
        Insert: {
          app_id?: string | null
          block_reason?: string | null
          blocked?: boolean
          created_at?: string
          id?: string
          latency_ms?: number | null
          matched_chunk_ids?: string[] | null
          query: string
          user_id?: string | null
        }
        Update: {
          app_id?: string | null
          block_reason?: string | null
          blocked?: boolean
          created_at?: string
          id?: string
          latency_ms?: number | null
          matched_chunk_ids?: string[] | null
          query?: string
          user_id?: string | null
        }
        Relationships: []
      }
      knowledge_tags: {
        Row: {
          created_at: string
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      listing_types: {
        Row: {
          created_at: string
          description: string | null
          display_name: string
          icon: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          display_name: string
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          display_name?: string
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      locations: {
        Row: {
          city: string | null
          country: string
          created_at: string
          id: string
          is_active: boolean
          latitude: number | null
          longitude: number | null
          name: string
          postal_code: string | null
          state: string | null
          updated_at: string
        }
        Insert: {
          city?: string | null
          country: string
          created_at?: string
          id?: string
          is_active?: boolean
          latitude?: number | null
          longitude?: number | null
          name: string
          postal_code?: string | null
          state?: string | null
          updated_at?: string
        }
        Update: {
          city?: string | null
          country?: string
          created_at?: string
          id?: string
          is_active?: boolean
          latitude?: number | null
          longitude?: number | null
          name?: string
          postal_code?: string | null
          state?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          ad_id: string | null
          attachment_type: string | null
          attachment_url: string | null
          content: string
          created_at: string
          deleted_at: string | null
          deleted_for: string[] | null
          id: string
          is_read: boolean
          is_voice_message: boolean | null
          location_data: Json | null
          message_duration: number | null
          message_type: string
          parent_message_id: string | null
          recipient_id: string
          sender_id: string
          subject: string | null
          updated_at: string
          voice_recording_url: string | null
        }
        Insert: {
          ad_id?: string | null
          attachment_type?: string | null
          attachment_url?: string | null
          content: string
          created_at?: string
          deleted_at?: string | null
          deleted_for?: string[] | null
          id?: string
          is_read?: boolean
          is_voice_message?: boolean | null
          location_data?: Json | null
          message_duration?: number | null
          message_type?: string
          parent_message_id?: string | null
          recipient_id: string
          sender_id: string
          subject?: string | null
          updated_at?: string
          voice_recording_url?: string | null
        }
        Update: {
          ad_id?: string | null
          attachment_type?: string | null
          attachment_url?: string | null
          content?: string
          created_at?: string
          deleted_at?: string | null
          deleted_for?: string[] | null
          id?: string
          is_read?: boolean
          is_voice_message?: boolean | null
          location_data?: Json | null
          message_duration?: number | null
          message_type?: string
          parent_message_id?: string | null
          recipient_id?: string
          sender_id?: string
          subject?: string | null
          updated_at?: string
          voice_recording_url?: string | null
        }
        Relationships: []
      }
      moderation_logs: {
        Row: {
          action_type: string
          created_at: string
          details: Json | null
          id: string
          moderator_id: string
          reason: string | null
          target_id: string
          target_type: string
        }
        Insert: {
          action_type: string
          created_at?: string
          details?: Json | null
          id?: string
          moderator_id: string
          reason?: string | null
          target_id: string
          target_type: string
        }
        Update: {
          action_type?: string
          created_at?: string
          details?: Json | null
          id?: string
          moderator_id?: string
          reason?: string | null
          target_id?: string
          target_type?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          action_url: string | null
          created_at: string
          expires_at: string | null
          id: string
          is_read: boolean
          message: string
          metadata: Json | null
          notification_type: string
          push_sent_at: string | null
          title: string
          user_id: string
        }
        Insert: {
          action_url?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_read?: boolean
          message: string
          metadata?: Json | null
          notification_type?: string
          push_sent_at?: string | null
          title: string
          user_id: string
        }
        Update: {
          action_url?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_read?: boolean
          message?: string
          metadata?: Json | null
          notification_type?: string
          push_sent_at?: string | null
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      official_announcements: {
        Row: {
          announcement_type: string | null
          attachments: string[] | null
          content: string
          created_at: string | null
          expiry_date: string | null
          id: string
          images: string[] | null
          is_active: boolean | null
          organization_id: string | null
          priority: string | null
          publish_date: string | null
          seller_id: string | null
          share_count: number | null
          title: string
          updated_at: string | null
          user_id: string
          view_count: number | null
        }
        Insert: {
          announcement_type?: string | null
          attachments?: string[] | null
          content: string
          created_at?: string | null
          expiry_date?: string | null
          id?: string
          images?: string[] | null
          is_active?: boolean | null
          organization_id?: string | null
          priority?: string | null
          publish_date?: string | null
          seller_id?: string | null
          share_count?: number | null
          title: string
          updated_at?: string | null
          user_id: string
          view_count?: number | null
        }
        Update: {
          announcement_type?: string | null
          attachments?: string[] | null
          content?: string
          created_at?: string | null
          expiry_date?: string | null
          id?: string
          images?: string[] | null
          is_active?: boolean | null
          organization_id?: string | null
          priority?: string | null
          publish_date?: string | null
          seller_id?: string | null
          share_count?: number | null
          title?: string
          updated_at?: string | null
          user_id?: string
          view_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "official_announcements_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organization_registrations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "official_announcements_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "official_announcements_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      org_staff_members: {
        Row: {
          accepted_at: string | null
          created_at: string | null
          email: string
          id: string
          invited_at: string | null
          invited_by: string | null
          is_active: boolean | null
          organization_registration_id: string
          permissions: Json | null
          role: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          accepted_at?: string | null
          created_at?: string | null
          email: string
          id?: string
          invited_at?: string | null
          invited_by?: string | null
          is_active?: boolean | null
          organization_registration_id: string
          permissions?: Json | null
          role?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          accepted_at?: string | null
          created_at?: string | null
          email?: string
          id?: string
          invited_at?: string | null
          invited_by?: string | null
          is_active?: boolean | null
          organization_registration_id?: string
          permissions?: Json | null
          role?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "org_staff_members_organization_registration_id_fkey"
            columns: ["organization_registration_id"]
            isOneToOne: false
            referencedRelation: "organization_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      organization_registrations: {
        Row: {
          authorization_letter_url: string
          contact_person_email: string
          contact_person_name: string
          contact_person_phone: string
          contact_person_title: string
          created_at: string | null
          district: string
          email_verification_sent_at: string | null
          email_verification_token: string | null
          email_verified: boolean | null
          id: string
          incorporation_date: string | null
          org_logo_url: string | null
          organization_name: string
          organization_type: string
          physical_address: string
          postal_address: string | null
          registration_certificate_url: string
          registration_number: string
          rejection_reason: string | null
          seller_profile_id: string | null
          tax_certificate_url: string | null
          tin_number: string | null
          updated_at: string | null
          user_id: string
          verification_badge_color: string | null
          verification_status: string | null
          verified_at: string | null
          verified_by: string | null
          website_url: string | null
        }
        Insert: {
          authorization_letter_url: string
          contact_person_email: string
          contact_person_name: string
          contact_person_phone: string
          contact_person_title: string
          created_at?: string | null
          district: string
          email_verification_sent_at?: string | null
          email_verification_token?: string | null
          email_verified?: boolean | null
          id?: string
          incorporation_date?: string | null
          org_logo_url?: string | null
          organization_name: string
          organization_type: string
          physical_address: string
          postal_address?: string | null
          registration_certificate_url: string
          registration_number: string
          rejection_reason?: string | null
          seller_profile_id?: string | null
          tax_certificate_url?: string | null
          tin_number?: string | null
          updated_at?: string | null
          user_id: string
          verification_badge_color?: string | null
          verification_status?: string | null
          verified_at?: string | null
          verified_by?: string | null
          website_url?: string | null
        }
        Update: {
          authorization_letter_url?: string
          contact_person_email?: string
          contact_person_name?: string
          contact_person_phone?: string
          contact_person_title?: string
          created_at?: string | null
          district?: string
          email_verification_sent_at?: string | null
          email_verification_token?: string | null
          email_verified?: boolean | null
          id?: string
          incorporation_date?: string | null
          org_logo_url?: string | null
          organization_name?: string
          organization_type?: string
          physical_address?: string
          postal_address?: string | null
          registration_certificate_url?: string
          registration_number?: string
          rejection_reason?: string | null
          seller_profile_id?: string | null
          tax_certificate_url?: string | null
          tin_number?: string | null
          updated_at?: string | null
          user_id?: string
          verification_badge_color?: string | null
          verification_status?: string | null
          verified_at?: string | null
          verified_by?: string | null
          website_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "organization_registrations_seller_profile_id_fkey"
            columns: ["seller_profile_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "organization_registrations_seller_profile_id_fkey"
            columns: ["seller_profile_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      partnership_requests: {
        Row: {
          application_count: number | null
          benefits_offered: string | null
          contact_email: string | null
          contact_phone: string | null
          created_at: string | null
          deadline: string | null
          description: string
          id: string
          is_active: boolean | null
          organization_id: string | null
          partnership_type: string | null
          requirements: string | null
          seller_id: string | null
          status: string | null
          title: string
          updated_at: string | null
          user_id: string
          view_count: number | null
        }
        Insert: {
          application_count?: number | null
          benefits_offered?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string | null
          deadline?: string | null
          description: string
          id?: string
          is_active?: boolean | null
          organization_id?: string | null
          partnership_type?: string | null
          requirements?: string | null
          seller_id?: string | null
          status?: string | null
          title: string
          updated_at?: string | null
          user_id: string
          view_count?: number | null
        }
        Update: {
          application_count?: number | null
          benefits_offered?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string | null
          deadline?: string | null
          description?: string
          id?: string
          is_active?: boolean | null
          organization_id?: string | null
          partnership_type?: string | null
          requirements?: string | null
          seller_id?: string | null
          status?: string | null
          title?: string
          updated_at?: string | null
          user_id?: string
          view_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "partnership_requests_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organization_registrations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "partnership_requests_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "partnership_requests_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_providers: {
        Row: {
          config: Json | null
          created_at: string
          description: string | null
          display_name: string
          id: string
          is_active: boolean | null
          logo_url: string | null
          name: string
          provider_type: string
          sort_order: number | null
          updated_at: string
        }
        Insert: {
          config?: Json | null
          created_at?: string
          description?: string | null
          display_name: string
          id?: string
          is_active?: boolean | null
          logo_url?: string | null
          name: string
          provider_type: string
          sort_order?: number | null
          updated_at?: string
        }
        Update: {
          config?: Json | null
          created_at?: string
          description?: string | null
          display_name?: string
          id?: string
          is_active?: boolean | null
          logo_url?: string | null
          name?: string
          provider_type?: string
          sort_order?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      payment_transactions: {
        Row: {
          ad_id: string | null
          amount: number
          callback_data: Json | null
          callback_received: boolean | null
          completed_at: string | null
          created_at: string | null
          currency: string
          error_message: string | null
          expires_at: string | null
          id: string
          initiated_at: string | null
          metadata: Json | null
          payment_method: string | null
          payment_provider: Database["public"]["Enums"]["payment_provider"]
          payment_type: string
          provider_reference: string | null
          provider_transaction_id: string | null
          status: Database["public"]["Enums"]["payment_status_enum"]
          subscription_id: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          ad_id?: string | null
          amount: number
          callback_data?: Json | null
          callback_received?: boolean | null
          completed_at?: string | null
          created_at?: string | null
          currency?: string
          error_message?: string | null
          expires_at?: string | null
          id?: string
          initiated_at?: string | null
          metadata?: Json | null
          payment_method?: string | null
          payment_provider: Database["public"]["Enums"]["payment_provider"]
          payment_type: string
          provider_reference?: string | null
          provider_transaction_id?: string | null
          status?: Database["public"]["Enums"]["payment_status_enum"]
          subscription_id?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          ad_id?: string | null
          amount?: number
          callback_data?: Json | null
          callback_received?: boolean | null
          completed_at?: string | null
          created_at?: string | null
          currency?: string
          error_message?: string | null
          expires_at?: string | null
          id?: string
          initiated_at?: string | null
          metadata?: Json | null
          payment_method?: string | null
          payment_provider?: Database["public"]["Enums"]["payment_provider"]
          payment_type?: string
          provider_reference?: string | null
          provider_transaction_id?: string | null
          status?: Database["public"]["Enums"]["payment_status_enum"]
          subscription_id?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_transactions_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_transactions_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      payments: {
        Row: {
          amount: number
          created_at: string
          currency: string
          description: string | null
          id: string
          metadata: Json | null
          payment_method: string
          payment_status: string
          processed_at: string | null
          transaction_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          currency?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          payment_method: string
          payment_status?: string
          processed_at?: string | null
          transaction_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          payment_method?: string
          payment_status?: string
          processed_at?: string | null
          transaction_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      pinned_ads: {
        Row: {
          ad_id: string
          created_at: string | null
          id: string
          pin_order: number | null
          seller_id: string
        }
        Insert: {
          ad_id: string
          created_at?: string | null
          id?: string
          pin_order?: number | null
          seller_id: string
        }
        Update: {
          ad_id?: string
          created_at?: string | null
          id?: string
          pin_order?: number | null
          seller_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pinned_ads_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pinned_ads_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pinned_ads_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      placement_types: {
        Row: {
          created_at: string
          description: string | null
          display_name: string
          icon: string | null
          id: string
          is_active: boolean | null
          name: string
          price_multiplier: number
          sort_order: number | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          display_name: string
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          price_multiplier?: number
          sort_order?: number | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          display_name?: string
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          price_multiplier?: number
          sort_order?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      posts: {
        Row: {
          attached_products: string[]
          attached_services: string[] | null
          comment_count: number | null
          content: string
          created_at: string | null
          id: string
          images: string[] | null
          is_active: boolean | null
          like_count: number | null
          location: string | null
          media_dimensions: Json | null
          media_duration: number | null
          post_type: string | null
          seller_id: string | null
          share_count: number | null
          tags: string[] | null
          tiktok_url: string | null
          title: string
          updated_at: string | null
          user_id: string
          video_height: number | null
          video_thumbnail_url: string | null
          video_url: string | null
          video_width: number | null
          view_count: number | null
          visibility: string
          website_url: string | null
          youtube_url: string | null
        }
        Insert: {
          attached_products?: string[]
          attached_services?: string[] | null
          comment_count?: number | null
          content: string
          created_at?: string | null
          id?: string
          images?: string[] | null
          is_active?: boolean | null
          like_count?: number | null
          location?: string | null
          media_dimensions?: Json | null
          media_duration?: number | null
          post_type?: string | null
          seller_id?: string | null
          share_count?: number | null
          tags?: string[] | null
          tiktok_url?: string | null
          title: string
          updated_at?: string | null
          user_id: string
          video_height?: number | null
          video_thumbnail_url?: string | null
          video_url?: string | null
          video_width?: number | null
          view_count?: number | null
          visibility?: string
          website_url?: string | null
          youtube_url?: string | null
        }
        Update: {
          attached_products?: string[]
          attached_services?: string[] | null
          comment_count?: number | null
          content?: string
          created_at?: string | null
          id?: string
          images?: string[] | null
          is_active?: boolean | null
          like_count?: number | null
          location?: string | null
          media_dimensions?: Json | null
          media_duration?: number | null
          post_type?: string | null
          seller_id?: string | null
          share_count?: number | null
          tags?: string[] | null
          tiktok_url?: string | null
          title?: string
          updated_at?: string | null
          user_id?: string
          video_height?: number | null
          video_thumbnail_url?: string | null
          video_url?: string | null
          video_width?: number | null
          view_count?: number | null
          visibility?: string
          website_url?: string | null
          youtube_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "posts_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      price_alerts: {
        Row: {
          ad_id: string
          created_at: string | null
          id: string
          is_active: boolean | null
          notified_at: string | null
          original_price: number
          target_percentage: number | null
          user_id: string
        }
        Insert: {
          ad_id: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          notified_at?: string | null
          original_price: number
          target_percentage?: number | null
          user_id: string
        }
        Update: {
          ad_id?: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          notified_at?: string | null
          original_price?: number
          target_percentage?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "price_alerts_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      pricing_plans: {
        Row: {
          boost_multiplier: number
          created_at: string
          currency: string
          description: string | null
          duration_days: number
          features: Json
          id: string
          is_active: boolean
          plan_name: string
          price: number
          updated_at: string
        }
        Insert: {
          boost_multiplier?: number
          created_at?: string
          currency?: string
          description?: string | null
          duration_days: number
          features?: Json
          id?: string
          is_active?: boolean
          plan_name: string
          price: number
          updated_at?: string
        }
        Update: {
          boost_multiplier?: number
          created_at?: string
          currency?: string
          description?: string | null
          duration_days?: number
          features?: Json
          id?: string
          is_active?: boolean
          plan_name?: string
          price?: number
          updated_at?: string
        }
        Relationships: []
      }
      profile_edit_history: {
        Row: {
          edited_at: string
          field_name: string
          id: string
          new_value: string | null
          old_value: string | null
          user_id: string
        }
        Insert: {
          edited_at?: string
          field_name: string
          id?: string
          new_value?: string | null
          old_value?: string | null
          user_id: string
        }
        Update: {
          edited_at?: string
          field_name?: string
          id?: string
          new_value?: string | null
          old_value?: string | null
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          account_status: string | null
          app_version: string | null
          banned_at: string | null
          banned_by: string | null
          banned_reason: string | null
          created_at: string | null
          feed_categories: string[]
          has_password: boolean
          id: string
          is_verified: boolean | null
          last_app_version_check: string | null
          min_required_version: string | null
          onboarding_completed_version: string | null
          suspension_end_date: string | null
          updated_at: string | null
        }
        Insert: {
          account_status?: string | null
          app_version?: string | null
          banned_at?: string | null
          banned_by?: string | null
          banned_reason?: string | null
          created_at?: string | null
          feed_categories?: string[]
          has_password?: boolean
          id: string
          is_verified?: boolean | null
          last_app_version_check?: string | null
          min_required_version?: string | null
          onboarding_completed_version?: string | null
          suspension_end_date?: string | null
          updated_at?: string | null
        }
        Update: {
          account_status?: string | null
          app_version?: string | null
          banned_at?: string | null
          banned_by?: string | null
          banned_reason?: string | null
          created_at?: string | null
          feed_categories?: string[]
          has_password?: boolean
          id?: string
          is_verified?: boolean | null
          last_app_version_check?: string | null
          min_required_version?: string | null
          onboarding_completed_version?: string | null
          suspension_end_date?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      promotion_details: {
        Row: {
          ad_id: string
          brand_name: string
          category_filter: string[] | null
          created_at: string
          current_claims: number | null
          discount_amount: number | null
          discount_percentage: number | null
          happy_hour_config: Json | null
          id: string
          is_seller_wide: boolean | null
          max_claims: number | null
          notify_followers_count: number | null
          offer_type: string
          on_expiry_action: string
          original_price: number | null
          promo_code: string | null
          promotion_type: string | null
          requirements: string | null
          start_at: string | null
          state: string | null
          terms_conditions: string | null
          updated_at: string
          valid_until: string | null
          visibility_score: number | null
        }
        Insert: {
          ad_id: string
          brand_name: string
          category_filter?: string[] | null
          created_at?: string
          current_claims?: number | null
          discount_amount?: number | null
          discount_percentage?: number | null
          happy_hour_config?: Json | null
          id?: string
          is_seller_wide?: boolean | null
          max_claims?: number | null
          notify_followers_count?: number | null
          offer_type: string
          on_expiry_action?: string
          original_price?: number | null
          promo_code?: string | null
          promotion_type?: string | null
          requirements?: string | null
          start_at?: string | null
          state?: string | null
          terms_conditions?: string | null
          updated_at?: string
          valid_until?: string | null
          visibility_score?: number | null
        }
        Update: {
          ad_id?: string
          brand_name?: string
          category_filter?: string[] | null
          created_at?: string
          current_claims?: number | null
          discount_amount?: number | null
          discount_percentage?: number | null
          happy_hour_config?: Json | null
          id?: string
          is_seller_wide?: boolean | null
          max_claims?: number | null
          notify_followers_count?: number | null
          offer_type?: string
          on_expiry_action?: string
          original_price?: number | null
          promo_code?: string | null
          promotion_type?: string | null
          requirements?: string | null
          start_at?: string | null
          state?: string | null
          terms_conditions?: string | null
          updated_at?: string
          valid_until?: string | null
          visibility_score?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "promotion_details_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      promotion_follows: {
        Row: {
          created_at: string | null
          id: string
          notified_end: boolean | null
          notified_start: boolean | null
          notify_before_end: boolean | null
          notify_on_start: boolean | null
          promotion_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          notified_end?: boolean | null
          notified_start?: boolean | null
          notify_before_end?: boolean | null
          notify_on_start?: boolean | null
          promotion_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          notified_end?: boolean | null
          notified_start?: boolean | null
          notify_before_end?: boolean | null
          notify_on_start?: boolean | null
          promotion_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "promotion_follows_promotion_id_fkey"
            columns: ["promotion_id"]
            isOneToOne: false
            referencedRelation: "promotion_details"
            referencedColumns: ["id"]
          },
        ]
      }
      promotion_products: {
        Row: {
          ad_id: string
          claimed_count: number | null
          created_at: string | null
          discount_amount: number | null
          discount_percentage: number | null
          id: string
          max_quantity_per_buyer: number | null
          promotion_id: string
          stock_limit: number | null
        }
        Insert: {
          ad_id: string
          claimed_count?: number | null
          created_at?: string | null
          discount_amount?: number | null
          discount_percentage?: number | null
          id?: string
          max_quantity_per_buyer?: number | null
          promotion_id: string
          stock_limit?: number | null
        }
        Update: {
          ad_id?: string
          claimed_count?: number | null
          created_at?: string | null
          discount_amount?: number | null
          discount_percentage?: number | null
          id?: string
          max_quantity_per_buyer?: number | null
          promotion_id?: string
          stock_limit?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "promotion_products_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "promotion_products_promotion_id_fkey"
            columns: ["promotion_id"]
            isOneToOne: false
            referencedRelation: "promotion_details"
            referencedColumns: ["id"]
          },
        ]
      }
      promotion_reminders: {
        Row: {
          created_at: string | null
          id: string
          is_notified: boolean | null
          promotion_id: string
          remind_at: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_notified?: boolean | null
          promotion_id: string
          remind_at: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          is_notified?: boolean | null
          promotion_id?: string
          remind_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "promotion_reminders_promotion_id_fkey"
            columns: ["promotion_id"]
            isOneToOne: false
            referencedRelation: "promotion_details"
            referencedColumns: ["id"]
          },
        ]
      }
      regions: {
        Row: {
          code: string | null
          country: string
          created_at: string
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          code?: string | null
          country: string
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          code?: string | null
          country?: string
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string
          description: string | null
          id: string
          reason: string
          report_type: string
          reported_ad_id: string | null
          reported_user_id: string | null
          reporter_id: string | null
          resolved_at: string | null
          resolved_by: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          reason: string
          report_type: string
          reported_ad_id?: string | null
          reported_user_id?: string | null
          reporter_id?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          reason?: string
          report_type?: string
          reported_ad_id?: string | null
          reported_user_id?: string | null
          reporter_id?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      review_helpful_votes: {
        Row: {
          created_at: string | null
          id: string
          review_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          review_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          review_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "review_helpful_votes_review_id_fkey"
            columns: ["review_id"]
            isOneToOne: false
            referencedRelation: "reviews"
            referencedColumns: ["id"]
          },
        ]
      }
      reviews: {
        Row: {
          ad_id: string | null
          comment: string | null
          created_at: string
          helpful_count: number | null
          id: string
          is_verified: boolean
          rating: number
          review_images: string[] | null
          reviewed_user_id: string
          reviewer_id: string
          updated_at: string
        }
        Insert: {
          ad_id?: string | null
          comment?: string | null
          created_at?: string
          helpful_count?: number | null
          id?: string
          is_verified?: boolean
          rating: number
          review_images?: string[] | null
          reviewed_user_id: string
          reviewer_id: string
          updated_at?: string
        }
        Update: {
          ad_id?: string | null
          comment?: string | null
          created_at?: string
          helpful_count?: number | null
          id?: string
          is_verified?: boolean
          rating?: number
          review_images?: string[] | null
          reviewed_user_id?: string
          reviewer_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      search_history: {
        Row: {
          clicked_ad_id: string | null
          created_at: string
          filters: Json | null
          id: string
          results_count: number | null
          search_query: string
          session_id: string | null
          user_id: string | null
        }
        Insert: {
          clicked_ad_id?: string | null
          created_at?: string
          filters?: Json | null
          id?: string
          results_count?: number | null
          search_query: string
          session_id?: string | null
          user_id?: string | null
        }
        Update: {
          clicked_ad_id?: string | null
          created_at?: string
          filters?: Json | null
          id?: string
          results_count?: number | null
          search_query?: string
          session_id?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      seller_documents: {
        Row: {
          document_name: string
          document_type: string
          document_url: string
          file_size: number | null
          id: string
          mime_type: string | null
          rejection_reason: string | null
          seller_id: string | null
          status: string
          uploaded_at: string
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          document_name: string
          document_type: string
          document_url: string
          file_size?: number | null
          id?: string
          mime_type?: string | null
          rejection_reason?: string | null
          seller_id?: string | null
          status?: string
          uploaded_at?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          document_name?: string
          document_type?: string
          document_url?: string
          file_size?: number | null
          id?: string
          mime_type?: string | null
          rejection_reason?: string | null
          seller_id?: string | null
          status?: string
          uploaded_at?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "seller_documents_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "sellers"
            referencedColumns: ["id"]
          },
        ]
      }
      seller_profiles: {
        Row: {
          account_tier: string
          business_bio: string | null
          business_categories: string[] | null
          business_category: string
          business_email: string
          business_logo_url: string | null
          business_name: string
          business_phone: string
          business_type: string | null
          business_video_url: string | null
          catalog_embedding: string | null
          country: string
          cover_image_url: string | null
          created_at: string | null
          current_service_status: string | null
          delivery_areas: string[] | null
          delivery_options: string[] | null
          district: string
          facebook_url: string | null
          featured_until: string | null
          follower_count: number | null
          following_count: number | null
          id: string
          instagram_url: string | null
          is_active: boolean | null
          is_featured: boolean | null
          is_online: boolean | null
          is_verified: boolean | null
          last_seen_at: string | null
          last_verification_check: string | null
          latitude: number | null
          linkedin_url: string | null
          longitude: number | null
          map_location: string | null
          offerings_count: number | null
          organization_registration_id: string | null
          payment_methods: string[] | null
          portfolio_updated_at: string | null
          primary_focus: string
          primary_focus_overridden: boolean
          profile_completion_percentage: number | null
          registration_number: string | null
          return_policy: string | null
          seller_type: string
          service_status_expires_at: string | null
          service_status_message: string | null
          services_count: number
          show_follower_count: boolean | null
          show_location: boolean | null
          store_slug: string
          street_address: string
          sub_county: string
          subscription_expires_at: string | null
          subscription_grace_end: string | null
          subscription_started_at: string | null
          subscription_status: string | null
          terms_accepted: boolean | null
          terms_accepted_at: string | null
          tiktok_username: string | null
          tiktok_video_url: string | null
          total_engagement: number | null
          twitter_url: string | null
          updated_at: string | null
          user_id: string
          verification_badge:
            | Database["public"]["Enums"]["seller_badge_level"]
            | null
          verification_badge_color: string | null
          verification_score: number | null
          warranty_policy: string | null
          website_url: string | null
          whatsapp_number: string | null
          working_hours: Json | null
          youtube_url: string | null
        }
        Insert: {
          account_tier?: string
          business_bio?: string | null
          business_categories?: string[] | null
          business_category: string
          business_email: string
          business_logo_url?: string | null
          business_name: string
          business_phone: string
          business_type?: string | null
          business_video_url?: string | null
          catalog_embedding?: string | null
          country?: string
          cover_image_url?: string | null
          created_at?: string | null
          current_service_status?: string | null
          delivery_areas?: string[] | null
          delivery_options?: string[] | null
          district: string
          facebook_url?: string | null
          featured_until?: string | null
          follower_count?: number | null
          following_count?: number | null
          id?: string
          instagram_url?: string | null
          is_active?: boolean | null
          is_featured?: boolean | null
          is_online?: boolean | null
          is_verified?: boolean | null
          last_seen_at?: string | null
          last_verification_check?: string | null
          latitude?: number | null
          linkedin_url?: string | null
          longitude?: number | null
          map_location?: string | null
          offerings_count?: number | null
          organization_registration_id?: string | null
          payment_methods?: string[] | null
          portfolio_updated_at?: string | null
          primary_focus?: string
          primary_focus_overridden?: boolean
          profile_completion_percentage?: number | null
          registration_number?: string | null
          return_policy?: string | null
          seller_type: string
          service_status_expires_at?: string | null
          service_status_message?: string | null
          services_count?: number
          show_follower_count?: boolean | null
          show_location?: boolean | null
          store_slug: string
          street_address: string
          sub_county: string
          subscription_expires_at?: string | null
          subscription_grace_end?: string | null
          subscription_started_at?: string | null
          subscription_status?: string | null
          terms_accepted?: boolean | null
          terms_accepted_at?: string | null
          tiktok_username?: string | null
          tiktok_video_url?: string | null
          total_engagement?: number | null
          twitter_url?: string | null
          updated_at?: string | null
          user_id: string
          verification_badge?:
            | Database["public"]["Enums"]["seller_badge_level"]
            | null
          verification_badge_color?: string | null
          verification_score?: number | null
          warranty_policy?: string | null
          website_url?: string | null
          whatsapp_number?: string | null
          working_hours?: Json | null
          youtube_url?: string | null
        }
        Update: {
          account_tier?: string
          business_bio?: string | null
          business_categories?: string[] | null
          business_category?: string
          business_email?: string
          business_logo_url?: string | null
          business_name?: string
          business_phone?: string
          business_type?: string | null
          business_video_url?: string | null
          catalog_embedding?: string | null
          country?: string
          cover_image_url?: string | null
          created_at?: string | null
          current_service_status?: string | null
          delivery_areas?: string[] | null
          delivery_options?: string[] | null
          district?: string
          facebook_url?: string | null
          featured_until?: string | null
          follower_count?: number | null
          following_count?: number | null
          id?: string
          instagram_url?: string | null
          is_active?: boolean | null
          is_featured?: boolean | null
          is_online?: boolean | null
          is_verified?: boolean | null
          last_seen_at?: string | null
          last_verification_check?: string | null
          latitude?: number | null
          linkedin_url?: string | null
          longitude?: number | null
          map_location?: string | null
          offerings_count?: number | null
          organization_registration_id?: string | null
          payment_methods?: string[] | null
          portfolio_updated_at?: string | null
          primary_focus?: string
          primary_focus_overridden?: boolean
          profile_completion_percentage?: number | null
          registration_number?: string | null
          return_policy?: string | null
          seller_type?: string
          service_status_expires_at?: string | null
          service_status_message?: string | null
          services_count?: number
          show_follower_count?: boolean | null
          show_location?: boolean | null
          store_slug?: string
          street_address?: string
          sub_county?: string
          subscription_expires_at?: string | null
          subscription_grace_end?: string | null
          subscription_started_at?: string | null
          subscription_status?: string | null
          terms_accepted?: boolean | null
          terms_accepted_at?: string | null
          tiktok_username?: string | null
          tiktok_video_url?: string | null
          total_engagement?: number | null
          twitter_url?: string | null
          updated_at?: string | null
          user_id?: string
          verification_badge?:
            | Database["public"]["Enums"]["seller_badge_level"]
            | null
          verification_badge_color?: string | null
          verification_score?: number | null
          warranty_policy?: string | null
          website_url?: string | null
          whatsapp_number?: string | null
          working_hours?: Json | null
          youtube_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "seller_profiles_organization_registration_id_fkey"
            columns: ["organization_registration_id"]
            isOneToOne: false
            referencedRelation: "organization_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      seller_social_connections: {
        Row: {
          access_token: string | null
          connected_at: string | null
          created_at: string | null
          disconnected_at: string | null
          id: string
          is_connected: boolean | null
          platform: string
          platform_user_id: string | null
          platform_username: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          access_token?: string | null
          connected_at?: string | null
          created_at?: string | null
          disconnected_at?: string | null
          id?: string
          is_connected?: boolean | null
          platform: string
          platform_user_id?: string | null
          platform_username?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          access_token?: string | null
          connected_at?: string | null
          created_at?: string | null
          disconnected_at?: string | null
          id?: string
          is_connected?: boolean | null
          platform?: string
          platform_user_id?: string | null
          platform_username?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      seller_terms: {
        Row: {
          content: string
          created_at: string
          id: string
          is_active: boolean | null
          title: string
          updated_at: string
          version: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          title: string
          updated_at?: string
          version: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          title?: string
          updated_at?: string
          version?: string
        }
        Relationships: []
      }
      seller_verifications: {
        Row: {
          badge_level: Database["public"]["Enums"]["seller_badge_level"] | null
          badge_updated_at: string | null
          business_name: string | null
          completed_steps: number | null
          created_at: string | null
          date_of_birth: string | null
          digital_signature_url: string | null
          email_verification_sent_at: string | null
          email_verification_token: string | null
          email_verified: boolean | null
          email_verified_at: string | null
          face_match_score: number | null
          full_legal_name: string | null
          gender: string | null
          id: string
          id_back_url: string | null
          id_front_url: string | null
          id_number: string | null
          id_rejection_reason: string | null
          id_status:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          id_type: string | null
          id_verified_at: string | null
          id_verified_by: string | null
          kyc_status:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          kyc_submitted_at: string | null
          nin_number: string | null
          overall_status:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          phone_number: string | null
          phone_otp_attempts: number | null
          phone_otp_code: string | null
          phone_otp_sent_at: string | null
          phone_verified: boolean | null
          phone_verified_at: string | null
          residential_district: string | null
          selfie_rejection_reason: string | null
          selfie_status:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          selfie_url: string | null
          selfie_verified_at: string | null
          selfie_verified_by: string | null
          seller_bio: string | null
          terms_accepted: boolean | null
          terms_accepted_at: string | null
          total_steps: number | null
          two_fa_enabled: boolean | null
          two_fa_enabled_at: string | null
          two_fa_method: string | null
          two_fa_secret: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          badge_level?: Database["public"]["Enums"]["seller_badge_level"] | null
          badge_updated_at?: string | null
          business_name?: string | null
          completed_steps?: number | null
          created_at?: string | null
          date_of_birth?: string | null
          digital_signature_url?: string | null
          email_verification_sent_at?: string | null
          email_verification_token?: string | null
          email_verified?: boolean | null
          email_verified_at?: string | null
          face_match_score?: number | null
          full_legal_name?: string | null
          gender?: string | null
          id?: string
          id_back_url?: string | null
          id_front_url?: string | null
          id_number?: string | null
          id_rejection_reason?: string | null
          id_status?:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          id_type?: string | null
          id_verified_at?: string | null
          id_verified_by?: string | null
          kyc_status?:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          kyc_submitted_at?: string | null
          nin_number?: string | null
          overall_status?:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          phone_number?: string | null
          phone_otp_attempts?: number | null
          phone_otp_code?: string | null
          phone_otp_sent_at?: string | null
          phone_verified?: boolean | null
          phone_verified_at?: string | null
          residential_district?: string | null
          selfie_rejection_reason?: string | null
          selfie_status?:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          selfie_url?: string | null
          selfie_verified_at?: string | null
          selfie_verified_by?: string | null
          seller_bio?: string | null
          terms_accepted?: boolean | null
          terms_accepted_at?: string | null
          total_steps?: number | null
          two_fa_enabled?: boolean | null
          two_fa_enabled_at?: string | null
          two_fa_method?: string | null
          two_fa_secret?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          badge_level?: Database["public"]["Enums"]["seller_badge_level"] | null
          badge_updated_at?: string | null
          business_name?: string | null
          completed_steps?: number | null
          created_at?: string | null
          date_of_birth?: string | null
          digital_signature_url?: string | null
          email_verification_sent_at?: string | null
          email_verification_token?: string | null
          email_verified?: boolean | null
          email_verified_at?: string | null
          face_match_score?: number | null
          full_legal_name?: string | null
          gender?: string | null
          id?: string
          id_back_url?: string | null
          id_front_url?: string | null
          id_number?: string | null
          id_rejection_reason?: string | null
          id_status?:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          id_type?: string | null
          id_verified_at?: string | null
          id_verified_by?: string | null
          kyc_status?:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          kyc_submitted_at?: string | null
          nin_number?: string | null
          overall_status?:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          phone_number?: string | null
          phone_otp_attempts?: number | null
          phone_otp_code?: string | null
          phone_otp_sent_at?: string | null
          phone_verified?: boolean | null
          phone_verified_at?: string | null
          residential_district?: string | null
          selfie_rejection_reason?: string | null
          selfie_status?:
            | Database["public"]["Enums"]["verification_step_status"]
            | null
          selfie_url?: string | null
          selfie_verified_at?: string | null
          selfie_verified_by?: string | null
          seller_bio?: string | null
          terms_accepted?: boolean | null
          terms_accepted_at?: string | null
          total_steps?: number | null
          two_fa_enabled?: boolean | null
          two_fa_enabled_at?: string | null
          two_fa_method?: string | null
          two_fa_secret?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      sellers: {
        Row: {
          application_status: string | null
          applied_at: string | null
          approved_at: string | null
          approved_by: string | null
          business_address: string | null
          business_description: string | null
          business_email: string | null
          business_logo_url: string | null
          business_name: string | null
          business_phone: string | null
          business_type: string | null
          business_website: string | null
          created_at: string
          district: string | null
          id: string
          is_verified: boolean | null
          parish: string | null
          rating: number | null
          registration_number: string | null
          response_time_hours: number | null
          seller_score: number | null
          sub_county: string | null
          tax_id: string | null
          terms_accepted: boolean | null
          terms_accepted_at: string | null
          total_sales: number | null
          trust_level: number | null
          updated_at: string
          user_id: string | null
          village: string | null
        }
        Insert: {
          application_status?: string | null
          applied_at?: string | null
          approved_at?: string | null
          approved_by?: string | null
          business_address?: string | null
          business_description?: string | null
          business_email?: string | null
          business_logo_url?: string | null
          business_name?: string | null
          business_phone?: string | null
          business_type?: string | null
          business_website?: string | null
          created_at?: string
          district?: string | null
          id?: string
          is_verified?: boolean | null
          parish?: string | null
          rating?: number | null
          registration_number?: string | null
          response_time_hours?: number | null
          seller_score?: number | null
          sub_county?: string | null
          tax_id?: string | null
          terms_accepted?: boolean | null
          terms_accepted_at?: string | null
          total_sales?: number | null
          trust_level?: number | null
          updated_at?: string
          user_id?: string | null
          village?: string | null
        }
        Update: {
          application_status?: string | null
          applied_at?: string | null
          approved_at?: string | null
          approved_by?: string | null
          business_address?: string | null
          business_description?: string | null
          business_email?: string | null
          business_logo_url?: string | null
          business_name?: string | null
          business_phone?: string | null
          business_type?: string | null
          business_website?: string | null
          created_at?: string
          district?: string | null
          id?: string
          is_verified?: boolean | null
          parish?: string | null
          rating?: number | null
          registration_number?: string | null
          response_time_hours?: number | null
          seller_score?: number | null
          sub_county?: string | null
          tax_id?: string | null
          terms_accepted?: boolean | null
          terms_accepted_at?: string | null
          total_sales?: number | null
          trust_level?: number | null
          updated_at?: string
          user_id?: string | null
          village?: string | null
        }
        Relationships: []
      }
      service_catalog_templates: {
        Row: {
          category: string
          created_at: string
          currency: string
          description: string | null
          duration_minutes: number | null
          id: string
          name: string
          source: string
          typical_price_max: number | null
          typical_price_min: number | null
          usage_count: number
        }
        Insert: {
          category: string
          created_at?: string
          currency?: string
          description?: string | null
          duration_minutes?: number | null
          id?: string
          name: string
          source?: string
          typical_price_max?: number | null
          typical_price_min?: number | null
          usage_count?: number
        }
        Update: {
          category?: string
          created_at?: string
          currency?: string
          description?: string | null
          duration_minutes?: number | null
          id?: string
          name?: string
          source?: string
          typical_price_max?: number | null
          typical_price_min?: number | null
          usage_count?: number
        }
        Relationships: []
      }
      service_catalogs: {
        Row: {
          ad_id: string
          created_at: string | null
          currency: string | null
          description: string | null
          display_order: number | null
          duration_minutes: number | null
          id: string
          is_featured: boolean | null
          name: string
          price: number | null
          seller_id: string
          updated_at: string | null
        }
        Insert: {
          ad_id: string
          created_at?: string | null
          currency?: string | null
          description?: string | null
          display_order?: number | null
          duration_minutes?: number | null
          id?: string
          is_featured?: boolean | null
          name: string
          price?: number | null
          seller_id: string
          updated_at?: string | null
        }
        Update: {
          ad_id?: string
          created_at?: string | null
          currency?: string | null
          description?: string | null
          display_order?: number | null
          duration_minutes?: number | null
          id?: string
          is_featured?: boolean | null
          name?: string
          price?: number | null
          seller_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "service_catalogs_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_catalogs_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_catalogs_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      service_categories: {
        Row: {
          created_at: string
          description: string | null
          display_order: number
          icon: string | null
          id: string
          is_active: boolean
          name: string
          parent_id: string | null
          slug: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          display_order?: number
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          parent_id?: string | null
          slug: string
        }
        Update: {
          created_at?: string
          description?: string | null
          display_order?: number
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          parent_id?: string | null
          slug?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "service_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      service_details: {
        Row: {
          accommodation_type: string | null
          ad_id: string
          amenities: string[] | null
          availability_hours: string | null
          availability_schedule: Json | null
          available_from: string | null
          bathrooms: string | null
          bedrooms: string | null
          booking_method: string | null
          booking_phone: string | null
          booking_url: string | null
          cancellation_policy: string | null
          contact_info: string | null
          created_at: string
          currency: string | null
          delivery_time: string | null
          deposit_required: string | null
          equipment_provided: boolean | null
          experience_years: number | null
          floor_level: string | null
          furnished_status: string | null
          id: string
          languages: string[] | null
          materials_included: boolean | null
          minimum_order: string | null
          pets_allowed: boolean | null
          portfolio_images: string[] | null
          price_max: number | null
          price_period: string | null
          pricing_type: string | null
          qualifications: string | null
          service_area: string[] | null
          service_radius: number | null
          starting_price: number | null
          updated_at: string
          warranty_offered: string | null
        }
        Insert: {
          accommodation_type?: string | null
          ad_id: string
          amenities?: string[] | null
          availability_hours?: string | null
          availability_schedule?: Json | null
          available_from?: string | null
          bathrooms?: string | null
          bedrooms?: string | null
          booking_method?: string | null
          booking_phone?: string | null
          booking_url?: string | null
          cancellation_policy?: string | null
          contact_info?: string | null
          created_at?: string
          currency?: string | null
          delivery_time?: string | null
          deposit_required?: string | null
          equipment_provided?: boolean | null
          experience_years?: number | null
          floor_level?: string | null
          furnished_status?: string | null
          id?: string
          languages?: string[] | null
          materials_included?: boolean | null
          minimum_order?: string | null
          pets_allowed?: boolean | null
          portfolio_images?: string[] | null
          price_max?: number | null
          price_period?: string | null
          pricing_type?: string | null
          qualifications?: string | null
          service_area?: string[] | null
          service_radius?: number | null
          starting_price?: number | null
          updated_at?: string
          warranty_offered?: string | null
        }
        Update: {
          accommodation_type?: string | null
          ad_id?: string
          amenities?: string[] | null
          availability_hours?: string | null
          availability_schedule?: Json | null
          available_from?: string | null
          bathrooms?: string | null
          bedrooms?: string | null
          booking_method?: string | null
          booking_phone?: string | null
          booking_url?: string | null
          cancellation_policy?: string | null
          contact_info?: string | null
          created_at?: string
          currency?: string | null
          delivery_time?: string | null
          deposit_required?: string | null
          equipment_provided?: boolean | null
          experience_years?: number | null
          floor_level?: string | null
          furnished_status?: string | null
          id?: string
          languages?: string[] | null
          materials_included?: boolean | null
          minimum_order?: string | null
          pets_allowed?: boolean | null
          portfolio_images?: string[] | null
          price_max?: number | null
          price_period?: string | null
          pricing_type?: string | null
          qualifications?: string | null
          service_area?: string[] | null
          service_radius?: number | null
          starting_price?: number | null
          updated_at?: string
          warranty_offered?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "service_details_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      service_faqs: {
        Row: {
          answer: string
          created_at: string
          id: string
          question: string
          seller_id: string
          service_id: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          answer: string
          created_at?: string
          id?: string
          question: string
          seller_id: string
          service_id: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          answer?: string
          created_at?: string
          id?: string
          question?: string
          seller_id?: string
          service_id?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_faqs_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_faqs_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_faqs_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      service_followers: {
        Row: {
          created_at: string
          follower_user_id: string
          id: string
          service_id: string
        }
        Insert: {
          created_at?: string
          follower_user_id: string
          id?: string
          service_id: string
        }
        Update: {
          created_at?: string
          follower_user_id?: string
          id?: string
          service_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_followers_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      service_offerings: {
        Row: {
          category: string | null
          created_at: string
          currency: string | null
          description: string | null
          display_order: number | null
          duration_estimate: string | null
          id: string
          is_active: boolean | null
          is_available: boolean | null
          price: number | null
          price_type: string | null
          seller_id: string
          tags: string[] | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          currency?: string | null
          description?: string | null
          display_order?: number | null
          duration_estimate?: string | null
          id?: string
          is_active?: boolean | null
          is_available?: boolean | null
          price?: number | null
          price_type?: string | null
          seller_id: string
          tags?: string[] | null
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string | null
          created_at?: string
          currency?: string | null
          description?: string | null
          display_order?: number | null
          duration_estimate?: string | null
          id?: string
          is_active?: boolean | null
          is_available?: boolean | null
          price?: number | null
          price_type?: string | null
          seller_id?: string
          tags?: string[] | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_offerings_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_offerings_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      service_portfolio: {
        Row: {
          client_name: string | null
          created_at: string
          description: string | null
          id: string
          images: string[]
          is_active: boolean | null
          is_featured: boolean | null
          project_date: string | null
          seller_id: string
          tags: string[] | null
          title: string
          updated_at: string
          user_id: string
          video_thumbnail_url: string | null
          video_url: string | null
          view_count: number | null
        }
        Insert: {
          client_name?: string | null
          created_at?: string
          description?: string | null
          id?: string
          images?: string[]
          is_active?: boolean | null
          is_featured?: boolean | null
          project_date?: string | null
          seller_id: string
          tags?: string[] | null
          title: string
          updated_at?: string
          user_id: string
          video_thumbnail_url?: string | null
          video_url?: string | null
          view_count?: number | null
        }
        Update: {
          client_name?: string | null
          created_at?: string
          description?: string | null
          id?: string
          images?: string[]
          is_active?: boolean | null
          is_featured?: boolean | null
          project_date?: string | null
          seller_id?: string
          tags?: string[] | null
          title?: string
          updated_at?: string
          user_id?: string
          video_thumbnail_url?: string | null
          video_url?: string | null
          view_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "service_portfolio_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_portfolio_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      service_status_updates: {
        Row: {
          created_at: string
          expires_at: string
          id: string
          is_active: boolean | null
          message: string | null
          seller_id: string
          status_type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at: string
          id?: string
          is_active?: boolean | null
          message?: string | null
          seller_id: string
          status_type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          id?: string
          is_active?: boolean | null
          message?: string | null
          seller_id?: string
          status_type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_status_updates_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_status_updates_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      service_testimonials: {
        Row: {
          client_avatar_url: string | null
          client_name: string | null
          client_user_id: string | null
          created_at: string
          id: string
          is_approved: boolean
          media_type: string | null
          media_url: string | null
          quote: string
          rating: number | null
          seller_id: string
          service_id: string
          updated_at: string
        }
        Insert: {
          client_avatar_url?: string | null
          client_name?: string | null
          client_user_id?: string | null
          created_at?: string
          id?: string
          is_approved?: boolean
          media_type?: string | null
          media_url?: string | null
          quote: string
          rating?: number | null
          seller_id: string
          service_id: string
          updated_at?: string
        }
        Update: {
          client_avatar_url?: string | null
          client_name?: string | null
          client_user_id?: string | null
          created_at?: string
          id?: string
          is_approved?: boolean
          media_type?: string | null
          media_url?: string | null
          quote?: string
          rating?: number | null
          seller_id?: string
          service_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_testimonials_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      service_updates: {
        Row: {
          after_image_url: string | null
          before_image_url: string | null
          caption: string | null
          client_name: string | null
          comment_count: number
          created_at: string
          discount_value: number | null
          embedding: string | null
          event_date: string | null
          event_location: string | null
          expires_at: string | null
          id: string
          images: string[] | null
          is_active: boolean
          is_featured: boolean
          like_count: number
          link_url: string | null
          metric_label: string | null
          metric_value: number | null
          project_date: string | null
          seller_id: string
          service_id: string
          share_count: number
          tags: string[] | null
          title: string | null
          update_type: string
          updated_at: string
          user_id: string
          video_thumbnail_url: string | null
          video_url: string | null
          view_count: number
        }
        Insert: {
          after_image_url?: string | null
          before_image_url?: string | null
          caption?: string | null
          client_name?: string | null
          comment_count?: number
          created_at?: string
          discount_value?: number | null
          embedding?: string | null
          event_date?: string | null
          event_location?: string | null
          expires_at?: string | null
          id?: string
          images?: string[] | null
          is_active?: boolean
          is_featured?: boolean
          like_count?: number
          link_url?: string | null
          metric_label?: string | null
          metric_value?: number | null
          project_date?: string | null
          seller_id: string
          service_id: string
          share_count?: number
          tags?: string[] | null
          title?: string | null
          update_type?: string
          updated_at?: string
          user_id: string
          video_thumbnail_url?: string | null
          video_url?: string | null
          view_count?: number
        }
        Update: {
          after_image_url?: string | null
          before_image_url?: string | null
          caption?: string | null
          client_name?: string | null
          comment_count?: number
          created_at?: string
          discount_value?: number | null
          embedding?: string | null
          event_date?: string | null
          event_location?: string | null
          expires_at?: string | null
          id?: string
          images?: string[] | null
          is_active?: boolean
          is_featured?: boolean
          like_count?: number
          link_url?: string | null
          metric_label?: string | null
          metric_value?: number | null
          project_date?: string | null
          seller_id?: string
          service_id?: string
          share_count?: number
          tags?: string[] | null
          title?: string | null
          update_type?: string
          updated_at?: string
          user_id?: string
          video_thumbnail_url?: string | null
          video_url?: string | null
          view_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "service_updates_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      settings: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_public: boolean
          setting_key: string
          setting_value: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_public?: boolean
          setting_key: string
          setting_value: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_public?: boolean
          setting_key?: string
          setting_value?: Json
          updated_at?: string
        }
        Relationships: []
      }
      sub_counties: {
        Row: {
          created_at: string
          district_id: string
          id: string
          name: string
          slug: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          district_id: string
          id?: string
          name: string
          slug: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          district_id?: string
          id?: string
          name?: string
          slug?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sub_counties_district_id_fkey"
            columns: ["district_id"]
            isOneToOne: false
            referencedRelation: "districts"
            referencedColumns: ["id"]
          },
        ]
      }
      subcategories: {
        Row: {
          category_id: string
          created_at: string
          icon: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          category_id: string
          created_at?: string
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          category_id?: string
          created_at?: string
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "subcategories_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_plans: {
        Row: {
          billing_period: string
          created_at: string | null
          currency: string
          description: string | null
          display_name: string
          features: Json | null
          id: string
          is_active: boolean | null
          max_ads: number | null
          max_boosts: number | null
          name: string
          price: number
          updated_at: string | null
        }
        Insert: {
          billing_period?: string
          created_at?: string | null
          currency?: string
          description?: string | null
          display_name: string
          features?: Json | null
          id?: string
          is_active?: boolean | null
          max_ads?: number | null
          max_boosts?: number | null
          name: string
          price: number
          updated_at?: string | null
        }
        Update: {
          billing_period?: string
          created_at?: string | null
          currency?: string
          description?: string | null
          display_name?: string
          features?: Json | null
          id?: string
          is_active?: boolean | null
          max_ads?: number | null
          max_boosts?: number | null
          name?: string
          price?: number
          updated_at?: string | null
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          cancel_at_period_end: boolean | null
          cancelled_at: string | null
          created_at: string | null
          current_period_end: string
          current_period_start: string
          failed_payment_count: number | null
          id: string
          last_payment_date: string | null
          metadata: Json | null
          next_payment_date: string | null
          payment_method_id: string | null
          payment_provider: Database["public"]["Enums"]["payment_provider"]
          plan_id: string | null
          seller_id: string | null
          status: Database["public"]["Enums"]["subscription_status_enum"]
          trial_end: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          cancel_at_period_end?: boolean | null
          cancelled_at?: string | null
          created_at?: string | null
          current_period_end: string
          current_period_start?: string
          failed_payment_count?: number | null
          id?: string
          last_payment_date?: string | null
          metadata?: Json | null
          next_payment_date?: string | null
          payment_method_id?: string | null
          payment_provider: Database["public"]["Enums"]["payment_provider"]
          plan_id?: string | null
          seller_id?: string | null
          status?: Database["public"]["Enums"]["subscription_status_enum"]
          trial_end?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          cancel_at_period_end?: boolean | null
          cancelled_at?: string | null
          created_at?: string | null
          current_period_end?: string
          current_period_start?: string
          failed_payment_count?: number | null
          id?: string
          last_payment_date?: string | null
          metadata?: Json | null
          next_payment_date?: string | null
          payment_method_id?: string | null
          payment_provider?: Database["public"]["Enums"]["payment_provider"]
          plan_id?: string | null
          seller_id?: string | null
          status?: Database["public"]["Enums"]["subscription_status_enum"]
          trial_end?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      system_logs: {
        Row: {
          created_at: string
          error_details: Json | null
          id: string
          log_level: string
          message: string
          request_id: string | null
          service: string
        }
        Insert: {
          created_at?: string
          error_details?: Json | null
          id?: string
          log_level: string
          message: string
          request_id?: string | null
          service: string
        }
        Update: {
          created_at?: string
          error_details?: Json | null
          id?: string
          log_level?: string
          message?: string
          request_id?: string | null
          service?: string
        }
        Relationships: []
      }
      system_status: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          last_check: string
          metadata: Json | null
          response_time_ms: number | null
          service_name: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          last_check?: string
          metadata?: Json | null
          response_time_ms?: number | null
          service_name: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          last_check?: string
          metadata?: Json | null
          response_time_ms?: number | null
          service_name?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      tenders: {
        Row: {
          application_count: number | null
          attachments: string[] | null
          award_date: string | null
          bid_bond_amount: number | null
          bid_bond_required: boolean | null
          budget_range_max: number | null
          budget_range_min: number | null
          contact_email: string | null
          contact_phone: string | null
          created_at: string | null
          currency: string | null
          description: string
          eligibility_requirements: string | null
          id: string
          images: string[] | null
          is_active: boolean | null
          location: string | null
          opening_date: string | null
          organization_id: string | null
          required_documents: string[] | null
          seller_id: string | null
          status: string | null
          submission_deadline: string
          tender_type: string
          title: string
          updated_at: string | null
          user_id: string
          view_count: number | null
          winner_id: string | null
        }
        Insert: {
          application_count?: number | null
          attachments?: string[] | null
          award_date?: string | null
          bid_bond_amount?: number | null
          bid_bond_required?: boolean | null
          budget_range_max?: number | null
          budget_range_min?: number | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string | null
          currency?: string | null
          description: string
          eligibility_requirements?: string | null
          id?: string
          images?: string[] | null
          is_active?: boolean | null
          location?: string | null
          opening_date?: string | null
          organization_id?: string | null
          required_documents?: string[] | null
          seller_id?: string | null
          status?: string | null
          submission_deadline: string
          tender_type?: string
          title: string
          updated_at?: string | null
          user_id: string
          view_count?: number | null
          winner_id?: string | null
        }
        Update: {
          application_count?: number | null
          attachments?: string[] | null
          award_date?: string | null
          bid_bond_amount?: number | null
          bid_bond_required?: boolean | null
          budget_range_max?: number | null
          budget_range_min?: number | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string | null
          currency?: string | null
          description?: string
          eligibility_requirements?: string | null
          id?: string
          images?: string[] | null
          is_active?: boolean | null
          location?: string | null
          opening_date?: string | null
          organization_id?: string | null
          required_documents?: string[] | null
          seller_id?: string | null
          status?: string | null
          submission_deadline?: string
          tender_type?: string
          title?: string
          updated_at?: string | null
          user_id?: string
          view_count?: number | null
          winner_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tenders_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organization_registrations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tenders_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tenders_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      transactions: {
        Row: {
          ad_id: string | null
          amount: number
          created_at: string
          currency: string
          description: string | null
          id: string
          metadata: Json | null
          payment_id: string | null
          status: string
          transaction_type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          ad_id?: string | null
          amount: number
          created_at?: string
          currency?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          payment_id?: string | null
          status?: string
          transaction_type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          ad_id?: string | null
          amount?: number
          created_at?: string
          currency?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          payment_id?: string | null
          status?: string
          transaction_type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_transactions_payment_id"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_ai_usage: {
        Row: {
          created_at: string
          daily_message_count: number
          id: string
          last_message_date: string | null
          message_count: number
          period_end: string
          period_start: string
          tokens_used: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          daily_message_count?: number
          id?: string
          last_message_date?: string | null
          message_count?: number
          period_end?: string
          period_start?: string
          tokens_used?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          daily_message_count?: number
          id?: string
          last_message_date?: string | null
          message_count?: number
          period_end?: string
          period_start?: string
          tokens_used?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_app_settings: {
        Row: {
          accent_color: string | null
          ai_auto_speak: boolean
          ai_auto_suggest: boolean
          ai_default_model: string
          ai_permission_analytics: boolean
          ai_permission_listings: boolean
          ai_permission_profile: boolean
          ai_personality: string
          ai_response_length: string
          ai_show_images: boolean
          ai_voice_enabled: boolean
          autoplay_gifs: boolean
          autoplay_product_cards: boolean | null
          autoplay_videos: boolean
          compact_mode: boolean
          created_at: string
          currency: string
          data_sharing: boolean
          email_notifications: boolean
          id: string
          language: string
          login_alerts: boolean
          marketing_emails: boolean
          marketplace_image_rotation: boolean
          notification_sound: boolean
          push_notifications: boolean
          reduced_motion: boolean
          save_search_history: boolean
          sms_notifications: boolean
          theme: string
          two_factor_enabled: boolean
          updated_at: string
          user_id: string
          video_quality: string
        }
        Insert: {
          accent_color?: string | null
          ai_auto_speak?: boolean
          ai_auto_suggest?: boolean
          ai_default_model?: string
          ai_permission_analytics?: boolean
          ai_permission_listings?: boolean
          ai_permission_profile?: boolean
          ai_personality?: string
          ai_response_length?: string
          ai_show_images?: boolean
          ai_voice_enabled?: boolean
          autoplay_gifs?: boolean
          autoplay_product_cards?: boolean | null
          autoplay_videos?: boolean
          compact_mode?: boolean
          created_at?: string
          currency?: string
          data_sharing?: boolean
          email_notifications?: boolean
          id?: string
          language?: string
          login_alerts?: boolean
          marketing_emails?: boolean
          marketplace_image_rotation?: boolean
          notification_sound?: boolean
          push_notifications?: boolean
          reduced_motion?: boolean
          save_search_history?: boolean
          sms_notifications?: boolean
          theme?: string
          two_factor_enabled?: boolean
          updated_at?: string
          user_id: string
          video_quality?: string
        }
        Update: {
          accent_color?: string | null
          ai_auto_speak?: boolean
          ai_auto_suggest?: boolean
          ai_default_model?: string
          ai_permission_analytics?: boolean
          ai_permission_listings?: boolean
          ai_permission_profile?: boolean
          ai_personality?: string
          ai_response_length?: string
          ai_show_images?: boolean
          ai_voice_enabled?: boolean
          autoplay_gifs?: boolean
          autoplay_product_cards?: boolean | null
          autoplay_videos?: boolean
          compact_mode?: boolean
          created_at?: string
          currency?: string
          data_sharing?: boolean
          email_notifications?: boolean
          id?: string
          language?: string
          login_alerts?: boolean
          marketing_emails?: boolean
          marketplace_image_rotation?: boolean
          notification_sound?: boolean
          push_notifications?: boolean
          reduced_motion?: boolean
          save_search_history?: boolean
          sms_notifications?: boolean
          theme?: string
          two_factor_enabled?: boolean
          updated_at?: string
          user_id?: string
          video_quality?: string
        }
        Relationships: []
      }
      user_behavior: {
        Row: {
          action_type: string
          ad_id: string | null
          category_filter: string | null
          created_at: string
          id: string
          location_filter: string | null
          price_max: number | null
          price_min: number | null
          search_query: string | null
          session_id: string | null
          user_id: string | null
        }
        Insert: {
          action_type: string
          ad_id?: string | null
          category_filter?: string | null
          created_at?: string
          id?: string
          location_filter?: string | null
          price_max?: number | null
          price_min?: number | null
          search_query?: string | null
          session_id?: string | null
          user_id?: string | null
        }
        Update: {
          action_type?: string
          ad_id?: string | null
          category_filter?: string | null
          created_at?: string
          id?: string
          location_filter?: string | null
          price_max?: number | null
          price_min?: number | null
          search_query?: string | null
          session_id?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_behavior_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      user_devices: {
        Row: {
          browser: string | null
          created_at: string | null
          device_name: string | null
          device_type: string | null
          id: string
          ip_address: unknown
          is_current: boolean | null
          is_trusted: boolean | null
          last_active_at: string | null
          location: string | null
          os: string | null
          user_id: string
        }
        Insert: {
          browser?: string | null
          created_at?: string | null
          device_name?: string | null
          device_type?: string | null
          id?: string
          ip_address?: unknown
          is_current?: boolean | null
          is_trusted?: boolean | null
          last_active_at?: string | null
          location?: string | null
          os?: string | null
          user_id: string
        }
        Update: {
          browser?: string | null
          created_at?: string | null
          device_name?: string | null
          device_type?: string | null
          id?: string
          ip_address?: unknown
          is_current?: boolean | null
          is_trusted?: boolean | null
          last_active_at?: string | null
          location?: string | null
          os?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_embeddings: {
        Row: {
          created_at: string | null
          last_computed_at: string | null
          preference_embedding: string | null
          search_embedding: string | null
          user_id: string
          view_embedding: string | null
        }
        Insert: {
          created_at?: string | null
          last_computed_at?: string | null
          preference_embedding?: string | null
          search_embedding?: string | null
          user_id: string
          view_embedding?: string | null
        }
        Update: {
          created_at?: string | null
          last_computed_at?: string | null
          preference_embedding?: string | null
          search_embedding?: string | null
          user_id?: string
          view_embedding?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_embeddings_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_generated_media: {
        Row: {
          context: Json | null
          created_at: string
          height: number | null
          id: string
          mime_type: string | null
          prompt: string | null
          source: string
          storage_path: string | null
          url: string
          user_id: string
          width: number | null
        }
        Insert: {
          context?: Json | null
          created_at?: string
          height?: number | null
          id?: string
          mime_type?: string | null
          prompt?: string | null
          source?: string
          storage_path?: string | null
          url: string
          user_id: string
          width?: number | null
        }
        Update: {
          context?: Json | null
          created_at?: string
          height?: number | null
          id?: string
          mime_type?: string | null
          prompt?: string | null
          source?: string
          storage_path?: string | null
          url?: string
          user_id?: string
          width?: number | null
        }
        Relationships: []
      }
      user_locations: {
        Row: {
          accuracy: string | null
          created_at: string | null
          district: string
          id: string
          latitude: number | null
          longitude: number | null
          region: string | null
          source: string | null
          sub_county: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          accuracy?: string | null
          created_at?: string | null
          district: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          region?: string | null
          source?: string | null
          sub_county?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          accuracy?: string | null
          created_at?: string | null
          district?: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          region?: string | null
          source?: string | null
          sub_county?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_login_history: {
        Row: {
          created_at: string | null
          device_id: string | null
          failure_reason: string | null
          id: string
          ip_address: unknown
          login_method: string | null
          login_status: string | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          device_id?: string | null
          failure_reason?: string | null
          id?: string
          ip_address?: unknown
          login_method?: string | null
          login_status?: string | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          device_id?: string | null
          failure_reason?: string | null
          id?: string
          ip_address?: unknown
          login_method?: string | null
          login_status?: string | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_login_history_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "user_devices"
            referencedColumns: ["id"]
          },
        ]
      }
      user_preferences: {
        Row: {
          created_at: string
          id: string
          last_active_location: string | null
          preferred_categories: string[] | null
          preferred_locations: string[] | null
          price_range_max: number | null
          price_range_min: number | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          last_active_location?: string | null
          preferred_categories?: string[] | null
          preferred_locations?: string[] | null
          price_range_max?: number | null
          price_range_min?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          last_active_location?: string | null
          preferred_categories?: string[] | null
          preferred_locations?: string[] | null
          price_range_max?: number | null
          price_range_min?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      user_privacy_settings: {
        Row: {
          allow_messages_from: string
          allow_tagging: boolean
          created_at: string
          id: string
          profile_visibility: string
          show_activity_status: boolean
          show_email: boolean
          show_listings_count: boolean
          show_location: boolean
          show_online_status: boolean
          show_phone: boolean
          show_social_links: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          allow_messages_from?: string
          allow_tagging?: boolean
          created_at?: string
          id?: string
          profile_visibility?: string
          show_activity_status?: boolean
          show_email?: boolean
          show_listings_count?: boolean
          show_location?: boolean
          show_online_status?: boolean
          show_phone?: boolean
          show_social_links?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          allow_messages_from?: string
          allow_tagging?: boolean
          created_at?: string
          id?: string
          profile_visibility?: string
          show_activity_status?: boolean
          show_email?: boolean
          show_listings_count?: boolean
          show_location?: boolean
          show_online_status?: boolean
          show_phone?: boolean
          show_social_links?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          expires_at: string | null
          granted_at: string
          granted_by: string | null
          id: string
          is_active: boolean
          role_name: string
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          granted_at?: string
          granted_by?: string | null
          id?: string
          is_active?: boolean
          role_name: string
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          granted_at?: string
          granted_by?: string | null
          id?: string
          is_active?: boolean
          role_name?: string
          user_id?: string
        }
        Relationships: []
      }
      verification_criteria: {
        Row: {
          account_age_days: number | null
          admin_approved: boolean | null
          avg_rating: number | null
          created_at: string | null
          has_video: boolean | null
          id: string
          is_verified: boolean | null
          profile_complete: boolean | null
          reviews_count: number | null
          seller_profile_id: string | null
          transactions_count: number | null
          updated_at: string | null
          user_id: string | null
          verification_score: number | null
        }
        Insert: {
          account_age_days?: number | null
          admin_approved?: boolean | null
          avg_rating?: number | null
          created_at?: string | null
          has_video?: boolean | null
          id?: string
          is_verified?: boolean | null
          profile_complete?: boolean | null
          reviews_count?: number | null
          seller_profile_id?: string | null
          transactions_count?: number | null
          updated_at?: string | null
          user_id?: string | null
          verification_score?: number | null
        }
        Update: {
          account_age_days?: number | null
          admin_approved?: boolean | null
          avg_rating?: number | null
          created_at?: string | null
          has_video?: boolean | null
          id?: string
          is_verified?: boolean | null
          profile_complete?: boolean | null
          reviews_count?: number | null
          seller_profile_id?: string | null
          transactions_count?: number | null
          updated_at?: string | null
          user_id?: string | null
          verification_score?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "verification_criteria_seller_profile_id_fkey"
            columns: ["seller_profile_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "verification_criteria_seller_profile_id_fkey"
            columns: ["seller_profile_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      verification_requests: {
        Row: {
          created_at: string | null
          date_of_birth: string
          district: string
          extracted_dob: string | null
          extracted_expiry: string | null
          extracted_id_number: string | null
          full_name: string
          gender: string
          id: string
          id_type: string | null
          national_id_back_url: string
          national_id_front_url: string
          nationality: string | null
          phone_number: string
          rejection_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          selfie_url: string
          status: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          date_of_birth: string
          district: string
          extracted_dob?: string | null
          extracted_expiry?: string | null
          extracted_id_number?: string | null
          full_name: string
          gender: string
          id?: string
          id_type?: string | null
          national_id_back_url: string
          national_id_front_url: string
          nationality?: string | null
          phone_number: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          selfie_url: string
          status?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          date_of_birth?: string
          district?: string
          extracted_dob?: string | null
          extracted_expiry?: string | null
          extracted_id_number?: string | null
          full_name?: string
          gender?: string
          id?: string
          id_type?: string | null
          national_id_back_url?: string
          national_id_front_url?: string
          nationality?: string | null
          phone_number?: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          selfie_url?: string
          status?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      verifications: {
        Row: {
          created_at: string
          document_url: string | null
          id: string
          notes: string | null
          status: string
          updated_at: string
          user_id: string
          verification_type: string
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          created_at?: string
          document_url?: string | null
          id?: string
          notes?: string | null
          status?: string
          updated_at?: string
          user_id: string
          verification_type: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          created_at?: string
          document_url?: string | null
          id?: string
          notes?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          verification_type?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: []
      }
      video_uploads: {
        Row: {
          b2_url: string | null
          created_at: string
          error: string | null
          file_name: string
          file_size: number | null
          file_type: string | null
          id: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          b2_url?: string | null
          created_at?: string
          error?: string | null
          file_name: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          b2_url?: string | null
          created_at?: string
          error?: string | null
          file_name?: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      volunteer_opportunities: {
        Row: {
          application_count: number | null
          application_deadline: string | null
          benefits_offered: string | null
          contact_email: string | null
          contact_phone: string | null
          created_at: string | null
          description: string
          end_date: string | null
          id: string
          is_active: boolean | null
          is_remote: boolean | null
          location: string | null
          organization_id: string | null
          requirements: string | null
          role_type: string | null
          seller_id: string | null
          skills_required: string[] | null
          spots_available: number | null
          spots_filled: number | null
          start_date: string | null
          status: string | null
          time_commitment: string | null
          title: string
          updated_at: string | null
          user_id: string
          view_count: number | null
        }
        Insert: {
          application_count?: number | null
          application_deadline?: string | null
          benefits_offered?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string | null
          description: string
          end_date?: string | null
          id?: string
          is_active?: boolean | null
          is_remote?: boolean | null
          location?: string | null
          organization_id?: string | null
          requirements?: string | null
          role_type?: string | null
          seller_id?: string | null
          skills_required?: string[] | null
          spots_available?: number | null
          spots_filled?: number | null
          start_date?: string | null
          status?: string | null
          time_commitment?: string | null
          title: string
          updated_at?: string | null
          user_id: string
          view_count?: number | null
        }
        Update: {
          application_count?: number | null
          application_deadline?: string | null
          benefits_offered?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string | null
          description?: string
          end_date?: string | null
          id?: string
          is_active?: boolean | null
          is_remote?: boolean | null
          location?: string | null
          organization_id?: string | null
          requirements?: string | null
          role_type?: string | null
          seller_id?: string | null
          skills_required?: string[] | null
          spots_available?: number | null
          spots_filled?: number | null
          start_date?: string | null
          status?: string | null
          time_commitment?: string | null
          title?: string
          updated_at?: string | null
          user_id?: string
          view_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "volunteer_opportunities_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organization_registrations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "volunteer_opportunities_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "volunteer_opportunities_seller_id_fkey"
            columns: ["seller_id"]
            isOneToOne: false
            referencedRelation: "seller_profiles_public"
            referencedColumns: ["id"]
          },
        ]
      }
      wallets: {
        Row: {
          balance: number
          created_at: string
          currency: string
          id: string
          is_active: boolean
          last_transaction_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          created_at?: string
          currency?: string
          id?: string
          is_active?: boolean
          last_transaction_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          created_at?: string
          currency?: string
          id?: string
          is_active?: boolean
          last_transaction_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      wizard_drafts: {
        Row: {
          created_at: string
          current_step: number
          form_data: Json
          id: string
          images_data: Json | null
          updated_at: string
          user_id: string
          wizard_type: string
        }
        Insert: {
          created_at?: string
          current_step?: number
          form_data?: Json
          id?: string
          images_data?: Json | null
          updated_at?: string
          user_id: string
          wizard_type: string
        }
        Update: {
          created_at?: string
          current_step?: number
          form_data?: Json
          id?: string
          images_data?: Json | null
          updated_at?: string
          user_id?: string
          wizard_type?: string
        }
        Relationships: []
      }
      workspace_analytics_daily: {
        Row: {
          created_at: string
          day: string
          engagements: number
          new_followers: number
          seller_id: string
          updated_at: string
          updates_count: number
          views: number
        }
        Insert: {
          created_at?: string
          day: string
          engagements?: number
          new_followers?: number
          seller_id: string
          updated_at?: string
          updates_count?: number
          views?: number
        }
        Update: {
          created_at?: string
          day?: string
          engagements?: number
          new_followers?: number
          seller_id?: string
          updated_at?: string
          updates_count?: number
          views?: number
        }
        Relationships: []
      }
    }
    Views: {
      seller_profiles_public: {
        Row: {
          business_bio: string | null
          business_logo_url: string | null
          business_name: string | null
          cover_image_url: string | null
          created_at: string | null
          current_service_status: string | null
          district: string | null
          follower_count: number | null
          following_count: number | null
          id: string | null
          is_verified: boolean | null
          portfolio_updated_at: string | null
          seller_type: string | null
          service_status_message: string | null
          store_slug: string | null
          user_id: string | null
          verification_badge_color: string | null
        }
        Insert: {
          business_bio?: string | null
          business_logo_url?: string | null
          business_name?: string | null
          cover_image_url?: string | null
          created_at?: string | null
          current_service_status?: string | null
          district?: string | null
          follower_count?: number | null
          following_count?: number | null
          id?: string | null
          is_verified?: boolean | null
          portfolio_updated_at?: string | null
          seller_type?: string | null
          service_status_message?: string | null
          store_slug?: string | null
          user_id?: string | null
          verification_badge_color?: string | null
        }
        Update: {
          business_bio?: string | null
          business_logo_url?: string | null
          business_name?: string | null
          cover_image_url?: string | null
          created_at?: string | null
          current_service_status?: string | null
          district?: string | null
          follower_count?: number | null
          following_count?: number | null
          id?: string | null
          is_verified?: boolean | null
          portfolio_updated_at?: string | null
          seller_type?: string | null
          service_status_message?: string | null
          store_slug?: string | null
          user_id?: string | null
          verification_badge_color?: string | null
        }
        Relationships: []
      }
      v_district_traffic: {
        Row: {
          district: string | null
          last_visit: string | null
          region: string | null
          seller_id: string | null
          visits: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      admin_ban_user: {
        Args: { admin_user_id: string; reason: string; target_user_id: string }
        Returns: undefined
      }
      admin_change_role: {
        Args: { _admin_id: string; _role_name: string }
        Returns: undefined
      }
      admin_get_emails: {
        Args: { _user_ids: string[] }
        Returns: {
          email: string
          user_id: string
        }[]
      }
      admin_get_user_labels: {
        Args: { _user_ids: string[] }
        Returns: {
          email: string
          name: string
          user_id: string
        }[]
      }
      admin_get_user_profiles: {
        Args: { _user_ids: string[] }
        Returns: {
          avatar_url: string
          email: string
          name: string
          provider: string
          providers: string[]
          user_id: string
        }[]
      }
      admin_grant_admin: {
        Args: { _role_name: string; _target_user_id: string }
        Returns: string
      }
      admin_list_admins: {
        Args: never
        Returns: {
          added_by: string
          admin_role_id: string
          created_at: string
          id: string
          is_active: boolean
          last_login: string
          role_name: string
          user_id: string
        }[]
      }
      admin_publish_app_update: {
        Args: {
          _app_store_url: string
          _is_forced: boolean
          _latest_version: string
          _min_version: string
          _play_store_url: string
          _release_notes: string
        }
        Returns: string
      }
      admin_recent_audit_logs: {
        Args: { _limit?: number }
        Returns: {
          action: string
          created_at: string
          id: string
          new_values: Json
          record_id: string
          table_name: string
          user_id: string
        }[]
      }
      admin_restore_user: {
        Args: { admin_user_id: string; target_user_id: string }
        Returns: undefined
      }
      admin_revoke_admin: { Args: { _admin_id: string }; Returns: undefined }
      admin_search_users_by_email: {
        Args: { _limit?: number; _q: string }
        Returns: {
          created_at: string
          email: string
          user_id: string
        }[]
      }
      admin_set_publish_toggle: {
        Args: { _enabled: boolean; _key: string }
        Returns: undefined
      }
      admin_suspend_user: {
        Args: {
          admin_user_id: string
          reason: string
          suspension_days: number
          target_user_id: string
        }
        Returns: undefined
      }
      calculate_profile_completion: {
        Args: { seller_profile_id: string }
        Returns: number
      }
      calculate_seller_score: { Args: { seller_id: string }; Returns: number }
      calculate_verification_score: {
        Args: { user_uuid: string }
        Returns: number
      }
      can_edit_profile_field: {
        Args: { p_field_name: string; p_user_id: string }
        Returns: boolean
      }
      cleanup_old_messages: { Args: never; Returns: undefined }
      create_notification: {
        Args: {
          p_action_url?: string
          p_message: string
          p_metadata?: Json
          p_title: string
          p_type: string
          p_user_id: string
        }
        Returns: string
      }
      delete_expired_ads: { Args: never; Returns: undefined }
      expire_promotions: { Args: never; Returns: undefined }
      find_similar_users: {
        Args: {
          match_count?: number
          match_threshold?: number
          query_embedding: string
        }
        Returns: {
          similarity: number
          user_id: string
        }[]
      }
      generate_store_slug: { Args: { business_name: string }; Returns: string }
      get_personalized_ads: {
        Args: { match_count?: number; p_user_id: string }
        Returns: {
          ad_id: string
          category: string
          images: string[]
          price: number
          similarity: number
          title: string
        }[]
      }
      get_public_user_profiles: {
        Args: { p_user_ids: string[] }
        Returns: {
          avatar_url: string
          display_name: string
          user_id: string
        }[]
      }
      get_related_items_by_category: {
        Args: {
          exclude_ids?: string[]
          result_limit?: number
          search_category?: string
        }
        Returns: {
          category: string
          created_at: string
          description: string
          id: string
          images: string[]
          is_boosted: boolean
          location: string
          price: number
          seller_id: string
          title: string
        }[]
      }
      get_remaining_edits: {
        Args: { p_field_name: string; p_user_id: string }
        Returns: {
          next_available: string
          remaining: number
        }[]
      }
      get_seller_analytics: {
        Args: {
          p_days?: number
          p_listing_id?: string
          p_seller_id: string
          p_user_id: string
        }
        Returns: Json
      }
      increment_ai_usage: {
        Args: { p_tokens?: number; p_user_id: string }
        Returns: Json
      }
      is_account_active: { Args: { user_uuid: string }; Returns: boolean }
      is_admin: { Args: { user_uuid: string }; Returns: boolean }
      is_app_admin: { Args: { _user_id: string }; Returns: boolean }
      is_authenticated: { Args: never; Returns: boolean }
      is_blocked: { Args: { user_a: string; user_b: string }; Returns: boolean }
      is_kb_admin: { Args: { _uid: string }; Returns: boolean }
      is_super_admin: { Args: { _user_id: string }; Returns: boolean }
      match_knowledge: {
        Args: {
          match_count?: number
          min_similarity?: number
          query_embedding: string
        }
        Returns: {
          chunk_id: string
          content: string
          doc_category: string
          doc_slug: string
          doc_summary: string
          doc_title: string
          doc_updated_at: string
          document_id: string
          similarity: number
        }[]
      }
      match_knowledge_keyword: {
        Args: { match_count?: number; query_text: string }
        Returns: {
          chunk_id: string
          content: string
          doc_category: string
          doc_slug: string
          doc_summary: string
          doc_title: string
          doc_updated_at: string
          document_id: string
          rank: number
        }[]
      }
      process_expired_subscriptions: { Args: never; Returns: undefined }
      recompute_seller_focus: {
        Args: { _seller_id: string }
        Returns: undefined
      }
      record_workspace_engagement: {
        Args: { p_seller_id: string }
        Returns: undefined
      }
      record_workspace_view: {
        Args: { p_seller_id: string }
        Returns: undefined
      }
      restore_expired_promotion_prices: { Args: never; Returns: undefined }
      search_ads_by_similarity: {
        Args: {
          match_count?: number
          match_threshold?: number
          query_embedding: string
        }
        Returns: {
          category: string
          description: string
          id: string
          images: string[]
          location: string
          price: number
          similarity: number
          title: string
        }[]
      }
      search_ads_fulltext:
        | {
            Args: { match_limit?: number; search_query: string }
            Returns: {
              brand: string
              category: string
              condition: string
              created_at: string
              description: string
              has_discount: boolean
              id: string
              images: string[]
              is_boosted: boolean
              listing_type: string
              location: string
              model: string
              original_price: number
              price: number
              rank: number
              seller_id: string
              title: string
            }[]
          }
        | {
            Args: {
              listing_types?: string[]
              match_limit?: number
              result_limit?: number
              search_query: string
            }
            Returns: {
              brand: string
              category: string
              condition: string
              created_at: string
              description: string
              has_discount: boolean
              id: string
              images: string[]
              is_boosted: boolean
              listing_type: string
              location: string
              model: string
              original_price: number
              price: number
              rank: number
              seller_id: string
              subcategory: string
              title: string
            }[]
          }
      update_seller_scores: { Args: never; Returns: undefined }
      update_subscription_status: { Args: never; Returns: undefined }
      validate_and_consume_invite_code: {
        Args: { p_code: string }
        Returns: boolean
      }
    }
    Enums: {
      notification_event_type:
        | "new_message"
        | "new_follower"
        | "new_ad_from_followed_seller"
        | "ad_boosted"
        | "application_received"
        | "application_status_updated"
        | "review_received"
        | "post_liked"
        | "post_commented"
        | "payment_completed"
        | "verification_approved"
        | "verification_rejected"
        | "ad_approved"
        | "ad_rejected"
        | "new_order"
        | "order_status_updated"
      payment_provider: "mtn_momo" | "airtel_money" | "stripe_card"
      payment_status_enum:
        | "pending"
        | "processing"
        | "completed"
        | "failed"
        | "cancelled"
        | "refunded"
      seller_badge_level: "basic" | "verified" | "trusted"
      subscription_status_enum:
        | "active"
        | "cancelled"
        | "past_due"
        | "expired"
        | "trial"
      verification_step_status:
        | "not_started"
        | "pending"
        | "submitted"
        | "approved"
        | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      notification_event_type: [
        "new_message",
        "new_follower",
        "new_ad_from_followed_seller",
        "ad_boosted",
        "application_received",
        "application_status_updated",
        "review_received",
        "post_liked",
        "post_commented",
        "payment_completed",
        "verification_approved",
        "verification_rejected",
        "ad_approved",
        "ad_rejected",
        "new_order",
        "order_status_updated",
      ],
      payment_provider: ["mtn_momo", "airtel_money", "stripe_card"],
      payment_status_enum: [
        "pending",
        "processing",
        "completed",
        "failed",
        "cancelled",
        "refunded",
      ],
      seller_badge_level: ["basic", "verified", "trusted"],
      subscription_status_enum: [
        "active",
        "cancelled",
        "past_due",
        "expired",
        "trial",
      ],
      verification_step_status: [
        "not_started",
        "pending",
        "submitted",
        "approved",
        "rejected",
      ],
    },
  },
} as const
