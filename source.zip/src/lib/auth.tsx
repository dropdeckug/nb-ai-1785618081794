import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type BusinessProfile = {
  user_id: string;
  business_name: string | null;
  business_logo_url: string | null;
  business_bio: string | null;
  is_verified: boolean | null;
  cover_image_url: string | null;
  follower_count: number | null;
};

type AuthCtx = {
  user: User | null;
  session: Session | null;
  loading: boolean;
  business: BusinessProfile | null;
  signOut: () => Promise<void>;
};

const Ctx = createContext<AuthCtx>({
  user: null,
  session: null,
  loading: true,
  business: null,
  signOut: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [business, setBusiness] = useState<BusinessProfile | null>(null);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const uid = session?.user?.id;
    if (!uid) {
      setBusiness(null);
      return;
    }
    supabase
      .from("seller_profiles_public")
      .select("user_id,business_name,business_logo_url,business_bio,is_verified,cover_image_url,follower_count")
      .eq("user_id", uid)
      .maybeSingle()
      .then(({ data }) => setBusiness((data as BusinessProfile) ?? null));
  }, [session?.user?.id]);

  const value: AuthCtx = {
    user: session?.user ?? null,
    session,
    loading,
    business,
    signOut: async () => {
      await supabase.auth.signOut();
    },
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);
