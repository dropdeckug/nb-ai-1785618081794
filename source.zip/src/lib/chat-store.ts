import { create } from "zustand";

export type ChatMessage = { role: "user" | "assistant"; content: string };

export type ChatThread = {
  id: string;
  initialPrompt: string;
  messages: ChatMessage[]; // full history including assistant replies
  createdAt: number;
  /** When set, ask page will auto-send this on mount (fresh thread from `/`). */
  pendingPrompt?: string | null;
};

type State = {
  threads: Record<string, ChatThread>;
  createThread: (prompt: string) => string;
  getThread: (id: string) => ChatThread | undefined;
  setMessages: (id: string, messages: ChatMessage[]) => void;
  appendMessage: (id: string, msg: ChatMessage) => void;
  updateLastAssistant: (id: string, content: string) => void;
  setPending: (id: string, prompt: string | null) => void;
  hydrate: (id: string, messages: ChatMessage[], initialPrompt: string) => void;
};

export const useChatStore = create<State>((set, get) => ({
  threads: {},
  createThread: (prompt) => {
    const id = Math.random().toString(36).slice(2, 10);
    const t: ChatThread = {
      id,
      initialPrompt: prompt,
      messages: [],
      createdAt: Date.now(),
      pendingPrompt: prompt,
    };
    set((s) => ({ threads: { ...s.threads, [id]: t } }));
    return id;
  },
  getThread: (id) => get().threads[id],
  setMessages: (id, messages) =>
    set((s) =>
      s.threads[id]
        ? { threads: { ...s.threads, [id]: { ...s.threads[id], messages } } }
        : s,
    ),
  appendMessage: (id, msg) =>
    set((s) => {
      const t = s.threads[id];
      if (!t) return s;
      return {
        threads: {
          ...s.threads,
          [id]: { ...t, messages: [...t.messages, msg] },
        },
      };
    }),
  updateLastAssistant: (id, content) =>
    set((s) => {
      const t = s.threads[id];
      if (!t || t.messages.length === 0) return s;
      const last = t.messages[t.messages.length - 1];
      if (last.role !== "assistant") return s;
      const next = t.messages.slice(0, -1).concat({ ...last, content });
      return { threads: { ...s.threads, [id]: { ...t, messages: next } } };
    }),
  setPending: (id, prompt) =>
    set((s) =>
      s.threads[id]
        ? {
            threads: {
              ...s.threads,
              [id]: { ...s.threads[id], pendingPrompt: prompt },
            },
          }
        : s,
    ),
  hydrate: (id, messages, initialPrompt) =>
    set((s) => ({
      threads: {
        ...s.threads,
        [id]: s.threads[id]
          ? { ...s.threads[id], messages, initialPrompt }
          : {
              id,
              initialPrompt,
              messages,
              createdAt: Date.now(),
              pendingPrompt: null,
            },
      },
    })),
}));
