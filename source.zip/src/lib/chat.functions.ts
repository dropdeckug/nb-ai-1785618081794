import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";

/**
 * earlymarket AI server function.
 *
 * Pipeline:
 *  1. Intent classification — small AI call deciding whether the user query
 *     needs marketplace data and which sources to consult.
 *  2. Real Supabase fetches for the requested sources (sellers, products,
 *     services, jobs, promotions, posts) using the publishable key.
 *  3. Final AI synthesis with the fetched context, returning a markdown answer.
 *
 * The response shape includes a `plan` of steps (each with kind, label, count,
 * sample items / sellers) plus a flat `sources` list and an `images` list,
 * so the client can drive a dynamic timeline animation and a sources dialog.
 */

type StepKind =
  | "intent"
  | "sellers"
  | "products"
  | "services"
  | "jobs"
  | "promotions"
  | "posts"
  | "discounts"
  | "drafting";

export type PlanSeller = {
  user_id: string;
  business_name: string | null;
  business_logo_url: string | null;
  is_verified: boolean | null;
};

export type PlanItem = {
  id: string;
  title: string;
  type: string; // "product" | "service" | "job" | "promotion" | "post"
  image: string | null;
  seller_id?: string | null;
  has_discount?: boolean | null;
  price?: number | null;
  currency?: string | null;
  url?: string | null;
};

export type PlanStep = {
  kind: StepKind;
  label: string;
  query?: string;
  count?: number;
  sellers?: PlanSeller[];
  items?: PlanItem[];
};

export type AskResponse =
  | {
      ok: true;
      intent: "marketplace" | "chat";
      plan: PlanStep[];
      answer: string;
      title: string;
      sources: PlanItem[];
      images: string[];
    }
  | { ok: false; error: string };

const MARKETPLACE_KINDS = [
  "products",
  "services",
  "jobs",
  "promotions",
  "posts",
  "sellers",
] as const;
type MarketplaceKind = (typeof MARKETPLACE_KINDS)[number];

async function classifyIntent(prompt: string, apiKey: string) {
  const sys = `You are an intent router for the earlymarket Uganda marketplace assistant.
Decide whether the user's message requires looking up marketplace data
(listings, products, services, jobs, promotions, posts, sellers) or whether
it is a casual / general question that can be answered without DB access.
Respond ONLY with strict JSON of the form:
{"needs_marketplace": boolean, "sources": ["products"|"services"|"jobs"|"promotions"|"posts"|"sellers"], "topic": "<short topic>"}
Pick only sources clearly implied by the question. If unsure but it's plausibly marketplace-related, default sources to ["products","sellers"].`;

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-3.1-flash-lite-preview",
      messages: [
        { role: "system", content: sys },
        { role: "user", content: prompt },
      ],
      response_format: { type: "json_object" },
    }),
  });
  if (!res.ok) throw new Error(`Intent ${res.status}`);
  const j = await res.json();
  const txt: string = j.choices?.[0]?.message?.content ?? "{}";
  try {
    const parsed = JSON.parse(txt);
    const sources = Array.isArray(parsed.sources)
      ? parsed.sources.filter((s: string): s is MarketplaceKind =>
          (MARKETPLACE_KINDS as readonly string[]).includes(s),
        )
      : [];
    return {
      needs_marketplace: !!parsed.needs_marketplace,
      sources: sources as MarketplaceKind[],
      topic: typeof parsed.topic === "string" ? parsed.topic : prompt.slice(0, 60),
    };
  } catch {
    return { needs_marketplace: false, sources: [] as MarketplaceKind[], topic: prompt.slice(0, 60) };
  }
}

function makeSb() {
  const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const key =
    process.env.SUPABASE_PUBLISHABLE_KEY ||
    process.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
    process.env.VITE_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error("Supabase env not configured for server fn");
  return createClient(url, key, { auth: { persistSession: false } });
}

function adToItem(a: any, kind: string): PlanItem {
  return {
    id: a.id,
    title: a.title,
    type: kind,
    image: Array.isArray(a.images) && a.images.length ? a.images[0] : null,
    seller_id: a.seller_id ?? null,
    has_discount: !!a.has_discount,
    price: a.price ?? null,
    currency: a.currency ?? null,
  };
}

function postToItem(p: any): PlanItem {
  return {
    id: p.id,
    title: p.title || (p.content ?? "").slice(0, 80) || "Post",
    type: "post",
    image: Array.isArray(p.images) && p.images.length ? p.images[0] : null,
    seller_id: p.seller_id ?? p.user_id ?? null,
  };
}

async function fetchListings(
  sb: ReturnType<typeof makeSb>,
  topic: string,
  kind: "products" | "services" | "jobs" | "promotions",
) {
  const typeMap = {
    products: "physical_products",
    services: "services",
    jobs: "jobs",
    promotions: "promotions",
  } as const;
  const t = typeMap[kind];
  // count
  const { count } = await sb
    .from("ads")
    .select("id", { count: "exact", head: true })
    .eq("status", "active")
    .eq("listing_type", t);
  // sample (with simple textual relevance)
  let q = sb
    .from("ads")
    .select(
      "id,title,description,images,seller_id,has_discount,price,currency,view_count",
    )
    .eq("status", "active")
    .eq("listing_type", t);
  if (topic && topic.length > 2) {
    const safe = topic.replace(/[%,()]/g, " ").trim().slice(0, 40);
    if (safe) q = q.or(`title.ilike.%${safe}%,description.ilike.%${safe}%`);
  }
  const { data } = await q.order("view_count", { ascending: false }).limit(8);
  let items = (data ?? []).map((a) => adToItem(a, kind.slice(0, -1)));
  if (items.length === 0) {
    // fallback to most viewed if no topic match
    const { data: d2 } = await sb
      .from("ads")
      .select("id,title,images,seller_id,has_discount,price,currency")
      .eq("status", "active")
      .eq("listing_type", t)
      .order("view_count", { ascending: false })
      .limit(6);
    items = (d2 ?? []).map((a) => adToItem(a, kind.slice(0, -1)));
  }
  return { count: count ?? items.length, items };
}

async function fetchSellers(sb: ReturnType<typeof makeSb>, topic: string) {
  const { count } = await sb
    .from("seller_profiles_public")
    .select("user_id", { count: "exact", head: true });
  let q = sb
    .from("seller_profiles_public")
    .select("user_id,business_name,business_logo_url,is_verified,follower_count");
  if (topic && topic.length > 2) {
    const safe = topic.replace(/[%,()]/g, " ").trim().slice(0, 40);
    if (safe) q = q.ilike("business_name", `%${safe}%`);
  }
  const { data } = await q
    .order("follower_count", { ascending: false, nullsFirst: false })
    .limit(8);
  let sellers = (data ?? []) as PlanSeller[];
  if (sellers.length === 0) {
    const { data: d2 } = await sb
      .from("seller_profiles_public")
      .select("user_id,business_name,business_logo_url,is_verified,follower_count")
      .order("follower_count", { ascending: false, nullsFirst: false })
      .limit(8);
    sellers = (d2 ?? []) as PlanSeller[];
  }
  return { count: count ?? sellers.length, sellers };
}

async function fetchPosts(sb: ReturnType<typeof makeSb>, topic: string) {
  const { count } = await sb
    .from("posts")
    .select("id", { count: "exact", head: true })
    .eq("is_active", true);
  let q = sb
    .from("posts")
    .select("id,title,content,images,seller_id,user_id,like_count,view_count")
    .eq("is_active", true);
  if (topic && topic.length > 2) {
    const safe = topic.replace(/[%,()]/g, " ").trim().slice(0, 40);
    if (safe) q = q.or(`title.ilike.%${safe}%,content.ilike.%${safe}%`);
  }
  const { data } = await q.order("view_count", { ascending: false }).limit(6);
  let items = (data ?? []).map(postToItem);
  if (items.length === 0) {
    const { data: d2 } = await sb
      .from("posts")
      .select("id,title,content,images,seller_id,user_id,view_count")
      .eq("is_active", true)
      .order("view_count", { ascending: false })
      .limit(4);
    items = (d2 ?? []).map(postToItem);
  }
  return { count: count ?? items.length, items };
}

async function buildPlan(prompt: string, intent: Awaited<ReturnType<typeof classifyIntent>>) {
  const plan: PlanStep[] = [];
  const allItems: PlanItem[] = [];
  const allImages: string[] = [];

  if (!intent.needs_marketplace || intent.sources.length === 0) {
    return { plan, items: allItems, images: allImages, sellersAll: [] as PlanSeller[] };
  }

  const sb = makeSb();

  // Always start with seller scan if sellers are requested OR if we'll need
  // to render seller chips for listing steps.
  const wantSellers = intent.sources.includes("sellers");
  const wantListings = intent.sources.some(
    (s) => s === "products" || s === "services" || s === "jobs" || s === "promotions",
  );

  let sellersAll: PlanSeller[] = [];
  if (wantSellers || wantListings) {
    const { count, sellers } = await fetchSellers(sb, intent.topic);
    sellersAll = sellers;
    plan.push({
      kind: "sellers",
      label: "Scanning sellers",
      query: intent.topic,
      count,
      sellers,
    });
  }

  for (const src of intent.sources) {
    if (src === "sellers") continue;
    if (src === "posts") {
      const { count, items } = await fetchPosts(sb, intent.topic);
      plan.push({
        kind: "posts",
        label: "Reading community posts",
        query: intent.topic,
        count,
        items,
      });
      allItems.push(...items);
      items.forEach((i) => i.image && allImages.push(i.image));
    } else {
      const { count, items } = await fetchListings(sb, intent.topic, src);
      const labelMap: Record<typeof src, string> = {
        products: "Reading product listings",
        services: "Reading service offerings",
        jobs: "Reading job postings",
        promotions: "Reading active promotions",
      };
      plan.push({
        kind: src,
        label: labelMap[src],
        query: intent.topic,
        count,
        items,
      });
      allItems.push(...items);
      items.forEach((i) => i.image && allImages.push(i.image));
      // surface a discounts sub-step when relevant
      if (src === "products" || src === "promotions") {
        const discounted = items.filter((i) => i.has_discount);
        if (discounted.length > 0) {
          plan.push({
            kind: "discounts",
            label: `Found ${discounted.length} with discounts`,
            count: discounted.length,
            items: discounted,
          });
        }
      }
    }
  }

  return { plan, items: allItems, images: Array.from(new Set(allImages)).slice(0, 8), sellersAll };
}

async function synthesizeAnswer(
  prompt: string,
  context: { plan: PlanStep[]; sellers: PlanSeller[] },
  apiKey: string,
) {
  const ctx = {
    sellers: context.sellers.slice(0, 8).map((s) => ({
      name: s.business_name,
      verified: !!s.is_verified,
    })),
    listings: context.plan
      .flatMap((p) => (p.items ?? []).map((i) => ({ kind: p.kind, title: i.title, has_discount: i.has_discount, price: i.price })))
      .slice(0, 24),
    counts: Object.fromEntries(context.plan.map((p) => [p.kind, p.count ?? 0])),
  };

  const sys = `You are earlymarket AI, the assistant for the EarlyMarket Uganda marketplace (earlymarketug.com).
The platform hosts: physical products, digital products, services (with service workspaces that include catalogs, offerings, portfolios, FAQs, testimonials and status updates), jobs, promotions/discounts, events, posts, tenders and volunteer opportunities. Sellers have business profiles with logos, bios, verification badges and follower counts.
- Answer concisely in clean markdown: short headings, bullet lists, **bold** key terms.
- Use ONLY the provided context. Never invent listings, sellers, prices, or links.
- When context contains service workspaces, mention their catalogs, offerings and testimonials where relevant.
- If the context is empty (general/chat question), answer plainly without mentioning the marketplace unless asked.
- Never mention "Lovable" or any vendor/model. Refer to yourself as "earlymarket AI" if needed.
- Keep total length focused; prefer information density over filler.`;

  const userMsg = `User question: ${prompt}\n\nMarketplace context (JSON):\n${JSON.stringify(ctx)}`;

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-3.1-flash-lite-preview",
      messages: [
        { role: "system", content: sys },
        { role: "user", content: userMsg },
      ],
    }),
  });
  if (!res.ok) {
    if (res.status === 429) throw new Error("Rate limited. Please try again in a moment.");
    if (res.status === 402)
      throw new Error("AI credits exhausted. Add funds in Settings → Workspace → Usage.");
    throw new Error(`AI request failed (${res.status}).`);
  }
  const j = await res.json();
  return (j.choices?.[0]?.message?.content as string) || "";
}

export const askEarlymarket = createServerFn({ method: "POST" })
  .inputValidator((data: { prompt: string }) => data)
  .handler(async ({ data }): Promise<AskResponse> => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey)
      return {
        ok: false,
        error:
          "LOVABLE_API_KEY is not configured on the server. On Cloudflare Workers, add it with: `wrangler secret put LOVABLE_API_KEY` (or in Dashboard → Workers → Settings → Variables → Secrets), then redeploy.",
      };

    try {
      const intent = await classifyIntent(data.prompt, apiKey);
      const { plan, items, images, sellersAll } = await buildPlan(data.prompt, intent);

      // Drafting step (always last)
      plan.push({ kind: "drafting", label: "Drafting answer with earlymarket AI" });

      const answer = await synthesizeAnswer(
        data.prompt,
        { plan, sellers: sellersAll },
        apiKey,
      );

      // Cheap title generation (3-6 words, no quotes)
      let title = data.prompt.slice(0, 60);
      try {
        const tRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            model: "google/gemini-3.1-flash-lite-preview",
            messages: [
              { role: "system", content: "Generate a 3-6 word concise chat title for the user's question. Output ONLY the title, no quotes, no punctuation at the end." },
              { role: "user", content: data.prompt },
            ],
          }),
        });
        if (tRes.ok) {
          const tj = await tRes.json();
          const t = (tj.choices?.[0]?.message?.content as string)?.trim();
          if (t) title = t.replace(/^["']|["']$/g, "").slice(0, 80);
        }
      } catch {
        /* ignore */
      }

      return {
        ok: true,
        intent: intent.needs_marketplace ? "marketplace" : "chat",
        plan,
        answer: answer || "_(empty response)_",
        title,
        sources: items,
        images,
      };
    } catch (e) {
      console.error("askEarlymarket error:", e);
      return { ok: false, error: e instanceof Error ? e.message : "Unknown error" };
    }
  });
