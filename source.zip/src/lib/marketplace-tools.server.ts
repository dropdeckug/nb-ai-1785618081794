/**
 * Marketplace tool executors used by /api/chat.
 * All read via the public Supabase key with broad ILIKE + fallback.
 * Server-only.
 */
import { createClient } from "@supabase/supabase-js";

export function makeSb() {
  const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const key =
    process.env.SUPABASE_PUBLISHABLE_KEY ||
    process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Supabase env not configured");
  return createClient(url, key, { auth: { persistSession: false } });
}

type Sb = ReturnType<typeof makeSb>;

function tokens(q: string): string[] {
  return (q || "")
    .toLowerCase()
    .replace(/[%_(),]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length >= 2)
    .slice(0, 5);
}

function orClause(fields: string[], words: string[]): string {
  const parts: string[] = [];
  for (const w of words) {
    const safe = w.replace(/,/g, " ");
    for (const f of fields) parts.push(`${f}.ilike.%${safe}%`);
  }
  return parts.join(",");
}

/* ------------ Sellers ------------ */
export async function findSellers(sb: Sb, query: string, limit = 10) {
  const words = tokens(query);
  const fields = ["business_name", "business_bio", "store_slug", "district"];
  let items: any[] = [];
  if (words.length) {
    const { data } = await sb
      .from("seller_profiles_public")
      .select(
        "user_id,business_name,business_logo_url,is_verified,follower_count,business_bio,district,store_slug",
      )
      .or(orClause(fields, words))
      .order("follower_count", { ascending: false, nullsFirst: false })
      .limit(limit);
    items = data ?? [];
  }
  if (items.length === 0) {
    // broaden — fall back to top sellers so we always return something
    const { data } = await sb
      .from("seller_profiles_public")
      .select(
        "user_id,business_name,business_logo_url,is_verified,follower_count,business_bio,district,store_slug",
      )
      .order("follower_count", { ascending: false, nullsFirst: false })
      .limit(limit);
    items = data ?? [];
  }
  return items;
}

/* ------------ Ads (products/services/jobs/promotions) ------------ */
// Rich per-type column sets so the AI sees every tiny detail on the ad.
const AD_SELECT_COMMON =
  "id,title,description,images,seller_id,category,subcategory,tags,price,currency,original_price,has_discount,is_price_negotiable,location,view_count,save_count,engagement_score,is_boosted,is_sponsored,youtube_url,tiktok_url,b2_video_url,video_thumbnail_url,created_at";

const AD_SELECT_BY_TYPE: Record<string, string> = {
  physical_products:
    AD_SELECT_COMMON +
    ",condition,brand,model,color,size,weight,dimensions,features,warranty,year_manufactured,inventory_count,shipping_options,pickup_available",
  services:
    AD_SELECT_COMMON +
    ",features,accepts_quotes,followers_count,testimonials_count,update_count,last_update_at",
  jobs: AD_SELECT_COMMON + ",features,expires_at",
  promotions: AD_SELECT_COMMON + ",expires_at,sponsored_until",
};

async function attachSellers(sb: Sb, rows: any[]) {
  const ids = Array.from(new Set(rows.map((r) => r.seller_id).filter(Boolean)));
  if (!ids.length) return rows;
  const { data } = await sb
    .from("seller_profiles_public")
    .select(
      "user_id,business_name,business_logo_url,is_verified,store_slug,district,follower_count",
    )
    .in("user_id", ids);
  const map = new Map((data ?? []).map((s: any) => [s.user_id, s]));
  return rows.map((r) => ({ ...r, seller: map.get(r.seller_id) ?? null }));
}

async function findAds(
  sb: Sb,
  query: string,
  listing_type: "physical_products" | "services" | "jobs" | "promotions",
  limit = 10,
) {
  const words = tokens(query);
  const sel = AD_SELECT_BY_TYPE[listing_type] ?? AD_SELECT_COMMON;
  const fields = ["title", "description", "brand", "model", "features"];
  let items: any[] = [];
  if (words.length) {
    const { data } = await sb
      .from("ads")
      .select(sel)
      .eq("status", "active")
      .eq("listing_type", listing_type)
      .or(orClause(fields, words))
      .order("engagement_score", { ascending: false, nullsFirst: false })
      .limit(limit);
    items = data ?? [];
  }
  if (items.length === 0 && words.length) {
    const { data } = await sb
      .from("ads")
      .select(sel)
      .eq("status", "active")
      .eq("listing_type", listing_type)
      .or(orClause(["category", "subcategory", "location"], words))
      .order("view_count", { ascending: false })
      .limit(limit);
    items = data ?? [];
  }
  if (items.length === 0) {
    const { data } = await sb
      .from("ads")
      .select(sel)
      .eq("status", "active")
      .eq("listing_type", listing_type)
      .order("view_count", { ascending: false })
      .limit(limit);
    items = data ?? [];
  }
  return attachSellers(sb, items);
}

export const findProducts = (sb: Sb, q: string, limit = 10) =>
  findAds(sb, q, "physical_products", limit);
export const findServices = (sb: Sb, q: string, limit = 10) =>
  findAds(sb, q, "services", limit);
export const findJobs = (sb: Sb, q: string, limit = 10) =>
  findAds(sb, q, "jobs", limit);
export const findPromotions = (sb: Sb, q: string, limit = 10) =>
  findAds(sb, q, "promotions", limit);

/* ------------ Service workspaces ------------ */
export async function findServiceCatalogs(sb: Sb, query: string, limit = 8) {
  const words = tokens(query);
  const select = "id,name,description,seller_id,cover_image_url";
  let items: any[] = [];
  if (words.length) {
    const { data } = await sb
      .from("service_catalogs")
      .select(select)
      .or(orClause(["name", "description"], words))
      .limit(limit);
    items = data ?? [];
  }
  if (items.length === 0) {
    const { data } = await sb.from("service_catalogs").select(select).limit(limit);
    items = data ?? [];
  }
  return items;
}

/* ------------ Posts ------------ */
export async function findPosts(sb: Sb, query: string, limit = 8) {
  const words = tokens(query);
  const select =
    "id,title,content,images,seller_id,user_id,like_count,view_count";
  let items: any[] = [];
  if (words.length) {
    const { data } = await sb
      .from("posts")
      .select(select)
      .eq("is_active", true)
      .or(orClause(["title", "content"], words))
      .order("view_count", { ascending: false })
      .limit(limit);
    items = data ?? [];
  }
  if (items.length === 0) {
    const { data } = await sb
      .from("posts")
      .select(select)
      .eq("is_active", true)
      .order("view_count", { ascending: false })
      .limit(limit);
    items = data ?? [];
  }
  return items;
}

/* ------------ Events ------------ */
export async function findEvents(sb: Sb, query: string, limit = 8) {
  const words = tokens(query);
  const select = "id,title,description,cover_image_url,start_date,end_date,location,is_free,ticket_price";
  let items: any[] = [];
  if (words.length) {
    const { data } = await sb
      .from("events")
      .select(select)
      .or(orClause(["title", "description", "location"], words))
      .order("start_date", { ascending: true })
      .limit(limit);
    items = data ?? [];
  }
  if (items.length === 0) {
    const { data } = await sb
      .from("events")
      .select(select)
      .order("start_date", { ascending: true })
      .limit(limit);
    items = data ?? [];
  }
  return items;
}

/* ================== Function declarations (Google AI Studio format) ================== */
export const TOOL_DECLARATIONS = [
  {
    name: "find_sellers",
    description:
      "Search sellers/businesses on earlymarket. Broad text search over business name, bio, district, slug. ALWAYS returns results (falls back to top sellers by follower count if no match).",
    parameters: {
      type: "OBJECT",
      properties: {
        query: { type: "STRING", description: "Free-text search terms" },
        limit: { type: "INTEGER" },
      },
      required: ["query"],
    },
  },
  {
    name: "find_products",
    description:
      "Search physical products for sale. Broad text over title, description, category. ALWAYS returns results.",
    parameters: {
      type: "OBJECT",
      properties: {
        query: { type: "STRING" },
        limit: { type: "INTEGER" },
      },
      required: ["query"],
    },
  },
  {
    name: "find_services",
    description: "Search service listings/offerings.",
    parameters: {
      type: "OBJECT",
      properties: { query: { type: "STRING" }, limit: { type: "INTEGER" } },
      required: ["query"],
    },
  },
  {
    name: "find_jobs",
    description: "Search job listings.",
    parameters: {
      type: "OBJECT",
      properties: { query: { type: "STRING" }, limit: { type: "INTEGER" } },
      required: ["query"],
    },
  },
  {
    name: "find_promotions",
    description: "Search current promotions and discount campaigns.",
    parameters: {
      type: "OBJECT",
      properties: { query: { type: "STRING" }, limit: { type: "INTEGER" } },
      required: ["query"],
    },
  },
  {
    name: "find_service_catalogs",
    description:
      "Search seller service workspaces (service catalogs) — these hold offerings, portfolios, testimonials and status updates.",
    parameters: {
      type: "OBJECT",
      properties: { query: { type: "STRING" }, limit: { type: "INTEGER" } },
      required: ["query"],
    },
  },
  {
    name: "find_posts",
    description: "Search community posts.",
    parameters: {
      type: "OBJECT",
      properties: { query: { type: "STRING" }, limit: { type: "INTEGER" } },
      required: ["query"],
    },
  },
  {
    name: "find_events",
    description: "Search upcoming or past events.",
    parameters: {
      type: "OBJECT",
      properties: { query: { type: "STRING" }, limit: { type: "INTEGER" } },
      required: ["query"],
    },
  },
];

export type ToolName =
  | "find_sellers"
  | "find_products"
  | "find_services"
  | "find_jobs"
  | "find_promotions"
  | "find_service_catalogs"
  | "find_posts"
  | "find_events";

export async function runTool(sb: Sb, name: ToolName, args: any) {
  const q = String(args?.query ?? "");
  const limit = Math.min(Math.max(Number(args?.limit ?? 8), 1), 20);
  switch (name) {
    case "find_sellers":
      return { sellers: await findSellers(sb, q, limit) };
    case "find_products":
      return { products: await findProducts(sb, q, limit) };
    case "find_services":
      return { services: await findServices(sb, q, limit) };
    case "find_jobs":
      return { jobs: await findJobs(sb, q, limit) };
    case "find_promotions":
      return { promotions: await findPromotions(sb, q, limit) };
    case "find_service_catalogs":
      return { catalogs: await findServiceCatalogs(sb, q, limit) };
    case "find_posts":
      return { posts: await findPosts(sb, q, limit) };
    case "find_events":
      return { events: await findEvents(sb, q, limit) };
    default:
      return { error: `Unknown tool: ${name}` };
  }
}

/** Nicely-labelled step description for the UI timeline. */
export function toolLabel(name: string, args: any): string {
  const q = args?.query ? `"${String(args.query).slice(0, 40)}"` : "";
  const map: Record<string, string> = {
    find_sellers: `Searching sellers ${q}`,
    find_products: `Searching products ${q}`,
    find_services: `Searching services ${q}`,
    find_jobs: `Searching jobs ${q}`,
    find_promotions: `Searching promotions ${q}`,
    find_service_catalogs: `Searching service workspaces ${q}`,
    find_posts: `Searching posts ${q}`,
    find_events: `Searching events ${q}`,
  };
  return map[name] ?? `Running ${name}`;
}

export function toolResultSummary(name: string, result: any): { count: number; kind: string } {
  const key = Object.keys(result)[0];
  const arr = Array.isArray(result[key]) ? result[key] : [];
  return { count: arr.length, kind: key };
}
