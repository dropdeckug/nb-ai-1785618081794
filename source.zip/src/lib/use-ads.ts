import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type ListingType = "physical_products" | "services" | "jobs" | "promotions";

export type AdRow = {
  id: string;
  title: string;
  description: string | null;
  category: string | null;
  subcategory: string | null;
  price: number | null;
  currency: string | null;
  location: string | null;
  seller_id: string;
  created_at: string;
  view_count: number | null;
  save_count: number | null;
  engagement_score: number | null;
  images: string[] | null;
  listing_type: ListingType | string | null;
  has_discount: boolean | null;
  is_boosted: boolean | null;
};

export const TYPE_LABEL: Record<string, string> = {
  physical_products: "Products",
  services: "Services",
  jobs: "Jobs",
  promotions: "Promotions",
};

export function relativeTime(iso: string): string {
  const t = new Date(iso).getTime();
  const diff = Date.now() - t;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d}d ago`;
  const mo = Math.floor(d / 30);
  return `${mo}mo ago`;
}

export function useAds() {
  const [data, setData] = useState<AdRow[] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    supabase
      .from("ads")
      .select(
        "id,title,description,category,subcategory,price,currency,location,seller_id,created_at,view_count,save_count,engagement_score,images,listing_type,has_discount,is_boosted",
      )
      .eq("status", "active")
      .order("view_count", { ascending: false })
      .limit(60)
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error) console.error("ads fetch", error);
        setData((data as AdRow[]) ?? []);
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { data, loading };
}

export type SellerRow = {
  user_id: string;
  business_name: string | null;
  business_logo_url: string | null;
  is_verified: boolean | null;
  follower_count: number | null;
};

export type PostRow = {
  id: string;
  title: string | null;
  content: string | null;
  images: string[] | null;
  seller_id: string | null;
  user_id: string | null;
  created_at: string;
  view_count: number | null;
  like_count: number | null;
  comment_count: number | null;
};

export function usePosts() {
  const [data, setData] = useState<PostRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    supabase
      .from("posts")
      .select(
        "id,title,content,images,seller_id,user_id,created_at,view_count,like_count,comment_count",
      )
      .eq("is_active", true)
      .order("view_count", { ascending: false })
      .limit(30)
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error) console.error("posts fetch", error);
        setData((data as PostRow[]) ?? []);
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);
  return { data, loading };
}

export function useTopSellers(ads: AdRow[] | null) {
  const [sellers, setSellers] = useState<Record<string, SellerRow> | null>(null);

  useEffect(() => {
    if (!ads || ads.length === 0) return;
    const ids = Array.from(new Set(ads.map((a) => a.seller_id))).slice(0, 60);
    if (ids.length === 0) return;
    supabase
      .from("seller_profiles_public")
      .select("user_id,business_name,business_logo_url,is_verified,follower_count")
      .in("user_id", ids)
      .then(({ data, error }) => {
        if (error) console.error("sellers fetch", error);
        const map: Record<string, SellerRow> = {};
        (data as SellerRow[] | null)?.forEach((s) => {
          map[s.user_id] = s;
        });
        setSellers(map);
      });
  }, [ads]);

  return sellers;
}
