import { useCallback, useEffect, useRef, useState } from "react";

export function useRecorder() {
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [level, setLevel] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const mediaRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const ctxRef = useRef<AudioContext | null>(null);
  const rafRef = useRef<number | null>(null);

  const cleanup = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    ctxRef.current?.close().catch(() => {});
    ctxRef.current = null;
    setLevel(0);
  }, []);

  useEffect(() => () => cleanup(), [cleanup]);

  const start = useCallback(async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const mimeType = ["audio/webm", "audio/mp4"].find(
        (t) => (window as any).MediaRecorder?.isTypeSupported?.(t),
      );
      const rec = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      chunksRef.current = [];
      rec.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      mediaRef.current = rec;
      rec.start();
      setRecording(true);

      // Level meter
      const Ctx: typeof AudioContext =
        window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new Ctx();
      ctxRef.current = ctx;
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteTimeDomainData(data as any);
        let sum = 0;
        for (let i = 0; i < data.length; i++) {
          const v = (data[i] - 128) / 128;
          sum += v * v;
        }
        setLevel(Math.sqrt(sum / data.length));
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch (e) {
      setError("Microphone access denied");
      cleanup();
      setRecording(false);
    }
  }, [cleanup]);

  const stopAndTranscribe = useCallback(async (): Promise<string> => {
    const rec = mediaRef.current;
    if (!rec) return "";
    const blob: Blob = await new Promise((resolve) => {
      rec.onstop = () => {
        const b = new Blob(chunksRef.current, {
          type: rec.mimeType || "audio/webm",
        });
        resolve(b);
      };
      try { rec.stop(); } catch { resolve(new Blob()); }
    });
    setRecording(false);
    cleanup();

    if (blob.size < 1024) return "";

    setTranscribing(true);
    try {
      const form = new FormData();
      form.append("file", blob, `clip.${(rec.mimeType || "").includes("mp4") ? "mp4" : "webm"}`);
      const res = await fetch("/api/transcribe", { method: "POST", body: form });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || `Failed (${res.status})`);
      }
      const j = await res.json();
      return (j.text as string) || "";
    } catch (e) {
      setError(e instanceof Error ? e.message : "Transcription failed");
      return "";
    } finally {
      setTranscribing(false);
    }
  }, [cleanup]);

  const cancel = useCallback(() => {
    try { mediaRef.current?.stop(); } catch {}
    setRecording(false);
    cleanup();
  }, [cleanup]);

  return { recording, transcribing, level, error, start, stopAndTranscribe, cancel };
}
