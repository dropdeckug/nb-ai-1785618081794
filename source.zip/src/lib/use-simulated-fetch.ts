import { useEffect, useState } from "react";

/**
 * Simulates async data loading until the EarlyMarket API is wired in.
 * Replace with real fetch / TanStack Query later.
 */
export function useSimulatedFetch<T>(data: T, delay = 1100): { data: T | null; loading: boolean } {
  const [state, setState] = useState<{ data: T | null; loading: boolean }>({
    data: null,
    loading: true,
  });

  useEffect(() => {
    let alive = true;
    const t = setTimeout(() => {
      if (alive) setState({ data, loading: false });
    }, delay);
    return () => {
      alive = false;
      clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return state;
}