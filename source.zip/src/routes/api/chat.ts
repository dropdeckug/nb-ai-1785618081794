import { createFileRoute } from "@tanstack/react-router";
import {
  TOOL_DECLARATIONS,
  makeSb,
  runTool,
  toolLabel,
  toolResultSummary,
  type ToolName,
} from "@/lib/marketplace-tools.server";

/**
 * Streaming chat endpoint powered by Google AI Studio (Gemini).
 * Emits newline-delimited JSON events:
 *   {type:"step",  tool, label, args}
 *   {type:"tool_result", tool, count, kind, items}
 *   {type:"text",  delta}
 *   {type:"title", title}
 *   {type:"done"}
 *   {type:"error", message}
 */

const MODEL = "gemini-flash-lite-latest";
const API_BASE = "https://generativelanguage.googleapis.com/v1beta";

type Msg = { role: "user" | "assistant"; content: string };

const SYSTEM = `You are earlymarket AI, the assistant for the EarlyMarket Uganda marketplace (earlymarketug.com).

The platform contains: sellers/businesses (with logos, bios, verification badges, districts, follower counts), physical products, digital products, services with service workspaces (catalogs, offerings, portfolios, FAQs, testimonials, status updates), jobs, promotions/discounts, events, community posts, tenders and volunteer opportunities.

Rules:
- When the user asks about anything findable on the marketplace (a seller, a product, a service, a job, an event, a discount, a post) ALWAYS call the matching tool BEFORE answering. Never claim "not found" without calling a tool. The tools guarantee results — they fall back to popular items when no exact match exists — so if a tool returns 0 items you can be sure nothing matches.
- Multiple tools can be called in parallel when the user's question spans several categories.
- Use ONLY the data returned by tools. Never invent listings, sellers, prices, images or links.
- Answer in clean markdown. Use every rich detail the tool returned: brand, model, condition, color, size, warranty, inventory, shipping, discount, location, view/save counts, seller name and verification, etc.
- For comparisons or when listing 3+ items with similar fields, ALWAYS use a GitHub-flavoured markdown TABLE (| col | col |).
- Include the first image of each item inline as small markdown images: ![](image_url) — this renders as a compact 96px thumbnail. Prefer 1 image per item.
- When the user asks for trends, activity over time, price ranges, or any numeric comparison, output a fenced block with language "chart" containing JSON:
  \`\`\`chart
  { "type": "line", "title": "Views over time", "xKey": "day", "yKey": "views", "data": [{"day":"Mon","views":12}, ...] }
  \`\`\`
  Supported types: "line", "bar". Keep data <= 20 points.
- Keep prose tight: short headings, bullets, **bold** for names/prices. Skip filler.
- If the question is casual / general (small talk, how the platform works) just answer directly — no tool needed.
- Never mention "Lovable", "Gemini", "Google", vendors or models. Refer to yourself as "earlymarket AI".`;

function toContents(history: Msg[], nextPrompt?: string): any[] {
  const arr: any[] = history.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }] as any[],
  }));
  if (nextPrompt) arr.push({ role: "user", parts: [{ text: nextPrompt }] });
  return arr;
}

async function generateTitle(apiKey: string, prompt: string): Promise<string> {
  try {
    const res = await fetch(
      `${API_BASE}/models/${MODEL}:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [
            {
              role: "user",
              parts: [
                {
                  text: `Write a 3-6 word chat title for this question. Output ONLY the title, no quotes, no trailing punctuation.\n\n${prompt}`,
                },
              ],
            },
          ],
          generationConfig: { temperature: 0.4, maxOutputTokens: 24 },
        }),
      },
    );
    if (!res.ok) return prompt.slice(0, 60);
    const j: any = await res.json();
    const t = j?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
    return (t ?? prompt.slice(0, 60)).replace(/^["']|["']$/g, "").slice(0, 80);
  } catch {
    return prompt.slice(0, 60);
  }
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
          return new Response(
            JSON.stringify({
              type: "error",
              message: "GEMINI_API_KEY is not configured on the server.",
            }) + "\n",
            { status: 500, headers: { "Content-Type": "application/x-ndjson" } },
          );
        }

        const body = (await request.json()) as {
          history?: Msg[];
          prompt?: string;
          wantTitle?: boolean;
        };
        const history = Array.isArray(body.history) ? body.history : [];
        const prompt = (body.prompt ?? "").trim();
        if (!prompt) return new Response("Missing prompt", { status: 400 });

        const encoder = new TextEncoder();
        const stream = new ReadableStream({
          async start(controller) {
            const send = (obj: any) => {
              controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
            };

            try {
              // Kick off title generation in parallel — send it whenever ready
              if (body.wantTitle) {
                generateTitle(apiKey, prompt).then((title) =>
                  send({ type: "title", title }),
                );
              }

              const sb = makeSb();
              let contents = toContents(history, prompt);

              // Multi-round tool loop (up to 5 rounds)
              for (let round = 0; round < 5; round++) {
                const upstream = await fetch(
                  `${API_BASE}/models/${MODEL}:streamGenerateContent?alt=sse&key=${apiKey}`,
                  {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      systemInstruction: { parts: [{ text: SYSTEM }] },
                      contents,
                      tools: [{ functionDeclarations: TOOL_DECLARATIONS }],
                      generationConfig: {
                        temperature: 0.6,
                        maxOutputTokens: 2048,
                      },
                    }),
                  },
                );

                if (!upstream.ok || !upstream.body) {
                  const txt = await upstream.text().catch(() => "");
                  send({
                    type: "error",
                    message: `Gemini ${upstream.status}: ${txt.slice(0, 300)}`,
                  });
                  controller.close();
                  return;
                }

                // Parse SSE from Google
                const reader = upstream.body.getReader();
                const decoder = new TextDecoder();
                let buf = "";
                const modelParts: any[] = [];
                const pendingCalls: { name: string; args: any }[] = [];
                let finished = false;

                while (!finished) {
                  const { done, value } = await reader.read();
                  if (done) break;
                  buf += decoder.decode(value, { stream: true });
                  const parts2 = buf.split(/\r?\n\r?\n/);
                  buf = parts2.pop() ?? "";
                  for (const rawChunk of parts2) {
                    const line = rawChunk
                      .split(/\r?\n/)
                      .filter((l) => l.startsWith("data:"))
                      .map((l) => l.slice(5).trim())
                      .join("");
                    if (!line || line === "[DONE]") continue;
                    let evt: any;
                    try {
                      evt = JSON.parse(line);
                    } catch {
                      continue;
                    }
                    const cand = evt?.candidates?.[0];
                    const parts = cand?.content?.parts ?? [];
                    for (const p of parts) {
                      if (p.functionCall) {
                        const fcPart: any = { functionCall: p.functionCall };
                        if (p.thoughtSignature) fcPart.thoughtSignature = p.thoughtSignature;
                        modelParts.push(fcPart);
                        pendingCalls.push({
                          name: p.functionCall.name,
                          args: p.functionCall.args ?? {},
                        });
                        send({
                          type: "step",
                          tool: p.functionCall.name,
                          args: p.functionCall.args ?? {},
                          label: toolLabel(
                            p.functionCall.name,
                            p.functionCall.args ?? {},
                          ),
                        });
                      } else if (typeof p.text === "string" && p.text) {
                        const tPart: any = { text: p.text };
                        if (p.thought) tPart.thought = p.thought;
                        if (p.thoughtSignature) tPart.thoughtSignature = p.thoughtSignature;
                        modelParts.push(tPart);
                        if (!p.thought) send({ type: "text", delta: p.text });
                      }
                    }
                    if (cand?.finishReason) finished = true;
                  }
                }

                // Append model turn to conversation
                contents.push({ role: "model", parts: modelParts.length ? modelParts : [{ text: "" }] });

                if (pendingCalls.length === 0) {
                  // Generate follow-ups from the full transcript (best-effort)
                  try {
                    const transcript = contents
                      .map((c: any) =>
                        (c.parts ?? [])
                          .map((p: any) => p.text ?? "")
                          .filter(Boolean)
                          .join(" "),
                      )
                      .filter(Boolean)
                      .join("\n\n")
                      .slice(-4000);
                    const fRes = await fetch(
                      `${API_BASE}/models/${MODEL}:generateContent?key=${apiKey}`,
                      {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          contents: [
                            {
                              role: "user",
                              parts: [
                                {
                                  text: `Given the following Q&A about the EarlyMarket Uganda marketplace, propose 5 short, distinct follow-up questions a user might ask next. Return a strict JSON array of strings, nothing else.\n\n${transcript}`,
                                },
                              ],
                            },
                          ],
                          generationConfig: {
                            temperature: 0.7,
                            maxOutputTokens: 200,
                            responseMimeType: "application/json",
                          },
                        }),
                      },
                    );
                    if (fRes.ok) {
                      const fj: any = await fRes.json();
                      const raw = fj?.candidates?.[0]?.content?.parts?.[0]?.text ?? "[]";
                      const parsed = JSON.parse(raw);
                      if (Array.isArray(parsed)) {
                        send({
                          type: "followups",
                          items: parsed.filter((x: any) => typeof x === "string").slice(0, 5),
                        });
                      }
                    }
                  } catch {
                    /* ignore */
                  }

                  send({ type: "done" });
                  controller.close();
                  return;
                }


                // Execute all tool calls in parallel
                const results = await Promise.all(
                  pendingCalls.map(async (c) => {
                    try {
                      const r = await runTool(sb, c.name as ToolName, c.args);
                      const summary = toolResultSummary(c.name, r);
                      const items = (Object.values(r)[0] as any[]) ?? [];
                      send({
                        type: "tool_result",
                        tool: c.name,
                        args: c.args,
                        count: summary.count,
                        kind: summary.kind,
                        items: items.slice(0, 6),
                      });
                      return { name: c.name, response: r };
                    } catch (e: any) {
                      send({
                        type: "tool_result",
                        tool: c.name,
                        args: c.args,
                        count: 0,
                        kind: "error",
                        items: [],
                      });
                      return {
                        name: c.name,
                        response: { error: String(e?.message ?? e) },
                      };
                    }
                  }),
                );

                // Append tool responses in a single user turn
                contents.push({
                  role: "user",
                  parts: results.map((r) => ({
                    functionResponse: { name: r.name, response: r.response },
                  })),
                });
                // continue loop -> model summarises
              }

              send({
                type: "error",
                message: "Reached tool-call limit.",
              });
              controller.close();
            } catch (e: any) {
              console.error("chat stream error:", e);
              send({
                type: "error",
                message: String(e?.message ?? e),
              });
              controller.close();
            }
          },
        });

        return new Response(stream, {
          headers: {
            "Content-Type": "application/x-ndjson; charset=utf-8",
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
          },
        });
      },
    },
  },
});
