import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/speak")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env.LOVABLE_API_KEY;
        if (!apiKey) {
          return new Response("LOVABLE_API_KEY is not configured", { status: 500 });
        }
        const { text, voice } = (await request.json()) as {
          text?: string;
          voice?: string;
        };
        if (!text?.trim()) return new Response("Missing text", { status: 400 });

        const res = await fetch("https://ai.gateway.lovable.dev/v1/audio/speech", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "openai/gpt-4o-mini-tts",
            input: text.slice(0, 2000),
            voice: voice || "alloy",
            response_format: "mp3",
          }),
        });

        if (!res.ok) {
          const t = await res.text().catch(() => "");
          return new Response(`TTS failed (${res.status}): ${t.slice(0, 200)}`, {
            status: res.status,
          });
        }

        return new Response(res.body, {
          status: 200,
          headers: { "Content-Type": "audio/mpeg" },
        });
      },
    },
  },
});
