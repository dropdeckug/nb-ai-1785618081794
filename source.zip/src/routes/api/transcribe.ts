import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/transcribe")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env.LOVABLE_API_KEY;
        if (!apiKey) {
          return Response.json(
            { error: "LOVABLE_API_KEY is not configured on the server." },
            { status: 500 },
          );
        }

        const form = await request.formData();
        const file = form.get("file");
        if (!(file instanceof Blob)) {
          return Response.json({ error: "Missing audio file" }, { status: 400 });
        }

        const mime = (file as File).type || "audio/webm";
        const ext =
          mime.includes("mp4") ? "mp4" :
          mime.includes("mpeg") ? "mp3" :
          mime.includes("wav") ? "wav" :
          mime.includes("ogg") ? "ogg" :
          "webm";

        const upstream = new FormData();
        upstream.append("model", "openai/gpt-4o-mini-transcribe");
        upstream.append("file", file, `recording.${ext}`);

        const res = await fetch(
          "https://ai.gateway.lovable.dev/v1/audio/transcriptions",
          {
            method: "POST",
            headers: { Authorization: `Bearer ${apiKey}` },
            body: upstream,
          },
        );

        if (!res.ok) {
          const txt = await res.text().catch(() => "");
          return Response.json(
            { error: `Transcription failed (${res.status}): ${txt.slice(0, 200)}` },
            { status: res.status },
          );
        }
        const json = await res.json();
        return Response.json({ text: (json.text || "").trim() });
      },
    },
  },
});
