import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/voice-chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
          return Response.json(
            { error: "GEMINI_API_KEY is not configured" },
            { status: 500 },
          );
        }
        const { prompt } = (await request.json()) as { prompt?: string };
        if (!prompt?.trim()) {
          return Response.json({ error: "Missing prompt" }, { status: 400 });
        }

        const res = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-lite-latest:generateContent?key=${apiKey}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              systemInstruction: {
                parts: [
                  {
                    text: "You are earlymarket AI in voice mode. Reply in 1-3 short sentences, conversational and friendly. No markdown, no lists.",
                  },
                ],
              },
              contents: [{ role: "user", parts: [{ text: prompt }] }],
              generationConfig: { temperature: 0.7, maxOutputTokens: 200 },
            }),
          },
        );

        if (!res.ok) {
          const t = await res.text().catch(() => "");
          return Response.json(
            { error: `AI failed (${res.status}): ${t.slice(0, 200)}` },
            { status: res.status },
          );
        }
        const j: any = await res.json();
        const text =
          (j?.candidates?.[0]?.content?.parts?.[0]?.text as string) || "";
        return Response.json({ text });
      },
    },
  },
});
