import { createFileRoute } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { PageShell } from "@/components/page-shell";

export const Route = createFileRoute("/artefacts")({
  head: () => ({ meta: [{ title: "Artefacts — earlymarket AI" }] }),
  component: () => (
    <PageShell title="Artefacts" subtitle="Generated documents, dashboards and apps.">
      <div className="grid gap-3 sm:grid-cols-2">
        {["Q3 Market brief", "Competitive landscape", "Pricing model", "Investor memo"].map((a) => (
          <div key={a} className="flex items-center gap-3 rounded-xl border border-border bg-card p-4">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-accent">
              <Sparkles className="h-4 w-4 text-brand" />
            </div>
            <div className="min-w-0">
              <div className="truncate text-sm font-medium">{a}</div>
              <div className="text-xs text-muted-foreground">Updated 2h ago</div>
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  ),
});