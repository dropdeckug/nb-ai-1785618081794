import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import { useChatStore, type ChatMessage } from "@/lib/chat-store";
import { SearchComposer } from "@/components/search-composer";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import {
  ChevronDown,
  ChevronRight,
  Search,
  Users,
  Package,
  Wrench,
  Briefcase,
  Tag,
  MessageSquare,
  Calendar,
  Layers,
  CornerDownRight,
  Plus,
  Share2,
  Copy as CopyIcon,
  RefreshCw,
  ThumbsUp,
  ThumbsDown,
  Globe,
  ImageIcon,
} from "lucide-react";
import { ShinyText } from "@/components/chat/shiny-text";
import { Logo } from "@/components/logo";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ChartBlock } from "@/components/chat/chart-block";

export const Route = createFileRoute("/ask/$threadId")({
  head: () => ({
    meta: [
      { title: "Ask — earlymarket AI" },
      { name: "description", content: "AI answers powered by the EarlyMarket UG marketplace." },
    ],
  }),
  component: AskPage,
});

type SellerAvatar = {
  user_id?: string | null;
  logo?: string;
  name?: string;
  verified?: boolean;
  store_slug?: string | null;
};

type StreamStep = {
  tool: string;
  label: string;
  args: any;
  count?: number;
  items?: any[];
  kind?: string;
  done?: boolean;
};

type Turn = {
  id: string;
  userMessage: string;
  steps: StreamStep[];
  answer: string;
  status: "streaming" | "done" | "error";
  error?: string;
  timelineOpen: boolean;
  followups: string[];
};

const TOOL_ICON: Record<string, typeof Search> = {
  find_sellers: Users,
  find_products: Package,
  find_services: Wrench,
  find_jobs: Briefcase,
  find_promotions: Tag,
  find_posts: MessageSquare,
  find_events: Calendar,
  find_service_catalogs: Layers,
};

const SELLER_BASE = "https://earlymarketug.com";

function sellerUrl(s: SellerAvatar): string | null {
  if (s.store_slug) return `${SELLER_BASE}/store/${s.store_slug}`;
  if (s.user_id) return `${SELLER_BASE}/seller/${s.user_id}`;
  return null;
}

function extractSellers(step: StreamStep): SellerAvatar[] {
  return (step.items ?? [])
    .map((it: any): SellerAvatar | null => {
      if (it.business_name || it.business_logo_url) {
        return {
          user_id: it.user_id,
          logo: it.business_logo_url,
          name: it.business_name,
          verified: it.is_verified,
          store_slug: it.store_slug,
        };
      }
      if (it.seller) {
        return {
          user_id: it.seller.user_id,
          logo: it.seller.business_logo_url,
          name: it.seller.business_name,
          verified: it.seller.is_verified,
          store_slug: it.seller.store_slug,
        };
      }
      return null;
    })
    .filter(Boolean) as SellerAvatar[];
}

function AskPage() {
  const { threadId } = Route.useParams();
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const thread = useChatStore((s) => s.threads[threadId]);
  const hydrate = useChatStore((s) => s.hydrate);
  const appendMessage = useChatStore((s) => s.appendMessage);
  const updateLastAssistant = useChatStore((s) => s.updateLastAssistant);
  const setPending = useChatStore((s) => s.setPending);

  const [turns, setTurns] = useState<Turn[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [pageLoading, setPageLoading] = useState(true);
  const [historyLoaded, setHistoryLoaded] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const streamingRef = useRef(false);
  const stickToBottomRef = useRef(true);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  // Track user scroll — disable auto-scroll if they scroll up
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const dist = el.scrollHeight - el.scrollTop - el.clientHeight;
      stickToBottomRef.current = dist < 120;
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      setPageLoading(true);
      const { data: conv } = await supabase
        .from("emi_conversations")
        .select("id,title")
        .eq("id", threadId)
        .maybeSingle();

      if (cancelled) return;

      if (conv) {
        setConversationId(conv.id);
        const { data: msgs } = await supabase
          .from("emi_messages")
          .select("role,content,created_at")
          .eq("conversation_id", conv.id)
          .order("created_at", { ascending: false })
          .limit(30);
        if (cancelled) return;
        const ordered = (msgs ?? []).slice().reverse() as ChatMessage[];
        const historyTurns: Turn[] = [];
        for (let i = 0; i < ordered.length; i++) {
          const m = ordered[i];
          if (m.role === "user") {
            const next = ordered[i + 1];
            historyTurns.push({
              id: `hist-${i}`,
              userMessage: m.content,
              steps: [],
              answer: next?.role === "assistant" ? next.content : "",
              status: "done",
              timelineOpen: false,
              followups: [],
            });
            if (next?.role === "assistant") i++;
          }
        }
        setTurns(historyTurns);
        hydrate(threadId, ordered, ordered[0]?.content ?? "");
        setHistoryLoaded(true);
      } else {
        setConversationId(null);
        setHistoryLoaded(true);
      }
      setPageLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [threadId, user, hydrate]);

  const runStream = useCallback(
    async (userMessage: string) => {
      if (streamingRef.current) return;
      streamingRef.current = true;
      stickToBottomRef.current = true;

      const turnId = `turn-${Date.now()}`;
      const isFirstTurn = turns.length === 0;
      setTurns((arr) => [
        ...arr,
        {
          id: turnId,
          userMessage,
          steps: [],
          answer: "",
          status: "streaming",
          timelineOpen: true,
          followups: [],
        },
      ]);
      appendMessage(threadId, { role: "user", content: userMessage });

      const history: ChatMessage[] = [];
      for (const t of turns) {
        history.push({ role: "user", content: t.userMessage });
        if (t.answer) history.push({ role: "assistant", content: t.answer });
      }

      let cId = conversationId;
      if (!cId && user) {
        // Insert with empty title — AI will fill it via {type:"title"}
        const { data: conv } = await supabase
          .from("emi_conversations")
          .insert({ id: threadId, user_id: user.id, title: "" })
          .select("id")
          .single();
        if (conv) {
          cId = conv.id;
          setConversationId(conv.id);
        }
      }

      if (cId) {
        supabase
          .from("emi_messages")
          .insert({ conversation_id: cId, role: "user", content: userMessage })
          .then(() => {});
      }

      let accum = "";
      appendMessage(threadId, { role: "assistant", content: "" });

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            history,
            prompt: userMessage,
            wantTitle: isFirstTurn,
          }),
        });
        if (!res.ok || !res.body) {
          throw new Error(`Chat request failed (${res.status})`);
        }
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buf = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop() ?? "";
          for (const raw of lines) {
            const line = raw.trim();
            if (!line) continue;
            let evt: any;
            try {
              evt = JSON.parse(line);
            } catch {
              continue;
            }
            if (evt.type === "step") {
              setTurns((arr) =>
                arr.map((t) =>
                  t.id === turnId
                    ? {
                        ...t,
                        steps: [
                          ...t.steps,
                          { tool: evt.tool, label: evt.label, args: evt.args },
                        ],
                      }
                    : t,
                ),
              );
            } else if (evt.type === "tool_result") {
              setTurns((arr) =>
                arr.map((t) => {
                  if (t.id !== turnId) return t;
                  const steps = [...t.steps];
                  for (let i = steps.length - 1; i >= 0; i--) {
                    if (steps[i].tool === evt.tool && steps[i].count === undefined) {
                      steps[i] = {
                        ...steps[i],
                        count: evt.count,
                        items: evt.items,
                        kind: evt.kind,
                        done: true,
                      };
                      break;
                    }
                  }
                  return { ...t, steps };
                }),
              );
            } else if (evt.type === "text") {
              accum += evt.delta;
              setTurns((arr) =>
                arr.map((t) => (t.id === turnId ? { ...t, answer: accum } : t)),
              );
              updateLastAssistant(threadId, accum);
            } else if (evt.type === "title") {
              if (cId && evt.title) {
                supabase
                  .from("emi_conversations")
                  .update({ title: evt.title })
                  .eq("id", cId)
                  .then(() => {});
              }
            } else if (evt.type === "followups") {
              setTurns((arr) =>
                arr.map((t) =>
                  t.id === turnId ? { ...t, followups: evt.items ?? [] } : t,
                ),
              );
            } else if (evt.type === "error") {
              throw new Error(evt.message);
            }
          }
        }

        setTurns((arr) =>
          arr.map((t) =>
            t.id === turnId ? { ...t, status: "done", timelineOpen: false } : t,
          ),
        );
        if (cId && accum) {
          await supabase.from("emi_messages").insert({
            conversation_id: cId,
            role: "assistant",
            content: accum,
          });
        }
      } catch (e: any) {
        setTurns((arr) =>
          arr.map((t) =>
            t.id === turnId
              ? { ...t, status: "error", error: e?.message ?? "Unknown error" }
              : t,
          ),
        );
      } finally {
        streamingRef.current = false;
      }
    },
    [turns, appendMessage, updateLastAssistant, threadId, conversationId, user],
  );

  useEffect(() => {
    if (!historyLoaded) return;
    if (!thread?.pendingPrompt) return;
    const p = thread.pendingPrompt;
    setPending(threadId, null);
    runStream(p);
  }, [historyLoaded, thread?.pendingPrompt, threadId, setPending, runStream]);

  // Smooth auto-scroll during streaming
  useEffect(() => {
    const el = scrollRef.current;
    if (!el || !stickToBottomRef.current) return;
    // rAF to batch and avoid layout thrash while tokens stream in
    const id = requestAnimationFrame(() => {
      el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    });
    return () => cancelAnimationFrame(id);
  }, [turns]);

  const handleFollowUp = (text: string) => {
    if (!text.trim() || streamingRef.current) return;
    runStream(text.trim());
  };

  return (
    <div ref={scrollRef} className="h-[calc(100vh-3.5rem)] overflow-y-auto scroll-smooth">
      <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 py-8 space-y-12">
        {pageLoading && turns.length === 0 && (
          <div className="text-sm text-muted-foreground">Loading…</div>
        )}

        {turns.map((turn) => (
          <TurnBlock
            key={turn.id}
            turn={turn}
            onToggleTimeline={() =>
              setTurns((arr) =>
                arr.map((t) =>
                  t.id === turn.id ? { ...t, timelineOpen: !t.timelineOpen } : t,
                ),
              )
            }
            onFollowUp={handleFollowUp}
          />
        ))}

        <div className="sticky bottom-4 pt-4">
          <SearchComposer onSubmit={handleFollowUp} placeholder="Ask a follow-up" />
        </div>
      </div>
    </div>
  );
}

function TurnBlock({
  turn,
  onToggleTimeline,
  onFollowUp,
}: {
  turn: Turn;
  onToggleTimeline: () => void;
  onFollowUp: (q: string) => void;
}) {
  const streaming = turn.status === "streaming";
  const activeStep = streaming
    ? turn.steps.find((s) => !s.done)?.label ?? (turn.answer ? "Drafting answer" : "Thinking")
    : null;

  // Aggregate sources + images from tool results across steps
  const { sources, images } = useMemo(() => {
    const src: any[] = [];
    const imgs: string[] = [];
    const seen = new Set<string>();
    for (const s of turn.steps) {
      for (const it of s.items ?? []) {
        const key = String(it.id ?? it.user_id ?? it.title ?? Math.random());
        if (seen.has(key)) continue;
        seen.add(key);
        src.push({ ...it, __tool: s.tool });
        const img =
          (Array.isArray(it.images) && it.images[0]) ||
          it.business_logo_url ||
          it.cover_image_url;
        if (img && !imgs.includes(img)) imgs.push(img);
      }
    }
    return { sources: src, images: imgs };
  }, [turn.steps]);

  const done = turn.status === "done";

  return (
    <div className="fade-up-line">
      <h1 className="text-2xl sm:text-3xl font-normal tracking-tight text-foreground">
        {turn.userMessage}
      </h1>

      {/* Source cards (perplexity-style) */}
      {done && sources.length > 0 && (
        <SourceCards sources={sources.slice(0, 4)} total={sources.length} />
      )}

      {(turn.steps.length > 0 || streaming) && (
        <div className="mt-4">
          <button
            onClick={onToggleTimeline}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
          >
            {turn.timelineOpen ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
            {streaming ? (
              <ShinyText>{activeStep ?? "Thinking"}…</ShinyText>
            ) : (
              <span>
                Completed {turn.steps.length} step
                {turn.steps.length === 1 ? "" : "s"}
              </span>
            )}
          </button>

          {turn.timelineOpen && (
            <div className="mt-3 ml-2 border-l border-border pl-4 space-y-3">
              {turn.steps.map((s, i) => {
                const Icon = TOOL_ICON[s.tool] ?? Search;
                const isActive = streaming && !s.done;
                const avatars = extractSellers(s);
                const shown = avatars.slice(0, 5);
                const extra = Math.max(0, (s.count ?? avatars.length) - shown.length);
                return (
                  <div key={i}>
                    <div className="flex items-center gap-2 text-sm">
                      <Icon
                        className={`h-3.5 w-3.5 ${
                          isActive ? "text-primary" : "text-muted-foreground"
                        }`}
                      />
                      {isActive ? (
                        <ShinyText>{s.label}</ShinyText>
                      ) : (
                        <span className="text-foreground/90">{s.label}</span>
                      )}
                      {typeof s.count === "number" && (
                        <span className="ml-1 inline-flex items-center rounded-full bg-secondary px-1.5 py-0.5 text-[11px] font-medium text-foreground/80">
                          {s.count}
                        </span>
                      )}
                    </div>
                    {shown.length > 0 && (
                      <div className="mt-1.5 ml-5 flex -space-x-2">
                        {shown.map((a, k) => {
                          const url = sellerUrl(a);
                          const Wrapper: any = url ? "a" : "div";
                          const wrapperProps = url
                            ? { href: url, target: "_blank", rel: "noreferrer" }
                            : {};
                          return (
                            <Wrapper
                              key={k}
                              title={a.name}
                              {...wrapperProps}
                              className="grid h-7 w-7 place-items-center overflow-hidden rounded-full border-2 border-background bg-secondary text-[9px] font-medium transition-transform hover:scale-110 hover:z-10"
                            >
                              {a.logo ? (
                                <img
                                  src={a.logo}
                                  alt=""
                                  className="h-full w-full object-cover"
                                />
                              ) : (
                                <span>{(a.name ?? "?").slice(0, 2).toUpperCase()}</span>
                              )}
                            </Wrapper>
                          );
                        })}
                        {extra > 0 && (
                          <div className="grid h-7 min-w-7 px-1 place-items-center rounded-full border-2 border-background bg-secondary text-[9px] font-semibold text-foreground/80">
                            +{extra}
                          </div>
                        )}
                      </div>
                    )}
                    {s.items && s.items.length > 0 && shown.length === 0 && (
                      <ul className="mt-1 ml-5 space-y-0.5 text-xs text-muted-foreground">
                        {s.items.slice(0, 3).map((it: any, j: number) => (
                          <li key={j} className="truncate">
                            • {it.title ?? it.name ?? "Item"}
                          </li>
                        ))}
                        {s.items.length > 3 && (
                          <li className="text-[11px]">+{s.items.length - 3} more</li>
                        )}
                      </ul>
                    )}
                  </div>
                );
              })}
              {streaming && turn.answer && (
                <div className="flex items-center gap-2 text-sm">
                  <Logo className="h-4 w-4 rounded-sm" />
                  <ShinyText>Drafting answer with earlymarket AI</ShinyText>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {turn.error && (
        <div className="mt-4 rounded-lg border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
          {turn.error}
        </div>
      )}

      {turn.answer && (
        <div className="mt-6 answer-md text-[15px] leading-7 text-foreground/90">
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              h1: (p) => <h1 className="mt-5 mb-2 text-2xl font-normal tracking-tight" {...p} />,
              h2: (p) => <h2 className="mt-5 mb-2 text-xl font-normal tracking-tight" {...p} />,
              h3: (p) => <h3 className="mt-4 mb-2 text-base font-medium" {...p} />,
              p: (p) => <p className="my-3" {...p} />,
              ul: (p) => <ul className="my-3 ml-5 list-disc space-y-1.5" {...p} />,
              ol: (p) => <ol className="my-3 ml-5 list-decimal space-y-1.5" {...p} />,
              li: (p) => <li className="pl-1" {...p} />,
              strong: (p) => <strong className="font-medium text-foreground" {...p} />,
              a: (p) => <a className="text-primary hover:underline" target="_blank" rel="noreferrer" {...p} />,
              img: ({ src, alt }) => (
                <a href={src as string} target="_blank" rel="noreferrer" className="inline-block align-middle">
                  <img
                    src={src as string}
                    alt={alt ?? ""}
                    loading="lazy"
                    className="my-1 mr-1 inline-block h-24 w-24 rounded-md border border-border object-cover"
                  />
                </a>
              ),
              table: (p) => (
                <div className="my-4 overflow-x-auto rounded-lg border border-border">
                  <table className="w-full text-sm" {...p} />
                </div>
              ),
              thead: (p) => <thead className="bg-secondary/60 text-left text-xs uppercase tracking-wide text-muted-foreground" {...p} />,
              th: (p) => <th className="px-3 py-2 font-medium" {...p} />,
              td: (p) => <td className="border-t border-border px-3 py-2 align-top" {...p} />,
              code: ({ inline, className, children, ...rest }: any) => {
                const match = /language-(\w+)/.exec(className ?? "");
                const lang = match?.[1];
                const text = String(children ?? "").replace(/\n$/, "");
                if (!inline && lang === "chart") {
                  return <ChartBlock source={text} />;
                }
                if (inline) {
                  return (
                    <code className="rounded bg-muted px-1 py-0.5 text-[0.85em]" {...rest}>
                      {children}
                    </code>
                  );
                }
                return (
                  <pre className="my-3 overflow-x-auto rounded-md bg-muted p-3 text-xs">
                    <code className={className} {...rest}>{children}</code>
                  </pre>
                );
              },
            }}
          >
            {turn.answer}
          </ReactMarkdown>
        </div>
      )}

      {/* Images section */}
      {done && images.length > 0 && (
        <section className="mt-8">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-medium text-foreground">
            <ImageIcon className="h-4 w-4 text-muted-foreground" />
            Images
          </h3>
          <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
            {images.slice(0, 12).map((src, i) => (
              <a
                key={`${src}-${i}`}
                href={src}
                target="_blank"
                rel="noreferrer"
                className="block aspect-square overflow-hidden rounded-md border border-border bg-muted"
              >
                <img
                  src={src}
                  alt=""
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform hover:scale-105"
                />
              </a>
            ))}
          </div>
        </section>
      )}

      {/* Action bar */}
      {done && (
        <div className="mt-6 flex items-center justify-between border-t border-border pt-3">
          <div className="flex items-center gap-1">
            <IconBtn
              label="Copy"
              onClick={() => navigator.clipboard?.writeText(turn.answer)}
            >
              <CopyIcon className="h-4 w-4" />
            </IconBtn>
            <IconBtn
              label="Share"
              onClick={() => {
                if (navigator.share)
                  navigator.share({ text: turn.answer }).catch(() => {});
              }}
            >
              <Share2 className="h-4 w-4" />
            </IconBtn>
            <IconBtn label="Regenerate" onClick={() => onFollowUp(turn.userMessage)}>
              <RefreshCw className="h-4 w-4" />
            </IconBtn>
            {sources.length > 0 && (
              <span className="ml-1 inline-flex items-center gap-1.5 rounded-full border border-border px-2.5 py-1 text-xs text-foreground/85">
                <Globe className="h-3.5 w-3.5" />
                {sources.length} sources
              </span>
            )}
          </div>
          <div className="flex items-center gap-1">
            <IconBtn label="Like"><ThumbsUp className="h-4 w-4" /></IconBtn>
            <IconBtn label="Dislike"><ThumbsDown className="h-4 w-4" /></IconBtn>
          </div>
        </div>
      )}

      {/* Follow-ups */}
      {done && turn.followups.length > 0 && (
        <section className="mt-8">
          <h3 className="text-sm font-medium text-foreground">Follow-ups</h3>
          <ul className="mt-3 divide-y divide-border border-y border-border">
            {turn.followups.map((q) => (
              <li key={q}>
                <button
                  onClick={() => onFollowUp(q)}
                  className="group flex w-full items-center justify-between gap-3 py-3 text-left text-sm text-foreground/85 hover:text-foreground"
                >
                  <span className="flex items-center gap-3">
                    <CornerDownRight className="h-4 w-4 text-muted-foreground" />
                    {q}
                  </span>
                  <Plus className="h-4 w-4 opacity-0 transition-opacity group-hover:opacity-100 text-muted-foreground" />
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

function IconBtn({
  children,
  label,
  onClick,
}: {
  children: React.ReactNode;
  label: string;
  onClick?: () => void;
}) {
  return (
    <button
      aria-label={label}
      onClick={onClick}
      className="grid h-8 w-8 place-items-center rounded-full text-muted-foreground hover:bg-accent hover:text-foreground"
    >
      {children}
    </button>
  );
}

const TYPE_ICON: Record<string, typeof Package> = {
  find_products: Package,
  find_services: Wrench,
  find_jobs: Briefcase,
  find_promotions: Tag,
  find_posts: MessageSquare,
  find_events: Calendar,
  find_sellers: Users,
  find_service_catalogs: Layers,
};

function SourceCards({ sources, total }: { sources: any[]; total: number }) {
  return (
    <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-2">
      {sources.map((s, i) => {
        const Icon = TYPE_ICON[s.__tool] ?? Globe;
        const title =
          s.title ?? s.name ?? s.business_name ?? "Item";
        const img =
          (Array.isArray(s.images) && s.images[0]) ||
          s.business_logo_url ||
          s.cover_image_url;
        const url = s.store_slug
          ? `${SELLER_BASE}/store/${s.store_slug}`
          : s.id
            ? `${SELLER_BASE}/ad/${s.id}`
            : SELLER_BASE;
        return (
          <a
            key={i}
            href={url}
            target="_blank"
            rel="noreferrer"
            className="flex flex-col gap-2 rounded-xl border border-border bg-card/40 p-3 text-left transition-colors hover:bg-accent/40"
          >
            <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
              {img ? (
                <img
                  src={img}
                  alt=""
                  className="h-4 w-4 rounded-sm object-cover"
                />
              ) : (
                <Icon className="h-3.5 w-3.5" />
              )}
              <span className="truncate">earlymarketug</span>
            </div>
            <div className="text-xs font-medium leading-snug text-foreground line-clamp-2">
              {title}
            </div>
          </a>
        );
      })}
      {total > sources.length && (
        <div className="flex items-center justify-center rounded-xl border border-border bg-card/40 p-3 text-xs text-muted-foreground">
          +{total - sources.length} more
        </div>
      )}
    </div>
  );
}
