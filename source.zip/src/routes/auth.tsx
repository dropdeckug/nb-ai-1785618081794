import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import logo from "@/assets/earlymarket-logo.png";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — earlymarket AI" },
      { name: "description", content: "Sign in to your existing earlyMarket business account or create a new one." },
    ],
  }),
  component: AuthPage,
});

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.76h3.56c2.08-1.92 3.28-4.74 3.28-8.09Z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.56-2.76c-.99.66-2.25 1.06-3.72 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23Z" />
      <path fill="#FBBC05" d="M5.84 14.11A6.6 6.6 0 0 1 5.5 12c0-.73.13-1.45.34-2.11V7.05H2.18A11 11 0 0 0 1 12c0 1.78.43 3.46 1.18 4.95l3.66-2.84Z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1A11 11 0 0 0 2.18 7.05L5.84 9.9C6.71 7.31 9.14 5.38 12 5.38Z" />
    </svg>
  );
}

function XIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true" fill="currentColor">
      <path d="M18.244 2H21l-6.522 7.452L22 22h-6.797l-4.78-6.243L4.8 22H2.04l6.98-7.974L2 2h6.97l4.32 5.71L18.244 2Zm-1.19 18h1.69L7.04 4H5.27l11.784 16Z" />
    </svg>
  );
}

function AuthPage() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && user) navigate({ to: "/" });
  }, [user, loading, navigate]);

  const oauth = async (provider: "google" | "twitter") => {
    setErr(null);
    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: window.location.origin },
    });
    if (error) setErr(error.message);
  };

  const onEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setErr(null);
    setInfo(null);
    setBusy(true);
    if (!showPwd) {
      // Probe: try magic link / detect existing
      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: { emailRedirectTo: window.location.origin },
      });
      setBusy(false);
      if (error) {
        setShowPwd(true);
        return;
      }
      setInfo("Check your email for a sign-in link.");
      return;
    }
    // Try sign in, fall back to sign up
    const { error: signInErr } = await supabase.auth.signInWithPassword({ email, password });
    if (signInErr) {
      const { error: signUpErr } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: window.location.origin },
      });
      setBusy(false);
      if (signUpErr) {
        setErr(signUpErr.message);
        return;
      }
      setInfo("Account created. Check your inbox to confirm.");
      return;
    }
    setBusy(false);
  };

  return (
    <div className="flex min-h-[calc(100vh-3.5rem)] items-center justify-center bg-background px-4 py-10">
      <div className="w-full max-w-md text-center">
        <img
          src={logo}
          alt="earlyMarket"
          className="mx-auto mb-8 h-12 w-12 rounded-xl shadow-sm"
        />
        <h1 className="font-serif text-[28px] leading-tight tracking-tight text-foreground sm:text-[34px]">
          Sign in to your existing earlyMarket account or create a new one
        </h1>
        <p className="mt-3 text-xs text-muted-foreground">
          By continuing, you agree to our{" "}
          <a className="underline" href="#">privacy policy</a>.
        </p>

        <div className="mt-8 space-y-3">
          <button
            onClick={() => oauth("google")}
            className="flex h-11 w-full items-center justify-center gap-2 rounded-md bg-foreground text-background text-sm font-medium hover:opacity-90"
          >
            <GoogleIcon /> Continue with Google
          </button>
          <button
            onClick={() => oauth("twitter")}
            className="flex h-11 w-full items-center justify-center gap-2 rounded-md bg-foreground text-background text-sm font-medium hover:opacity-90"
          >
            <XIcon /> Continue with X
          </button>
        </div>

        <form onSubmit={onEmail} className="mt-5 space-y-2">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="h-11 w-full rounded-md border border-border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          {showPwd && (
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="h-11 w-full rounded-md border border-border bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          )}
          <button
            type="submit"
            disabled={busy}
            className="h-11 w-full rounded-md bg-secondary text-sm font-medium text-foreground hover:bg-secondary/80 disabled:opacity-60"
          >
            {busy ? "Please wait…" : showPwd ? "Continue" : "Continue with email"}
          </button>
        </form>

        {err && <p className="mt-3 text-xs text-destructive">{err}</p>}
        {info && <p className="mt-3 text-xs text-emerald-500">{info}</p>}

        <div className="mt-5 flex items-center justify-center gap-4 text-xs text-muted-foreground">
          <button onClick={() => setShowPwd((s) => !s)} className="hover:text-foreground">
            {showPwd ? "Use magic link instead" : "Use password instead"}
          </button>
          <Link to="/" className="hover:text-foreground">Close</Link>
        </div>
      </div>
    </div>
  );
}
