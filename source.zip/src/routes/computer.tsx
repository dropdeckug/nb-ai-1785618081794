import { createFileRoute } from "@tanstack/react-router";
import { Monitor } from "lucide-react";
import { PageShell } from "@/components/page-shell";

export const Route = createFileRoute("/computer")({
  head: () => ({ meta: [{ title: "Computer — earlymarket AI" }] }),
  component: () => (
    <PageShell title="Computer" subtitle="Let earlymarket AI take action across apps.">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {["Organise my life", "Monitor the situation", "Recruiting", "Create a prototype", "Plan a trip", "Draft a report"].map((t) => (
          <button key={t} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 text-left hover:bg-accent">
            <Monitor className="h-5 w-5 text-brand" />
            <div>
              <div className="text-sm font-medium">{t}</div>
              <div className="text-xs text-muted-foreground">Tap to start a task</div>
            </div>
          </button>
        ))}
      </div>
    </PageShell>
  ),
});
