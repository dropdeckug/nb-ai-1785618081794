import { createFileRoute } from "@tanstack/react-router";
import { useTheme } from "@/lib/theme";
import { PageShell } from "@/components/page-shell";
import { Sun, Moon } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/customise")({
  head: () => ({ meta: [{ title: "Customise — earlymarket AI" }] }),
  component: Customise,
});

function Row({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-border py-4 last:border-0">
      <div className="min-w-0">
        <div className="text-sm font-medium">{label}</div>
        {description && (
          <div className="text-xs text-muted-foreground">{description}</div>
        )}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function Toggle({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`relative h-5 w-9 rounded-full transition-colors ${checked ? "bg-brand" : "bg-muted"}`}
    >
      <span
        className={`absolute top-0.5 left-0.5 h-4 w-4 rounded-full bg-background shadow transition-transform ${checked ? "translate-x-4" : ""}`}
      />
    </button>
  );
}

function Customise() {
  const { theme, setTheme } = useTheme();
  const [voice, setVoice] = useState(true);
  const [autocomplete, setAutocomplete] = useState(true);
  const [analytics, setAnalytics] = useState(false);
  const [model, setModel] = useState("default");
  const [language, setLanguage] = useState("English");

  return (
    <PageShell title="Customise" subtitle="Tune earlymarket AI to your workflow.">
      <div className="space-y-8">
        <section className="rounded-xl border border-border bg-card p-5">
          <h2 className="mb-2 text-sm font-medium uppercase tracking-wide text-muted-foreground">
            Appearance
          </h2>
          <Row label="Theme" description="Switch between dark and light mode.">
            <div className="inline-flex rounded-full border border-border p-0.5">
              <button
                onClick={() => setTheme("dark")}
                className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs ${theme === "dark" ? "bg-accent text-foreground" : "text-muted-foreground"}`}
              >
                <Moon className="h-3.5 w-3.5" /> Dark
              </button>
              <button
                onClick={() => setTheme("light")}
                className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs ${theme === "light" ? "bg-accent text-foreground" : "text-muted-foreground"}`}
              >
                <Sun className="h-3.5 w-3.5" /> Light
              </button>
            </div>
          </Row>
          <Row label="Language" description="Used for the interface and responses.">
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="rounded-md border border-border bg-background px-2 py-1 text-sm"
            >
              <option>English</option>
              <option>Français</option>
              <option>Deutsch</option>
              <option>Swahili</option>
            </select>
          </Row>
        </section>

        <section className="rounded-xl border border-border bg-card p-5">
          <h2 className="mb-2 text-sm font-medium uppercase tracking-wide text-muted-foreground">
            Model
          </h2>
          <Row label="Default model" description="Used when you don't pick one explicitly.">
            <select
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="rounded-md border border-border bg-background px-2 py-1 text-sm"
            >
              <option value="default">earlymarket Default</option>
              <option value="pro">earlymarket Pro</option>
              <option value="reasoning">earlymarket Reasoning</option>
            </select>
          </Row>
          <Row label="Voice mode" description="Enable spoken input and replies.">
            <Toggle checked={voice} onChange={setVoice} />
          </Row>
          <Row label="Autocomplete" description="Suggest follow-ups while you type.">
            <Toggle checked={autocomplete} onChange={setAutocomplete} />
          </Row>
        </section>

        <section className="rounded-xl border border-border bg-card p-5">
          <h2 className="mb-2 text-sm font-medium uppercase tracking-wide text-muted-foreground">
            Privacy
          </h2>
          <Row label="Share usage analytics" description="Help us improve earlymarket AI.">
            <Toggle checked={analytics} onChange={setAnalytics} />
          </Row>
          <Row label="Connected account" description="deejay kenny · earlymarketug.com">
            <button className="rounded-full border border-border px-3 py-1 text-xs hover:bg-accent">
              Manage
            </button>
          </Row>
        </section>
      </div>
    </PageShell>
  );
}