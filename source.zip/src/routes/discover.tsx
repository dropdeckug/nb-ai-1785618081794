import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  ChevronDown,
  Clock,
  Heart,
  MoreHorizontal,
  Cloud,
  TrendingUp,
  TrendingDown,
  Briefcase,
  Wrench,
  Package,
  Tag,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { FeedSkeleton } from "@/components/skeletons/shimmer";
import { useAds, usePosts, useTopSellers, relativeTime, TYPE_LABEL, type AdRow, type PostRow } from "@/lib/use-ads";
import { useEffect } from "react";

export const Route = createFileRoute("/discover")({
  head: () => ({
    meta: [
      { title: "Discover — earlymarket AI" },
      {
        name: "description",
        content:
          "Marketplace pulse: top stories, deals and movements across the EarlyMarket community.",
      },
    ],
  }),
  component: DiscoverPage,
});

const TABS = ["For You", "Top", "Products", "Services", "Jobs", "Promotions", "Posts"] as const;
type Tab = (typeof TABS)[number];

const TYPE_ICONS: Record<string, typeof Briefcase> = {
  physical_products: Package,
  services: Wrench,
  jobs: Briefcase,
  promotions: Tag,
};

const placeholderImg =
  "https://images.unsplash.com/photo-1556740758-90de374c12ad?w=900&q=70&auto=format";

function DiscoverPage() {
  const [active, setActive] = useState<Tab>("For You");
  const { data, loading } = useAds();
  const { data: posts } = usePosts();
  const sellers = useTopSellers(data);

  // Auto-rotate the hero card every 6s through the visible filtered items.
  const [heroIdx, setHeroIdx] = useState(0);

  const filtered = useMemo(() => {
    if (!data) return [];
    if (active === "Posts") return [];
    if (active === "For You") return data;
    if (active === "Top")
      return [...data].sort((a, b) => (b.view_count ?? 0) - (a.view_count ?? 0));
    const map: Record<Tab, string> = {
      "For You": "",
      Top: "",
      Products: "physical_products",
      Services: "services",
      Jobs: "jobs",
      Promotions: "promotions",
      Posts: "",
    };
    return data.filter((a) => a.listing_type === map[active]);
  }, [data, active]);

  useEffect(() => {
    setHeroIdx(0);
  }, [active]);

  useEffect(() => {
    const pool = active === "Posts" ? posts ?? [] : filtered;
    if (pool.length < 2) return;
    const t = setInterval(() => setHeroIdx((i) => (i + 1) % pool.length), 6000);
    return () => clearInterval(t);
  }, [filtered, posts, active]);

  return (
    <div className="grid grid-cols-1 gap-8 px-6 py-6 lg:grid-cols-[1fr_340px]">
      <div>
        <div className="mb-6 flex items-center gap-5 overflow-x-auto border-b border-border">
          <h1 className="mr-auto pb-3 text-base font-medium">Discover</h1>
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setActive(t)}
              className={cn(
                "relative flex shrink-0 items-center gap-1 pb-3 text-sm transition-colors",
                active === t
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {t}
              {active === t && (
                <span className="absolute -bottom-px left-0 right-0 h-0.5 rounded-full bg-foreground" />
              )}
            </button>
          ))}
        </div>

        {loading || !data ? (
          <FeedSkeleton />
        ) : active === "Posts" ? (
          !posts || posts.length === 0 ? (
            <div className="rounded-xl border border-border p-10 text-center text-sm text-muted-foreground">
              No community posts yet.
            </div>
          ) : (
            <div className="space-y-10">
              <PostHero post={posts[heroIdx % posts.length]} seller={sellers?.[posts[heroIdx % posts.length].seller_id ?? ""]} />
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {posts.filter((_, i) => i !== heroIdx % posts.length).slice(0, 12).map((p) => (
                  <PostCard key={p.id} post={p} seller={sellers?.[p.seller_id ?? ""]} />
                ))}
              </div>
            </div>
          )
        ) : filtered.length === 0 ? (
          <div className="rounded-xl border border-border p-10 text-center text-sm text-muted-foreground">
            No listings in this category yet.
          </div>
        ) : (
          <div className="space-y-10">
            <HeroStory
              ad={filtered[heroIdx % filtered.length]}
              seller={sellers?.[filtered[heroIdx % filtered.length].seller_id]}
            />
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.filter((_, i) => i !== heroIdx % filtered.length).slice(0, 12).map((a) => (
                <StoryCard key={a.id} ad={a} seller={sellers?.[a.seller_id]} />
              ))}
            </div>
          </div>
        )}
      </div>

      <aside className="space-y-5">
        <TopAccountsCard ads={data} sellers={sellers} loading={loading} />
        <WeatherCard loading={loading} />
        <MarketOutlook ads={data} loading={loading} />
      </aside>
    </div>
  );
}

function adImage(a: AdRow) {
  return (a.images && a.images[0]) || placeholderImg;
}

function adExcerpt(a: AdRow) {
  if (a.description) return a.description.slice(0, 180);
  const price = a.price ? `${a.currency || "UGX"} ${Number(a.price).toLocaleString()}` : "";
  return `${a.location ?? ""}${price ? ` • ${price}` : ""}`;
}

function TypeBadge({ type }: { type: string | null }) {
  const Icon = TYPE_ICONS[type ?? ""] ?? Tag;
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-secondary/70 px-2 py-0.5 text-[11px] font-medium text-foreground/80">
      <Icon className="h-3 w-3" />
      {TYPE_LABEL[type ?? ""] ?? "Listing"}
    </span>
  );
}

function EngagementDots({ ad }: { ad: AdRow }) {
  const items: { label: string; color: string }[] = [];
  if ((ad.view_count ?? 0) > 0) items.push({ label: "views", color: "bg-sky-400" });
  if ((ad.save_count ?? 0) > 0) items.push({ label: "saves", color: "bg-rose-400" });
  if ((ad.engagement_score ?? 0) > 0)
    items.push({ label: "engagement", color: "bg-emerald-400" });
  if (ad.is_boosted) items.push({ label: "boosted", color: "bg-orange-400" });
  if (items.length === 0) items.push({ label: "new", color: "bg-muted-foreground" });
  return (
    <div className="flex -space-x-1.5">
      {items.slice(0, 4).map((i, idx) => (
        <span
          key={idx}
          className={cn("h-4 w-4 rounded-full border border-background", i.color)}
        />
      ))}
    </div>
  );
}

function HeroStory({ ad, seller }: { ad: AdRow; seller?: import("@/lib/use-ads").SellerRow }) {
  return (
    <article className="grid gap-6 md:grid-cols-[1fr_340px]">
      <div>
        <div className="mb-2 flex items-center gap-2">
          <TypeBadge type={ad.listing_type} />
          {ad.has_discount && (
            <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/10 px-2 py-0.5 text-[11px] font-medium text-rose-500">
              Discount
            </span>
          )}
        </div>
        <h2 className="text-2xl font-medium leading-snug tracking-tight md:text-[28px]">
          {ad.title}
        </h2>
        <div className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
          <Clock className="h-3.5 w-3.5" />
          Posted {relativeTime(ad.created_at)}
          {seller?.business_name && (
            <>
              <span>•</span>
              <span className="inline-flex items-center gap-1">
                {seller.business_name}
                {seller.is_verified && <CheckCircle2 className="h-3 w-3 text-sky-500" />}
              </span>
            </>
          )}
        </div>
        <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground">
          {adExcerpt(ad)}
        </p>
        <div className="mt-5 flex items-center gap-3">
          <EngagementDots ad={ad} />
          <span className="text-xs text-muted-foreground">
            {(ad.view_count ?? 0).toLocaleString()} views • {(ad.save_count ?? 0).toLocaleString()} saves
          </span>
          <div className="ml-auto flex items-center gap-3 text-muted-foreground">
            <button className="hover:text-foreground" aria-label="Like">
              <Heart className="h-4 w-4" />
            </button>
            <button className="hover:text-foreground" aria-label="More">
              <MoreHorizontal className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
      <img
        src={adImage(ad)}
        alt={ad.title}
        className="h-52 w-full rounded-xl object-cover"
        loading="lazy"
      />
    </article>
  );
}

function StoryCard({ ad, seller }: { ad: AdRow; seller?: import("@/lib/use-ads").SellerRow }) {
  return (
    <article className="space-y-3">
      <div className="relative">
        <img
          src={adImage(ad)}
          alt={ad.title}
          className="h-44 w-full rounded-xl object-cover"
          loading="lazy"
        />
        <div className="absolute left-2 top-2">
          <TypeBadge type={ad.listing_type} />
        </div>
      </div>
      <h3 className="text-[15px] font-medium leading-snug">{ad.title}</h3>
      {seller?.business_name && (
        <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
          {seller.business_name}
          {seller.is_verified && <CheckCircle2 className="h-3 w-3 text-sky-500" />}
        </div>
      )}
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <EngagementDots ad={ad} />
        <span>
          {(ad.view_count ?? 0).toLocaleString()} views
        </span>
        <div className="ml-auto flex items-center gap-3">
          <Heart className="h-3.5 w-3.5" />
          <MoreHorizontal className="h-3.5 w-3.5" />
        </div>
      </div>
    </article>
  );
}

function TopAccountsCard({
  ads,
  sellers,
  loading,
}: {
  ads: AdRow[] | null;
  sellers: Record<string, import("@/lib/use-ads").SellerRow> | null;
  loading: boolean;
}) {
  const top = useMemo(() => {
    if (!ads) return [];
    const agg = new Map<
      string,
      { listings: number; views: number; saves: number; score: number }
    >();
    for (const a of ads) {
      const cur = agg.get(a.seller_id) ?? { listings: 0, views: 0, saves: 0, score: 0 };
      cur.listings += 1;
      cur.views += a.view_count ?? 0;
      cur.saves += a.save_count ?? 0;
      cur.score += Number(a.engagement_score ?? 0);
      agg.set(a.seller_id, cur);
    }
    return Array.from(agg.entries())
      .filter(([id]) => sellers?.[id]?.business_name) // only real, named sellers
      .sort(
        (a, b) =>
          b[1].views + b[1].saves * 5 - (a[1].views + a[1].saves * 5) ||
          b[1].listings - a[1].listings,
      )
      .slice(0, 5);
  }, [ads, sellers]);

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-[15px] font-medium">Top accounts</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Most listings & engagement this week
          </p>
        </div>
      </div>
      {loading ? (
        <div className="mt-4 space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="shimmer h-10" />
          ))}
        </div>
      ) : top.length === 0 ? (
        <p className="mt-4 text-xs text-muted-foreground">No top accounts yet.</p>
      ) : (
        <ul className="mt-4 space-y-3">
          {top.map(([id, s], idx) => {
            const seller = sellers?.[id];
            const name = seller?.business_name ?? "Seller";
            return (
              <li key={id} className="flex items-center gap-3">
                <span className="w-4 text-center text-xs text-muted-foreground">
                  {idx + 1}
                </span>
                {seller?.business_logo_url ? (
                  <img
                    src={seller.business_logo_url}
                    alt={name}
                    className="h-8 w-8 rounded-full object-cover"
                  />
                ) : (
                  <div className="grid h-8 w-8 place-items-center rounded-full bg-secondary text-[11px] font-medium">
                    {name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1 text-sm font-medium">
                    <span className="truncate">{name}</span>
                    {seller?.is_verified && (
                      <CheckCircle2 className="h-3 w-3 shrink-0 text-sky-500" />
                    )}
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {s.listings} listings • {s.views.toLocaleString()} views
                    {s.saves > 0 && ` • ${s.saves} saves`}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function WeatherCard({ loading }: { loading: boolean }) {
  if (loading) {
    return (
      <div className="rounded-2xl border border-border bg-card p-5 space-y-3">
        <div className="shimmer h-6 w-32" />
        <div className="shimmer h-3 w-24" />
        <div className="shimmer h-16 w-full" />
      </div>
    );
  }
  const days = [
    { d: "Sat", t: "24°" },
    { d: "Sun", t: "27°" },
    { d: "Mon", t: "27°" },
    { d: "Tue", t: "28°" },
    { d: "Wed", t: "28°" },
  ];
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Cloud className="h-5 w-5 text-muted-foreground" />
          <span className="text-2xl font-light">19°</span>
          <span className="text-xs text-muted-foreground">F/C</span>
        </div>
        <span className="text-xs text-muted-foreground">Partly cloudy</span>
      </div>
      <div className="mt-1 flex items-center justify-between text-xs text-muted-foreground">
        <span>Kampala</span>
        <span>H: 24° L: 17°</span>
      </div>
      <div className="mt-4 grid grid-cols-5 gap-2 text-center">
        {days.map((day) => (
          <div key={day.d} className="space-y-1">
            <Cloud className="mx-auto h-4 w-4 text-muted-foreground" />
            <div className="text-xs">{day.t}</div>
            <div className="text-[10px] text-muted-foreground">{day.d}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MarketOutlook({ ads, loading }: { ads: AdRow[] | null; loading: boolean }) {
  const items = useMemo(() => {
    if (!ads) return [];
    const total = ads.length;
    const count = (t: string) => ads.filter((a) => a.listing_type === t).length;
    const totalViews = ads.reduce((s, a) => s + (a.view_count ?? 0), 0);
    const totalSaves = ads.reduce((s, a) => s + (a.save_count ?? 0), 0);
    return [
      { name: "Active Listings", value: total.toLocaleString(), delta: `${count("physical_products")} products`, up: true },
      { name: "Total Views", value: totalViews.toLocaleString(), delta: `${totalSaves} saves`, up: true },
      { name: "Services", value: count("services").toLocaleString(), delta: `${count("jobs")} jobs`, up: true },
      { name: "Promotions", value: count("promotions").toLocaleString(), delta: `${ads.filter((a) => a.has_discount).length} discounted`, up: ads.filter((a) => a.has_discount).length > 0 },
    ];
  }, [ads]);

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h3 className="text-[15px] font-medium">Market Outlook</h3>
      {loading || !ads ? (
        <div className="mt-3 grid grid-cols-2 gap-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="shimmer h-16" />
          ))}
        </div>
      ) : (
        <div className="mt-3 grid grid-cols-2 gap-3">
          {items.map((i) => (
            <div key={i.name} className="rounded-lg border border-border p-3">
              <div className="text-[11px] text-muted-foreground">{i.name}</div>
              <div className="mt-1 text-sm font-medium">{i.value}</div>
              <div
                className={cn(
                  "mt-1 flex items-center gap-1 text-[11px]",
                  i.up ? "text-emerald-500" : "text-rose-500",
                )}
              >
                {i.up ? (
                  <TrendingUp className="h-3 w-3" />
                ) : (
                  <TrendingDown className="h-3 w-3" />
                )}
                {i.delta}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function postImage(p: PostRow) {
  return (p.images && p.images[0]) || placeholderImg;
}

function PostHero({ post, seller }: { post: PostRow; seller?: import("@/lib/use-ads").SellerRow }) {
  const title = post.title || (post.content ?? "").slice(0, 100) || "Community post";
  const excerpt = (post.content ?? "").slice(0, 200);
  return (
    <article className="grid gap-6 md:grid-cols-[1fr_340px]">
      <div>
        <div className="mb-2 flex items-center gap-2">
          <span className="inline-flex items-center gap-1 rounded-full bg-secondary/70 px-2 py-0.5 text-[11px] font-medium text-foreground/80">
            Post
          </span>
        </div>
        <h2 className="text-2xl font-medium leading-snug tracking-tight md:text-[28px]">
          {title}
        </h2>
        <div className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
          <Clock className="h-3.5 w-3.5" />
          Posted {relativeTime(post.created_at)}
          {seller?.business_name && (
            <>
              <span>•</span>
              <span className="inline-flex items-center gap-1">
                {seller.business_name}
                {seller.is_verified && <CheckCircle2 className="h-3 w-3 text-sky-500" />}
              </span>
            </>
          )}
        </div>
        <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground">
          {excerpt}
        </p>
        <div className="mt-5 flex items-center gap-3 text-xs text-muted-foreground">
          <span>{(post.view_count ?? 0).toLocaleString()} views</span>
          <span>•</span>
          <span>{(post.like_count ?? 0).toLocaleString()} likes</span>
          <span>•</span>
          <span>{(post.comment_count ?? 0).toLocaleString()} comments</span>
          <div className="ml-auto flex items-center gap-3">
            <Heart className="h-4 w-4" />
            <MoreHorizontal className="h-4 w-4" />
          </div>
        </div>
      </div>
      <img src={postImage(post)} alt={title} className="h-52 w-full rounded-xl object-cover" loading="lazy" />
    </article>
  );
}

function PostCard({ post, seller }: { post: PostRow; seller?: import("@/lib/use-ads").SellerRow }) {
  const title = post.title || (post.content ?? "").slice(0, 80) || "Community post";
  return (
    <article className="space-y-3">
      <div className="relative">
        <img src={postImage(post)} alt={title} className="h-44 w-full rounded-xl object-cover" loading="lazy" />
        <div className="absolute left-2 top-2">
          <span className="inline-flex items-center gap-1 rounded-full bg-secondary/70 px-2 py-0.5 text-[11px] font-medium text-foreground/80">
            Post
          </span>
        </div>
      </div>
      <h3 className="text-[15px] font-medium leading-snug">{title}</h3>
      {seller?.business_name && (
        <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
          {seller.business_name}
          {seller.is_verified && <CheckCircle2 className="h-3 w-3 text-sky-500" />}
        </div>
      )}
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <span>{(post.view_count ?? 0).toLocaleString()} views</span>
        <span>•</span>
        <span>{(post.like_count ?? 0).toLocaleString()} likes</span>
        <div className="ml-auto flex items-center gap-3">
          <Heart className="h-3.5 w-3.5" />
          <MoreHorizontal className="h-3.5 w-3.5" />
        </div>
      </div>
    </article>
  );
}
