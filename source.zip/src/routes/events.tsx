import { createFileRoute } from "@tanstack/react-router";
import { Calendar, MapPin } from "lucide-react";
import { useSimulatedFetch } from "@/lib/use-simulated-fetch";
import { CardGridSkeleton } from "@/components/skeletons/shimmer";

export const Route = createFileRoute("/events")({
  head: () => ({
    meta: [
      { title: "Events — earlymarket AI" },
      {
        name: "description",
        content:
          "Markets, expos and community meetups happening on EarlyMarket UG.",
      },
    ],
  }),
  component: EventsPage,
});

const EVENTS = [
  {
    id: "1",
    title: "Kampala Weekend Open Market",
    date: "Sat, 17 May · 9:00",
    place: "Centenary Park",
    image:
      "https://images.unsplash.com/photo-1533900298318-6b8da08a523e?w=600&q=70&auto=format",
  },
  {
    id: "2",
    title: "EarlyMarket Sellers Bootcamp",
    date: "Wed, 21 May · 14:00",
    place: "Online",
    image:
      "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&q=70&auto=format",
  },
  {
    id: "3",
    title: "Ntinda Food Festival",
    date: "Sun, 25 May · 11:00",
    place: "Ntinda Square",
    image:
      "https://images.unsplash.com/photo-1555244162-803834f70033?w=600&q=70&auto=format",
  },
];

function EventsPage() {
  const { data, loading } = useSimulatedFetch(EVENTS);
  return (
    <div className="px-6 py-6">
      <h1 className="text-2xl font-light tracking-tight">Events</h1>
      <p className="text-sm text-muted-foreground">
        Markets, meetups and expos curated for your interests.
      </p>
      <div className="mt-6">
        {loading || !data ? (
          <CardGridSkeleton count={3} />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {data.map((e) => (
              <article
                key={e.id}
                className="overflow-hidden rounded-xl border border-border bg-card"
              >
                <img
                  src={e.image}
                  alt={e.title}
                  className="h-40 w-full object-cover"
                  loading="lazy"
                />
                <div className="p-4">
                  <h3 className="text-sm font-medium">{e.title}</h3>
                  <div className="mt-2 flex flex-col gap-1 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {e.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      {e.place}
                    </span>
                  </div>
                  <button className="mt-3 w-full rounded-full border border-border py-1.5 text-xs hover:bg-accent">
                    RSVP
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}