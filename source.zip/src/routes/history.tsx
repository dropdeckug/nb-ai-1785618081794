import { createFileRoute } from "@tanstack/react-router";
import { History as HistoryIcon } from "lucide-react";
import { PageShell } from "@/components/page-shell";

export const Route = createFileRoute("/history")({
  head: () => ({ meta: [{ title: "History — earlymarket AI" }] }),
  component: () => (
    <PageShell title="History" subtitle="Your recent threads.">
      <ul className="divide-y divide-border rounded-xl border border-border bg-card">
        {[
          "how to set up electron in my project",
          "compare vector databases for RAG",
          "summarise EarlyMarket UG quarterly update",
          "ideas for a personal CRM",
        ].map((h) => (
          <li key={h} className="flex items-center gap-3 px-4 py-3 hover:bg-accent">
            <HistoryIcon className="h-4 w-4 text-muted-foreground" />
            <span className="truncate text-sm">{h}</span>
          </li>
        ))}
      </ul>
    </PageShell>
  ),
});