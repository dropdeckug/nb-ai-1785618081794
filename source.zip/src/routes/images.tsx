import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Sparkles, Image as ImageIcon, Wand2, Loader2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/images")({
  head: () => ({
    meta: [
      { title: "Images — earlymarket AI" },
      { name: "description", content: "Your generated and uploaded images." },
    ],
  }),
  component: ImagesPage,
});

type Media = {
  id: string;
  url: string;
  source: string | null;
  prompt: string | null;
  created_at: string;
};

type Filter = "all" | "ai" | "uploaded";

function ImagesPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState<Media[]>([]);
  const [loadingList, setLoadingList] = useState(true);
  const [filter, setFilter] = useState<Filter>("all");
  const [prompt, setPrompt] = useState("");
  const [generating, setGenerating] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [lightbox, setLightbox] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      setLoadingList(true);
      const { data } = await supabase
        .from("user_generated_media")
        .select("id,url,source,prompt,created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(200);
      if (!cancelled) {
        setItems((data ?? []) as Media[]);
        setLoadingList(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  const filtered = items.filter((m) =>
    filter === "all" ? true : filter === "ai" ? m.source === "ai" : m.source !== "ai",
  );

  const generate = async () => {
    if (!prompt.trim() || generating || !user) return;
    setGenerating(true);
    setPreview(null);
    try {
      const res = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      if (!res.ok || !res.body) {
        const t = await res.text().catch(() => "");
        throw new Error(t || `Failed (${res.status})`);
      }
      const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
      let buf = "";
      let finalB64 = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += value;
        const events = buf.split("\n\n");
        buf = events.pop() ?? "";
        for (const ev of events) {
          const line = ev.split("\n").find((l) => l.startsWith("data:"));
          if (!line) continue;
          const json = line.slice(5).trim();
          if (json === "[DONE]") continue;
          try {
            const p = JSON.parse(json);
            if (p.b64_json) {
              setPreview(`data:image/png;base64,${p.b64_json}`);
              if (p.type === "image_generation.completed") finalB64 = p.b64_json;
            }
          } catch {
            /* ignore */
          }
        }
      }
      if (finalB64) {
        const dataUrl = `data:image/png;base64,${finalB64}`;
        const { data: row } = await supabase
          .from("user_generated_media")
          .insert({
            user_id: user.id,
            url: dataUrl,
            source: "ai",
            prompt,
            mime_type: "image/png",
            width: 1024,
            height: 1024,
          })
          .select("id,url,source,prompt,created_at")
          .single();
        if (row) setItems((prev) => [row as Media, ...prev]);
        setPrompt("");
        setPreview(null);
      }
    } catch (e) {
      alert(e instanceof Error ? e.message : "Generation failed");
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="h-[calc(100vh-3.5rem)] overflow-y-auto">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 py-8">
        <div className="flex items-center gap-3 mb-6">
          <ImageIcon className="h-6 w-6 text-brand" />
          <h1 className="text-2xl font-light tracking-tight">Images</h1>
        </div>

        {/* Generator */}
        <div className="rounded-2xl border border-border bg-card p-4 mb-6">
          <div className="flex items-center gap-2 mb-3 text-sm text-muted-foreground">
            <Wand2 className="h-4 w-4" />
            Generate with GPT Image
          </div>
          <div className="flex gap-2">
            <input
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && generate()}
              placeholder="Describe an image…"
              disabled={generating}
              className="flex-1 rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand/40"
            />
            <button
              onClick={generate}
              disabled={generating || !prompt.trim()}
              className="rounded-lg bg-foreground text-background px-4 py-2 text-sm font-medium hover:opacity-90 disabled:opacity-50 inline-flex items-center gap-2"
            >
              {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              Generate
            </button>
          </div>
          {preview && (
            <div className="mt-4">
              <img
                src={preview}
                alt="preview"
                className={cn(
                  "rounded-lg max-h-80 transition-[filter]",
                  generating ? "blur-md" : "blur-0",
                )}
              />
            </div>
          )}
        </div>

        {/* Filter */}
        <div className="flex gap-2 mb-4">
          {(["all", "ai", "uploaded"] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs capitalize",
                filter === f
                  ? "border-foreground bg-foreground text-background"
                  : "border-border text-muted-foreground hover:bg-accent",
              )}
            >
              {f === "ai" ? "Generated by AI" : f}
            </button>
          ))}
        </div>

        {/* Grid */}
        {loadingList ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="aspect-square animate-pulse rounded-lg bg-muted" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center text-sm text-muted-foreground py-16">
            No images yet. Generate one above.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {filtered.map((m) => (
              <button
                key={m.id}
                onClick={() => setLightbox(m.url)}
                className="group relative aspect-square overflow-hidden rounded-lg bg-muted"
              >
                <img
                  src={m.url}
                  alt={m.prompt ?? ""}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
                {m.source === "ai" && (
                  <span className="absolute top-2 left-2 rounded-full bg-black/60 text-white px-2 py-0.5 text-[10px] inline-flex items-center gap-1">
                    <Sparkles className="h-2.5 w-2.5" /> AI
                  </span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {lightbox && (
        <div
          onClick={() => setLightbox(null)}
          className="fixed inset-0 z-50 grid place-items-center bg-black/90 p-6 cursor-zoom-out"
        >
          <img src={lightbox} alt="" className="max-h-full max-w-full rounded-lg" />
          <button
            className="absolute top-4 right-4 grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}
