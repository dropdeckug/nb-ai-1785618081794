import { createFileRoute, useNavigate } from "@tanstack/react-router";
import {
  Monitor,
  ListTodo,
  Eye,
  Users,
  Code2,
  ArrowRight,
} from "lucide-react";
import { SearchComposer } from "@/components/search-composer";
import { useChatStore } from "@/lib/chat-store";

export const Route = createFileRoute("/")({
  component: Index,
});

const chips = [
  { label: "Find trending products", icon: ListTodo },
  { label: "Top sellers this week", icon: Users },
  { label: "Hot promotions & discounts", icon: Eye },
  { label: "Latest job listings", icon: Code2 },
];

const prompts = [
  "What services are trending on earlymarket today?",
  "Show me top-rated sellers in Kampala",
  "Find affordable electronics with active discounts",
];

function Index() {
  const navigate = useNavigate();
  const createThread = useChatStore((s) => s.createThread);
  const submit = (text: string) => {
    const id = createThread(text);
    navigate({ to: "/ask/$threadId", params: { threadId: id } });
  };
  return (
    <div className="mx-auto flex min-h-[calc(100vh-3.5rem)] w-full max-w-3xl flex-col items-center px-4 sm:px-6 pt-12 sm:pt-20">
      <h1 className="mb-8 sm:mb-10 text-center text-4xl sm:text-6xl font-light tracking-tight text-foreground">
        earlymarket
      </h1>

      <div className="w-full">
        <SearchComposer onSubmit={submit} autoFocus />
      </div>

      <div className="mt-6 w-full rounded-2xl border border-border bg-card/50 p-3">
        <div className="flex items-center gap-2 px-2 py-1.5 text-xs text-muted-foreground">
          <Monitor className="h-3.5 w-3.5" />
          Try earlymarket
        </div>
        <div className="mt-1 flex flex-wrap gap-2 px-1">
          {chips.map((c) => (
            <button
              key={c.label}
              onClick={() => submit(c.label)}
              className="flex items-center gap-1.5 rounded-full border border-border bg-background/60 px-3 py-1.5 text-xs font-medium hover:bg-accent"
            >
              <c.icon className="h-3.5 w-3.5 text-brand" />
              {c.label}
            </button>
          ))}
        </div>
        <div className="mt-3 divide-y divide-border/60 px-2">
          {prompts.map((p) => (
            <button
              key={p}
              onClick={() => submit(p)}
              className="group flex w-full items-center justify-between py-2.5 text-left text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <span>{p}</span>
              <ArrowRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
