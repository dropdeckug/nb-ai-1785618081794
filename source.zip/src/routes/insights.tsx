import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Brush,
  CartesianGrid,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  ChevronDown,
  Maximize2,
  Camera,
  MoreHorizontal,
  TrendingUp,
  Star,
  Bell,
} from "lucide-react";
import { ChartSkeleton, Shimmer } from "@/components/skeletons/shimmer";
import { useAds, TYPE_LABEL, type AdRow } from "@/lib/use-ads";
import { useAuth } from "@/lib/auth";
import { BarChart3 } from "lucide-react";

export const Route = createFileRoute("/insights")({
  head: () => ({
    meta: [
      { title: "Insights — earlymarket AI" },
      {
        name: "description",
        content:
          "Real-time analytics for your EarlyMarket store: revenue, orders, and AI-driven recommendations.",
      },
    ],
  }),
  component: InsightsPage,
});

type Point = { t: string; v: number; vol: number };

function buildSeries(ads: AdRow[]): Point[] {
  // Group by day (last 30 days), value = cumulative views, vol = listings created that day.
  const days = 30;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const buckets: { date: Date; views: number; listings: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    buckets.push({ date: d, views: 0, listings: 0 });
  }
  for (const a of ads) {
    const created = new Date(a.created_at);
    created.setHours(0, 0, 0, 0);
    const idx = buckets.findIndex((b) => b.date.getTime() === created.getTime());
    if (idx >= 0) {
      buckets[idx].listings += 1;
      buckets[idx].views += a.view_count ?? 0;
    }
  }
  let cumulative = 0;
  return buckets.map((b) => {
    cumulative += b.views;
    return {
      t: `${b.date.getMonth() + 1}/${b.date.getDate()}`,
      v: cumulative,
      vol: b.listings,
    };
  });
}

function InsightsPage() {
  const { data: ads, loading } = useAds();
  const series = useMemo(() => (ads ? buildSeries(ads) : []), [ads]);
  const [range, setRange] = useState("1M");

  return (
    <div className="px-6 py-6">
      <div className="mb-4 flex items-center gap-2 text-sm">
        <Link to="/insights" className="text-muted-foreground hover:underline">
          earlymarket Insights
        </Link>
        <span className="text-muted-foreground">›</span>
        <span>EM-INDEX</span>
      </div>

      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-full border border-border text-xs font-medium">
            EM
          </div>
          <div>
            <h1 className="text-3xl font-light tracking-tight">
              EarlyMarket Index
            </h1>
            <p className="text-xs text-muted-foreground">EM-INDEX • Live from marketplace</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <MyInsightsButton ads={ads} />
          <button className="flex items-center gap-1 rounded-full px-3 py-1.5 hover:bg-accent">
            <Star className="h-3.5 w-3.5" /> Follow
          </button>
          <button className="hidden sm:flex items-center gap-1 rounded-full px-3 py-1.5 hover:bg-accent">
            <Bell className="h-3.5 w-3.5" /> Price Alert
          </button>
        </div>
      </div>

      {loading || series.length === 0 ? (
        <ChartSkeleton />
      ) : (
        <ChartCard data={series} range={range} setRange={setRange} />
      )}

      <div className="mt-6 grid gap-4 lg:grid-cols-[1fr_320px]">
        <StatsTable loading={loading} ads={ads} series={series} />
        <SideNote loading={loading} />
      </div>
    </div>
  );
}

function ChartCard({
  data,
  range,
  setRange,
}: {
  data: { t: string; v: number; vol: number }[];
  range: string;
  setRange: (r: string) => void;
}) {
  const last = data[data.length - 1].v;
  const first = data[0].v;
  const change = last - first;
  const pct = ((change / first) * 100).toFixed(2);
  const up = change >= 0;
  const ranges = ["1D", "1W", "1M", "3M", "1Y", "ALL"];

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex items-baseline gap-3">
        <span className="text-2xl font-medium">
          {last.toLocaleString()} views
        </span>
        <span
          className={
            up
              ? "text-sm font-medium text-emerald-500"
              : "text-sm font-medium text-rose-500"
          }
        >
          {up ? "+" : ""}{change.toLocaleString()} {up ? "↗" : "↘"} {pct}%
        </span>
      </div>
      <div className="mt-1 text-xs text-muted-foreground">
        Cumulative marketplace views • last 30 days
      </div>

      <div className="mt-4 flex items-center gap-2 border-b border-border pb-3">
        <div className="flex items-center gap-1 rounded-full border border-border bg-background px-2 py-1 text-xs">
          <select
            value={range}
            onChange={(e) => setRange(e.target.value)}
            className="cursor-pointer bg-transparent pr-1 outline-none"
          >
            {ranges.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
          <ChevronDown className="h-3 w-3" />
        </div>
        <button className="flex items-center gap-1 rounded-full border border-border px-2 py-1 text-xs hover:bg-accent">
          Compare <ChevronDown className="h-3 w-3" />
        </button>
        <button
          className="grid h-7 w-7 place-items-center rounded-full border border-border hover:bg-accent"
          aria-label="Snapshot"
        >
          <Camera className="h-3.5 w-3.5" />
        </button>
        <button
          className="grid h-7 w-7 place-items-center rounded-full border border-border hover:bg-accent"
          aria-label="Fullscreen"
        >
          <Maximize2 className="h-3.5 w-3.5" />
        </button>
        <button
          className="ml-auto grid h-7 w-7 place-items-center rounded-full border border-border hover:bg-accent"
          aria-label="More"
        >
          <MoreHorizontal className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="mt-4 h-72 w-full">
        <ResponsiveContainer>
          <AreaChart data={data}>
            <defs>
              <linearGradient id="emFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.78 0.18 150)" stopOpacity={0.4} />
                <stop offset="100%" stopColor="oklch(0.78 0.18 150)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 4" vertical={false} />
            <XAxis
              dataKey="t"
              tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              orientation="left"
              domain={["dataMin - 100", "dataMax + 100"]}
              tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
              tickLine={false}
              axisLine={false}
              width={60}
            />
            <Tooltip
              cursor={{ stroke: "var(--color-foreground)", strokeOpacity: 0.2 }}
              contentStyle={{
                background: "var(--color-card)",
                border: "1px solid var(--color-border)",
                borderRadius: 8,
                fontSize: 12,
              }}
              formatter={(v: number) => [`${v.toLocaleString()} views`, "Cumulative"]}
            />
            <ReferenceLine
              y={data[0].v}
              stroke="var(--color-muted-foreground)"
              strokeDasharray="4 4"
              label={{
                value: `Start: ${data[0].v.toLocaleString()}`,
                fill: "var(--color-muted-foreground)",
                fontSize: 11,
                position: "right",
              }}
            />
            <Area
              type="monotone"
              dataKey="v"
              stroke="oklch(0.78 0.18 150)"
              strokeWidth={1.5}
              fill="url(#emFill)"
              isAnimationActive
            />
            <Brush
              dataKey="t"
              height={28}
              travellerWidth={8}
              stroke="var(--color-border)"
              fill="var(--color-card)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-2 h-16 w-full">
        <ResponsiveContainer>
          <BarChart data={data}>
            <Bar dataKey="vol" fill="oklch(0.6 0.13 150 / 0.4)" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function StatsTable({
  loading,
  ads,
  series,
}: {
  loading: boolean;
  ads: AdRow[] | null;
  series: { v: number; vol: number }[];
}) {
  if (loading || !ads || series.length === 0) {
    return (
      <div className="rounded-xl border border-border bg-card p-5 space-y-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <Shimmer key={i} className="h-5" />
        ))}
      </div>
    );
  }
  const totalViews = ads.reduce((s, a) => s + (a.view_count ?? 0), 0);
  const totalSaves = ads.reduce((s, a) => s + (a.save_count ?? 0), 0);
  const newest = series[series.length - 1];
  const newListings30d = series.reduce((s, p) => s + p.vol, 0);
  const byType = (t: string) => ads.filter((a) => a.listing_type === t).length;
  const stats = [
    { k: "Total Listings", v: ads.length.toLocaleString() },
    { k: "Total Views", v: totalViews.toLocaleString() },
    { k: "Total Saves", v: totalSaves.toLocaleString() },
    { k: "New (30d)", v: newListings30d.toLocaleString() },
    { k: "Today's Posts", v: newest.vol.toLocaleString() },
    { k: TYPE_LABEL.physical_products, v: byType("physical_products").toLocaleString() },
    { k: TYPE_LABEL.services, v: byType("services").toLocaleString() },
    { k: TYPE_LABEL.jobs, v: byType("jobs").toLocaleString() },
    { k: TYPE_LABEL.promotions, v: byType("promotions").toLocaleString() },
  ];
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="mb-3 flex items-center gap-2 text-sm font-medium">
        <TrendingUp className="h-4 w-4" /> Live Statistics
      </h3>
      <div className="grid grid-cols-2 gap-y-2 text-sm sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.k} className="flex flex-col">
            <span className="text-xs text-muted-foreground">{s.k}</span>
            <span>{s.v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function SideNote({ loading }: { loading: boolean }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 text-xs text-muted-foreground">
      {loading ? (
        <div className="space-y-2">
          <Shimmer className="h-3" />
          <Shimmer className="h-3 w-5/6" />
          <Shimmer className="h-3 w-2/3" />
        </div>
      ) : (
        <>
          Data provided by EarlyMarket UG. Index aggregates seller revenue,
          basket size, and bookings across the platform. For informational
          purposes only — not investment advice.
        </>
      )}
    </div>
  );
}
function MyInsightsButton({ ads }: { ads: AdRow[] | null }) {
  const { user, business } = useAuth();
  if (!user) return null;
  const mine = (ads ?? []).filter((a) => a.seller_id === user.id);
  const views = mine.reduce((s, a) => s + (a.view_count ?? 0), 0);
  const label = business?.business_name ? "My business insights" : "My insights";
  return (
    <button className="flex items-center gap-1.5 rounded-full bg-foreground px-3 py-1.5 text-xs font-medium text-background hover:opacity-90">
      <BarChart3 className="h-3.5 w-3.5" />
      {label} • {mine.length} listings • {views.toLocaleString()} views
    </button>
  );
}
