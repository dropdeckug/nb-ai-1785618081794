import { createFileRoute } from "@tanstack/react-router";
import { MapPin, Briefcase, Clock } from "lucide-react";
import { useSimulatedFetch } from "@/lib/use-simulated-fetch";
import { Shimmer } from "@/components/skeletons/shimmer";

export const Route = createFileRoute("/jobs")({
  head: () => ({
    meta: [
      { title: "Jobs — earlymarket AI" },
      {
        name: "description",
        content:
          "Open roles across the EarlyMarket community — matched to your profile.",
      },
    ],
  }),
  component: JobsPage,
});

const JOBS = [
  {
    id: "1",
    title: "Backend Engineer (Node.js)",
    company: "EarlyMarket UG",
    location: "Kampala, Hybrid",
    type: "Full-time",
    posted: "2d ago",
  },
  {
    id: "2",
    title: "Boda dispatch coordinator",
    company: "QuickDrop Logistics",
    location: "Ntinda",
    type: "Full-time",
    posted: "1d ago",
  },
  {
    id: "3",
    title: "Social media designer",
    company: "Sanyu Crafts",
    location: "Remote (Uganda)",
    type: "Contract",
    posted: "5h ago",
  },
  {
    id: "4",
    title: "Customer success agent",
    company: "EarlyMarket UG",
    location: "Kampala",
    type: "Full-time",
    posted: "3d ago",
  },
];

function JobsPage() {
  const { data, loading } = useSimulatedFetch(JOBS);
  return (
    <div className="mx-auto max-w-3xl px-6 py-6">
      <h1 className="text-2xl font-light tracking-tight">Jobs</h1>
      <p className="text-sm text-muted-foreground">
        Roles matched to your skills and recent activity.
      </p>
      <div className="mt-6 space-y-3">
        {loading || !data
          ? Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className="rounded-xl border border-border bg-card p-4 space-y-3"
              >
                <Shimmer className="h-4 w-2/3" />
                <Shimmer className="h-3 w-1/3" />
                <Shimmer className="h-3 w-1/2" />
              </div>
            ))
          : data.map((j) => (
              <article
                key={j.id}
                className="flex flex-col gap-2 rounded-xl border border-border bg-card p-4 transition hover:border-foreground/20 sm:flex-row sm:items-center"
              >
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-secondary text-foreground/70">
                  <Briefcase className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-medium">{j.title}</h3>
                  <p className="text-xs text-muted-foreground">{j.company}</p>
                  <div className="mt-1 flex flex-wrap gap-3 text-[11px] text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      {j.location}
                    </span>
                    <span>{j.type}</span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {j.posted}
                    </span>
                  </div>
                </div>
                <button className="rounded-full bg-foreground px-4 py-1.5 text-xs font-medium text-background hover:opacity-90">
                  Apply
                </button>
              </article>
            ))}
      </div>
    </div>
  );
}