import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useSimulatedFetch } from "@/lib/use-simulated-fetch";
import { CardGridSkeleton, Shimmer } from "@/components/skeletons/shimmer";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "Products — earlymarket AI" },
      {
        name: "description",
        content:
          "AI-curated product recommendations from the EarlyMarket marketplace.",
      },
    ],
  }),
  component: ProductsPage,
});

const PRODUCTS = [
  {
    id: "1",
    name: "Solar lantern with USB charger",
    seller: "BrightHome KLA",
    price: "UGX 78,000",
    image:
      "https://images.unsplash.com/photo-1565636192335-fb3b50886e69?w=600&q=70&auto=format",
    tag: "Trending",
  },
  {
    id: "2",
    name: "Handwoven kitenge bag",
    seller: "Sanyu Crafts",
    price: "UGX 45,000",
    image:
      "https://images.unsplash.com/photo-1591561954557-26941169b49e?w=600&q=70&auto=format",
    tag: "New",
  },
  {
    id: "3",
    name: "Cold-pressed honey 500g",
    seller: "Mukwano Farm",
    price: "UGX 22,000",
    image:
      "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=600&q=70&auto=format",
    tag: "Best seller",
  },
  {
    id: "4",
    name: "Refurbished Lenovo ThinkPad",
    seller: "TechHub Ntinda",
    price: "UGX 1,250,000",
    image:
      "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=600&q=70&auto=format",
    tag: "Discount",
  },
  {
    id: "5",
    name: "Organic shea butter 200ml",
    seller: "Nile Beauty",
    price: "UGX 18,000",
    image:
      "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600&q=70&auto=format",
    tag: "New",
  },
  {
    id: "6",
    name: "Hand-painted ceramic mugs",
    seller: "Clay & Co.",
    price: "UGX 12,500",
    image:
      "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=600&q=70&auto=format",
    tag: "Trending",
  },
];

function ProductsPage() {
  const { data, loading } = useSimulatedFetch(PRODUCTS);
  return (
    <div className="px-6 py-6">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-light tracking-tight">Products</h1>
          <p className="text-sm text-muted-foreground">
            Recommendations powered by your store activity and recent demand.
          </p>
        </div>
        <div className="flex w-full items-center gap-2 rounded-full border border-border bg-card px-4 py-2 sm:w-80">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            placeholder="Search products"
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>
      </div>

      {loading || !data ? (
        <CardGridSkeleton count={6} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {data.map((p) => (
            <article
              key={p.id}
              className="group overflow-hidden rounded-xl border border-border bg-card transition hover:border-foreground/20"
            >
              <div className="relative">
                <img
                  src={p.image}
                  alt={p.name}
                  className="h-44 w-full object-cover"
                  loading="lazy"
                />
                <span className="absolute left-3 top-3 rounded-full bg-background/80 px-2 py-0.5 text-[10px] font-medium backdrop-blur">
                  {p.tag}
                </span>
              </div>
              <div className="p-4">
                <h3 className="text-sm font-medium">{p.name}</h3>
                <p className="mt-1 text-xs text-muted-foreground">{p.seller}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-sm font-semibold">{p.price}</span>
                  <button className="rounded-full border border-border px-3 py-1 text-[11px] hover:bg-accent">
                    Analyse
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      <div className="mt-8 rounded-xl border border-border bg-card p-5">
        <h3 className="text-sm font-medium">AI suggestion</h3>
        {loading ? (
          <div className="mt-3 space-y-2">
            <Shimmer className="h-3" />
            <Shimmer className="h-3 w-5/6" />
            <Shimmer className="h-3 w-2/3" />
          </div>
        ) : (
          <p className="mt-2 text-sm text-muted-foreground">
            Your store can lift conversion ~14% by bundling the solar lantern
            with the cold-pressed honey for the upcoming weekend market.
          </p>
        )}
      </div>
    </div>
  );
}