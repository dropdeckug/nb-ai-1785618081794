import { createFileRoute } from "@tanstack/react-router";
import { Star } from "lucide-react";
import { useSimulatedFetch } from "@/lib/use-simulated-fetch";
import { CardGridSkeleton } from "@/components/skeletons/shimmer";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — earlymarket AI" },
      {
        name: "description",
        content:
          "Discover trusted service providers across Uganda — analysed and ranked by EarlyMarket AI.",
      },
    ],
  }),
  component: ServicesPage,
});

const SERVICES = [
  {
    id: "1",
    title: "Home cleaning & laundry",
    provider: "Sparkle Pros",
    rating: 4.9,
    bookings: 1240,
    image:
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600&q=70&auto=format",
  },
  {
    id: "2",
    title: "Maths & Physics tutoring",
    provider: "Brainy Coach",
    rating: 4.8,
    bookings: 312,
    image:
      "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600&q=70&auto=format",
  },
  {
    id: "3",
    title: "Wedding photography",
    provider: "Lens & Light",
    rating: 5.0,
    bookings: 87,
    image:
      "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&q=70&auto=format",
  },
  {
    id: "4",
    title: "Plumbing repairs",
    provider: "FixIt Kampala",
    rating: 4.7,
    bookings: 642,
    image:
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600&q=70&auto=format",
  },
  {
    id: "5",
    title: "Salon at home",
    provider: "Glow Studio",
    rating: 4.9,
    bookings: 901,
    image:
      "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=600&q=70&auto=format",
  },
  {
    id: "6",
    title: "Catering for events",
    provider: "Plate Stories",
    rating: 4.8,
    bookings: 233,
    image:
      "https://images.unsplash.com/photo-1555244162-803834f70033?w=600&q=70&auto=format",
  },
];

function ServicesPage() {
  const { data, loading } = useSimulatedFetch(SERVICES);
  return (
    <div className="px-6 py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-light tracking-tight">Services</h1>
        <p className="text-sm text-muted-foreground">
          Verified providers near you, scored by EarlyMarket AI.
        </p>
      </div>
      {loading || !data ? (
        <CardGridSkeleton count={6} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {data.map((s) => (
            <article
              key={s.id}
              className="overflow-hidden rounded-xl border border-border bg-card"
            >
              <img
                src={s.image}
                alt={s.title}
                className="h-40 w-full object-cover"
                loading="lazy"
              />
              <div className="p-4">
                <h3 className="text-sm font-medium">{s.title}</h3>
                <p className="text-xs text-muted-foreground">{s.provider}</p>
                <div className="mt-3 flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1">
                    <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                    {s.rating}
                  </span>
                  <span className="text-muted-foreground">
                    {s.bookings} bookings
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}