import { createFileRoute } from "@tanstack/react-router";
import { LayoutGrid, Plus } from "lucide-react";
import { PageShell } from "@/components/page-shell";

export const Route = createFileRoute("/spaces")({
  head: () => ({ meta: [{ title: "Spaces — earlymarket AI" }] }),
  component: () => (
    <PageShell title="Spaces" subtitle="Group conversations, files and sources by project.">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <button className="flex items-center justify-center gap-2 rounded-xl border border-dashed border-border p-8 text-sm text-muted-foreground hover:bg-accent">
          <Plus className="h-4 w-4" /> New space
        </button>
        {["Market research", "Customer insights", "Product roadmap"].map((s) => (
          <div key={s} className="rounded-xl border border-border bg-card p-4">
            <LayoutGrid className="h-5 w-5 text-brand" />
            <div className="mt-3 text-sm font-medium">{s}</div>
            <div className="text-xs text-muted-foreground">12 threads · updated today</div>
          </div>
        ))}
      </div>
    </PageShell>
  ),
});
